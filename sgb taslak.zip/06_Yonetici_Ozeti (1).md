# Yönetici Özeti – Siber Güvenlik Mevzuatı Karşılaştırmalı Analiz

**Kapsam.** [ÇIKARIM] İncelenen metinler Bilgi ve İletişim Güvenliği Rehberi (BİGR), Siber Dayanıklılık Yönetmeliği Taslağı (SD), Denetim Yönetmeliği Taslağı (DY) ve Bankaların Bilgi Sistemleri ve Elektronik Bankacılık Hizmetleri Hakkında Yönetmelik (BSEY) ile görüş formu şablonudur. [ÇIKARIM] Envanter 1.890 birimden oluşur: BİGR 719, SD 497, DY 279, BSEY 395 (00 dosyası). [ÇIKARIM] Kurum bilgisi verilmediği için analiz kurumdan bağımsızdır.

## Temel bulgular

- [ÇIKARIM] BİGR'in 660 tedbirinden 78'i SD ile örtüşmektedir. [ÇIKARIM] 467 tedbirde BİGR daha ayrıntılıdır. [ÇIKARIM] 15 tedbirde SD daha katıdır. [ÇIKARIM] 85 tedbirin SD'de karşılığı yoktur (arama kanıtıyla) (02 dosyası).
- [ÇIKARIM] SD'nin 497 fıkra/bendinden 205'inin BİGR'de karşılığı bulunamamıştır. [ÇIKARIM] 130 birimde SD daha ayrıntılı, 16 birimde SD daha katıdır (02 dosyası).
- [ÇIKARIM] BİGR ile SD arasında ikisine birlikte uyumu imkânsız kılan doğrudan bir çelişki tespit edilmemiştir. [ÇIKARIM] Bağlayıcı metinler arasındaki çatışmalar BSEY karşılaştırmasında ortaya çıkmaktadır.
- [ÇIKARIM] Üçlü karşılaştırmada 25 çatışma kaydedilmiştir: 3 kritik, 8 yüksek, 11 orta, 3 düşük. [ÇIKARIM] Bunların 16'sı kümülatif uyumla çözülmektedir; 6'sında HUKUK GÖRÜŞÜ GEREKİR (03 dosyası).
- [ÇIKARIM] DY'nin geçici 1 inci maddesi geçiş döneminde ölçütü BİGR'e bağlamaktadır (DY-G01-06). [ÇIKARIM] Bu nedenle SD m.26–71 ve geçici maddelerindeki 236 yükümlülük biriminin 76'sı bu dönemde ölçütsüz, 53'ü ise kısmen ölçülebilir kalmaktadır (04 dosyası, SD Denetlenebilirlik Matrisi).
- [ÇIKARIM] Faz 1 rubriğinde kritik önemdeki değerlendirme birimleri DY'de 3, SD'de 2'dir. [ÇIKARIM] DY'de ölçülebilirlik ortalaması 0,81'dir (0–3 ölçeği; 01 dosyası, Özet).
- [ÇIKARIM] Dört güncel konu üç metinde de düzenlenmemiştir; terim aramaları 0 eşleşme vermiştir. [ÇIKARIM] Bu konular kuantum sonrası kriptografi, kimlik avına dayanıklı çok faktörlü doğrulama, sentetik medya destekli sosyal mühendislik ve fidye yazılımına özgü hazırlıktır. [ÇIKARIM] Büyük dil modeli/ajan riskleri ile SaaS/OAuth yönetimi ise yalnız kısmen karşılanmaktadır (03 dosyası, Üçünde de Eksik).

## Kritik çatışmalar

- [BULGU] **C-01 – Kanunla korunan sırlar.** DY-010-01-b bilgi talebini "ticari sır veya gizlilik kısıtlaması olmaksızın" kapsamaktadır. [BULGU] BSEY-010-01 ise müşteri sırrı niteliğindeki bilgilerin "Kanunda yer alan istisnai haller haricinde" üçüncü kişilerle paylaşılamayacağını hükme bağlamaktadır. [DEĞERLENDİRME] Kanunlar arası ilişki için HUKUK GÖRÜŞÜ GEREKİR; saklılık ve gizlilik usulü önerilmiştir (O-DY-03, O-SD-02).
- [ÇIKARIM] **C-02 – Kritik altyapı verisinin yurt dışına aktarımı.** SD m.58(2) ile BSEY m.25(4) farklı istisna rejimleri öngörmektedir. [DEĞERLENDİRME] Sektörel istisnaların saklı tutulması önerilmiştir (O-SD-11).
- [ÇIKARIM] **C-20 – Yürürlük ile ölçüt yayımı arasındaki boşluk.** SD yükümlülükleri yürürlüğe girdiğinde, bu yükümlülüklere özgü denetim ölçütü henüz yayımlanmamış olabilir. [DEĞERLENDİRME] Ölçütlerin yürürlükten önce yayımlanması ve genel bir çatışma çözüm kuralı önerilmiştir (O-DY-16, O-SD-16).

## Öncelikli 10 öneri

1. [DEĞERLENDİRME] O-DY-16 (DY geçici m.1, Kritik): SD'ye özgü ölçütlerin yürürlükten önce yayımlanması ve tanım önceliğinin belirlenmesi.
2. [DEĞERLENDİRME] O-SD-16 (SD yeni geçici madde, Kritik): Sektörel düzenlemelerle çatışmada genel çözüm kuralı.
3. [DEĞERLENDİRME] O-DY-03 (DY m.10, Kritik): Kanunla korunan sırlar için gerekçeli gizlilik itirazı ve süre.
4. [DEĞERLENDİRME] O-SD-02 (SD m.19, Kritik): Kanun hükümlerinin saklılığı.
5. [DEĞERLENDİRME] O-DY-10 (DY m.22, Kritik): Acil müdahalede süre, gerekçe ve bildirim şartları.
6. [DEĞERLENDİRME] O-SD-11 (SD m.58, Kritik): Yurt dışı aktarımda sektörel istisna usulü.
7. [DEĞERLENDİRME] O-DY-07 (DY yeni m.17/A, Yüksek): Diğer denetimlerle karşılıklı tanıma ve kanıt paylaşımı (C-06, C-09, C-10).
8. [DEĞERLENDİRME] O-SD-08 (SD m.52 ve m.71, Yüksek): Belgelendirme ile düzenleyici denetimin karşılıklı tanınması.
9. [DEĞERLENDİRME] O-DY-15 (DY m.34, Yüksek): Teknik rehberlerin bağlayıcılık düzeyi; BİGR'in tavsiye kipi (C-19).
10. [DEĞERLENDİRME] O-SD-06 (SD m.42, Yüksek): Log saklama süresinde daha uzun sektörel sürelerin saklılığı (C-03).

## Doğrulama ve sınırlar

- [ÇIKARIM] Programatik kontroller 7.457 birebir metin hücresini/parçasını, formlardaki 68 taslak metin paragrafını ve 386 alıntıyı doğrulamıştır. [ÇIKARIM] Hiçbirinde uyumsuzluk bulunmamıştır. [ÇIKARIM] Anılan 1.890 Kaynak_ID'nin tamamı envanterde mevcuttur (06_QA_Raporu).
- [ÇIKARIM] Uzman kararı verilmemiş eşlemelerden alınan %10'luk örneklemde ikinci geçiş, ilk geçişle 66 satırın 58'inde uyumludur. [ÇIKARIM] Kalan 8 satır uzman incelemesine bırakılmıştır.
- [ÇIKARIM] Doğrulanamayan 12 konu 06_QA_Raporu'nda listelenmiştir. [ÇIKARIM] Bunlar arasında 7545 ve 5411 sayılı Kanunlar, İSEDES Yönetmeliği, BİGR Denetim Rehberi, BSEY'in 2020 sonrası değişiklik durumu ve BİGR EK-A matrisi bulunmaktadır.
- [ÇIKARIM] BİGR tedbirlerinin yaklaşık 590'ında eşleme, alt başlık varsayılanı ile en yakın aday birimin birleşimine dayanır. [ÇIKARIM] Bu eşlemeler tedbir bazında tek tek uzman doğrulamasından geçmemiştir.
- [ÇIKARIM] Uluslararası eşlemeler yalnız çerçeve düzeyinde verilmiştir (NIST CSF 2.0 işlevi, CIS Controls v8.1 kontrol başlığı). [ÇIKARIM] Kontrol kimliği düzeyindeki eşlemeler DOĞRULANMALI olarak işaretlenmiştir.
