# Siber güvenlik mevzuatı değerlendirmesi

24 Kasım 2026 · Kurumdan bağımsız çalışma

## Bulgular ve karar gerektiren konular

- [DEĞERLENDİRME] A (R3) [SRC-BIGR, SRC-SD, SRC-DY, SRC-BSEY]. Envanter **2.014 kayıttan** oluşuyor: BİGR 683 (660 tedbir), SD 573, DY 316, BSEY 442.
- [DEĞERLENDİRME] A (R5) [SRC-BIGR, SRC-SD, SRC-DY, SRC-BSEY]. Çatışma ve öncelik kaydındaki **21 konunun 8’inde hukuki öncelik belirsiz** ve görüş havuzunda 12 DY ile 5 doğrudan SD önerisi var.
- [ÇIKARIM] [DY-010-01-b, DY-010-04, SD-019-04, BSEY-010-01] (Ç-01). Bilgi isteme yetkisi ve sır saklılığı, hangi verinin kime ve hangi güvenli usulle açılabileceğinin her denetim talebinde belirlenmesini gerektiriyor.
- [ÇIKARIM] [DY-026-02, DY-027-01, BSEY-029-08, BSEY-031-01] (Ç-16). Dış hizmetle yürütülen öz denetim bankanın kendi iç denetimini de üstleniyorsa, iki hükmün aynı faaliyet üzerindeki etkisi için **HUKUK GÖRÜŞÜ GEREKİR**.
- [ÇIKARIM] [SD-027-01, SD-033-01, SD-033-02, SD-033-05, BSEY-018-05] (Ç-11). Olay bildirimi karşılaştırması, ilk tespit, ilk bildirim, olay seviyesi ve sektörel muhatap için ayrı kayıtlar gerektiriyor.
- [ÇIKARIM] [BIGR-3.1.8.2, SD-042-03, BSEY-013-03] (Ç-17). BSEY’de sayılan iz kayıtlarının beş yıllık saklama şartı, bu kategorilerin SD’deki iki yıllık kapsamla çakıştığı yerlerde de kendi kategorileri için geçerli.
- [HARİCİ] [SRC-BSEY, SRC-BSEY46, SRC-UYAP]. BSEY envanterindeki 442 kayıt, Adalet Bakanlığının 24.11.2026 tarihli UYAP sorgusunda dönen 105185 kimlikli birleşik metinle eşleşti ve değişiklik cetveli 46. maddenin 20.06.2020/31161 değişikliğini gösterdi. [İlk yayım](https://www.resmigazete.gov.tr/eskiler/2020/03/20200315-10.htm) · [Değişiklik](https://www.resmigazete.gov.tr/eskiler/2020/06/20200620-1.htm) · [UYAP Mevzuat](https://mevzuat.adalet.gov.tr/)

## Öncelikli 10 düzenleme önerisi

1. [DEĞERLENDİRME] A (R6) [DY-010-01-b, DY-010-04, BSEY-010-01] (G-01). Korunan sırlar için yazılı yetki dayanağı, yetkili alıcı ve güvenli inceleme usulü belirleyin.
2. [DEĞERLENDİRME] A (R5, R6) [DY-027-01, BSEY-029-08] (G-12). Sektörel dış hizmet yasaklarını saklı tutun ve görevlendirme kapsamını belgeleyin.
3. [DEĞERLENDİRME] A (R6) [DY-019-05, DY-032-01] (G-05). Taslak bulguya karşı savunma ile yaptırım savunmasının bildirim ve süre başlangıçlarını ayrı kayda bağlayın.
4. [DEĞERLENDİRME] B (R7, R9) [DY-014-07, DY-013-02] (G-02). Canlı sisteme uzaktan erişimde işlem kapsamı, oturum kaydı ve güvenli durdurma koşulunu belirleyin.
5. [DEĞERLENDİRME] A (R5) [DY-017-03, DY-012-04, BSEY-031-01] (G-03). Sektörel raporlar için kapsam, dönem, bağımsızlık ve kanıt eşdeğerliği ölçütü tanımlayın.
6. [DEĞERLENDİRME] A (R3) [DY-018-03, DY-018-04, SD-064-02] (G-04). Kanıtın edinimden erişim, devir, saklama ve imhaya kadar izini zorunlu kılın.
7. [DEĞERLENDİRME] A (R2, R5) [DY-029-04-ç, SD-027-01, SD-033-05, BSEY-018-05] (G-11, SDG-01). Ortak olay kimliğini kullanın ve bildirim süresini başlatan olayları muhatap bazında tanımlayın.
8. [DEĞERLENDİRME] B (R7, R9) [DY-022-04, DY-022-05, SD-065-02] (G-06). Acil tedbirin hizmet etkisini, gözden geçirme koşulunu ve kaldırma kararını kaydedin.
9. [DEĞERLENDİRME] A (R1, R5) [DY-G001-06, DY-G001-07, BIGR-2.3.2] (G-10). Eski ve yeni ölçütleri yürürlük, denetimin başlangıcı ve sürüm bilgisiyle eşleyen geçiş çizelgesi yayımlayın.
10. [DEĞERLENDİRME] B (R8, R9) [SD-051-06, BIGR-3.1.13.4, BIGR-3.1.13.5] (SDG-03). Yedek değiştirilemezliğini koruma, yetki ayrımı, izolasyon ve geri dönüş testiyle tanımlayın.

## Kapsam ve doğrulama

- [DEĞERLENDİRME] A (R3, R5) [SRC-BIGR, SRC-SD, SRC-BSEY]. Satır kapsamı tam ve uzman eşleme incelemesi 121/660 BİGR, 139/497 SD ve 56/442 BSEY kaydında tamamlandı.
- [DEĞERLENDİRME] A/B (R1–R12) [SRC-BIGR, SRC-SD, SRC-DY, SRC-BSEY]. 24.168 rubrik hücresinin 3.495’i gerekçeli ön puan içeriyor ve 20.673’ü açık.
- [DEĞERLENDİRME] A (R3) [SRC-BIGR, SRC-SD, SRC-DY, SRC-BSEY, SRC-FORM]. 7.948 programatik metin ve alıntı karşılaştırmasında uyuşmazlık görülmedi ve bağımsız kör örneklem çalışması yapılamadı.
- [DEĞERLENDİRME] A (R5) [SRC-BIGR, SRC-DY, SRC-BSEY]. Ayrı BİGR Denetim Rehberi ile seçilmiş sektörel tebliğ sağlanmadığı için bunlara özgü ölçüt ve uygulanabilirlik kararları açık.
