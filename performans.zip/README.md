# WinPerfDiag

Windows 11 performans teşhis aracı. Domain ortamında, çok sayıda güvenlik ajanı
çalışan makinelerde yavaşlığın **nedenini** ölçümle isimlendirir.

Tek dosya PowerShell scripti. Harici modül veya bağımlılık yok.
**Standart kullanıcı yetkileriyle çalışır**; yönetici hakkı varsa ek ölçüm
kaynakları açılır ama gerekli değildir. Tüm veri yerelde kalır.

## Hızlı başlangıç

```powershell
# 0) Hangi ölçüm kaynağına erişebiliyorum? (hiçbir şey yazmaz, hiçbir şey ölçmez)
.\WinPerfDiag.ps1 -Mode Check

# 1) "Şu anda neden yavaş?" — 12 örnek, 5 sn aralık (~1 dk)
.\WinPerfDiag.ps1 -Mode Diag

# 2) Daha uzun ve sık örnekleme
.\WinPerfDiag.ps1 -Mode Diag -SampleCount 40 -Interval 3

# 3) "Aralıklı yavaşlığı yakala" — iş günü boyunca arka planda
.\WinPerfDiag.ps1 -Mode Monitor -Interval 30        # Ctrl-C ile bitir
.\WinPerfDiag.ps1 -Mode Monitor -Interval 30 -Duration 28800   # 8 saat

# 4) Yönetici hakkıyla (filtre yığınının gerçek yüklenme sırası + açılış olayları)
.\WinPerfDiag.ps1 -Mode Diag        # yükseltilmiş PowerShell içinde

# 5) Kaydedilmiş bir koşumdan raporu yeniden üret
.\WinPerfDiag.ps1 -Mode Report -InputFile .\winperfdiag-20260920-143000.json
```

Çıktı varsayılan olarak `%LOCALAPPDATA%\WinPerfDiag\` altına HTML + JSON olarak
düşer. `-OutFile` ile yol verebilir, `-Format Html` veya `-Format Json` ile
tek biçim seçebilirsiniz.

## Domain ortamında dağıtım — önce bunu okuyun

Kurumsal makinede scripti çalıştırmanın önünde iki engel olabilir:

**1. Yürütme ilkesi (ExecutionPolicy).** Önce kontrol edin:

```powershell
Get-ExecutionPolicy -List
```

`MachinePolicy` veya `UserPolicy` satırı `AllSigned` / `Restricted` ise,
`-ExecutionPolicy Bypass` bunu **geçemez** — GPO ile ayarlanan ilke komut
satırı parametresinden önceliklidir. Bu durumda tek yol scriptin kurumsal kod
imzalama sertifikanızla imzalanması veya BT tarafından istisna tanımlanmasıdır.
Yalnızca `LocalMachine` ayarlıysa şu çalışır:

```powershell
powershell.exe -ExecutionPolicy Bypass -File .\WinPerfDiag.ps1 -Mode Diag
```

**2. Kısıtlı dil modu (Constrained Language Mode).** AppLocker veya WDAC
uygulanmışsa PowerShell kısıtlı dil modunda çalışır. Script bunu gözeterek
yazıldı — `Add-Type` kullanılmaz, `New-Object` kullanılmaz, .NET tip erişimi
yalnızca kısıtlı modda da izin verilen tiplerle sınırlıdır. Tek istisna
`powercfg` çıktısındaki onaltılık değerin çevrilmesidir; kısıtlanırsa o tek
metrik eksik kalır, script çalışmaya devam eder.

`-Mode Check` çıktısında dil modu zaten raporlanır.

## Standart kullanıcı ile ne ölçülebiliyor

| Ölçüm | Standart kullanıcı | Not |
|---|---|---|
| Process başına CPU, bellek, disk işlemi | evet | `Win32_PerfRawData_PerfProc_Process` |
| DPC / kesme yüzdesi | evet | sürücü kaynaklı yükün tek göstergesi |
| Disk gecikmesi (ms) | evet | ham sayaçtan hesaplanır |
| İşlemci kuyruğu, bağlam değişimi | evet | |
| Bellek, commit, sabit sayfa hatası | evet | |
| **Minifilter altitude + sınıf** | **evet** | kayıt defterinden okunur |
| **Filtre sürücüsü çalışıyor mu** | **evet** | `Win32_SystemDriver.Started` |
| Servis, başlangıç öğesi, zamanlanmış görev | evet | |
| Güç planı, maksimum işlemci durumu | evet | |
| Disk doluluk, SSD/HDD ayrımı | evet | |
| Sistem olay günlüğü (Event ID 2004 vb.) | evet | |
| `fltmc filters` | **hayır** | yönetici; kayıt defteri ile telafi edilir |
| Açılış performansı olayları (ID 100–109) | genellikle hayır | yönetici |
| Grup İlkesi işleme süreleri | genellikle hayır | yönetici |

Yani **standart kullanıcıyla sizin senaryonuzun kalbi ölçülebiliyor**: hangi
dosya sistemi filtresinin yüklü ve çalışır olduğu, kaçının Anti-Virus sınıfında
olduğu, disk gecikmesinin kaç milisaniye olduğu ve DPC yüzdesinin ne kadar
yükseldiği. Yönetici hakkı bunların üstüne filtrelerin gerçek yüklenme sırasını
ve açılış olaylarını ekler.

## Üç tasarım kararı (yanlış yapılırsa araç sessizce yanlış sayı üretir)

**`Get-Counter` kullanılmıyor.** Türkçe Windows'ta performans sayacı isimleri de
Türkçedir (`\İşlemci(_Total)\...`). İngilizce sayaç adı kullanan her script bu
makinelerde patlar. Bunun yerine `Win32_PerfRawData_*` CIM sınıfları
kullanılıyor — bu sınıfların özellik adları işletim sistemi dilinden bağımsız
olarak İngilizcedir.

**`Win32_PerfFormattedData_PerfDisk_LogicalDisk.AvgDisksecPerRead`
kullanılmıyor.** Bu alan `UInt32` ve saniye cinsinden; 8 ms'lik gerçek bir
gecikme orada **0** görünür. AV taramasının en net kanıtı tam olarak bu metrik
olduğu için ham sayaçtan `PERF_AVERAGE_TIMER` formülüyle hesaplanıyor:
`((N₁−N₀) ÷ frekans) ÷ (B₁−B₀)`.

**Minifilter sınıflandırması altitude numarasından çıkarılmıyor.** Kayıt
defterindeki `Group` değeri zaten `"FSFilter Anti-Virus"` gibi açık yazıyor;
tahmin yerine o okunuyor. Altitude yalnızca sıralama için kullanılıyor.

Ayrıca: `Win32_Product` **asla** sorgulanmıyor — o sınıf her sorguda MSI yeniden
yapılandırma tetikler ve kendisi yavaşlığa sebep olur.

Yerelleştirme kaynaklı iki tuzak daha kapatıldı: maksimum işlemci durumu
`powercfg` çıktısından hiç ayrıştırılmıyor — o çıktı hem Türkçeleşmiş hem de
gerçek değerden önce "Minimum Possible Setting" satırını içeriyor; değer kayıt
defterinden (`...\Control\Power\User\PowerSchemes\<GUID>\54533251-...\bc5038f7-...`)
okunuyor. Sürücü durumu için ise yerelleştirilebilen `State` metni yerine dil
bağımsız `Started` (boolean) alanı kullanılıyor.

## Raporu nasıl okumalı

Rapor 11 bölümdür ve **her bölümün başında "Neden bakıyoruz" açıklaması** vardır:
o bölümün hangi soruyu cevapladığı ve bulgunun nasıl yorumlanacağı. 2. bölüm
rapordaki her terimin ne anlama geldiğini açıklayan sözlüktür.

### Her satır tek bir process'tir

Suçlu tablosunda **gruplama yoktur**. Aynı programın her kopyası ayrı satırdır:

```
svchost   PID 5002   CPU %2.5   RAM 700 MB   disk 900 işlem/sn
svchost   PID 5001   CPU %0.25  RAM  60 MB   disk   5 işlem/sn
```

Gruplansaydı tek bir "svchost: %2.75" satırı görürdünüz ve hangi kopyanın sorun
çıkardığını bulamazdınız. Aynı şey chrome sekmeleri ve antivirüs alt süreçleri
için de geçerlidir.

### Değişim sütunu belirleyicidir

"En çok tüketen" ile "yavaşlığın nedeni" aynı şey değildir. Araç her process için
yavaşlık anındaki ortalamayı normal dönemdekiyle karşılaştırır ve farkı **cümle
olarak** yazar:

| Değişim metni | Anlamı |
|---|---|
| `+8.88 puan CPU — yavaşlık anında ARTTI` | Yavaşlık anında daha çok çalışmış. **Güçlü aday.** |
| `değişmedi` | Sürekli aynı yükü üretiyor. Makine normalken de aynı yükteydi ama o zaman yavaşlık yoktu — muhtemelen suçlu değil. |
| `-27 işlem/sn — yavaşlık anında AZALDI` | Yavaşlık anında daha az iş yapabilmiş. Bu process diski **bekliyor** demektir: sebep değil, **kurban**. |
| `karşılaştırılamadı (normal dönem yok)` | Tüm ölçümler yavaş dönemde geçti, kıyas noktası yok. |

Sentetik testten gerçek çıktı:

```
hog_app          %9    normal %0.12   +8.88 puan CPU — yavaşlık anında ARTTI   -> suçlu
CSFalconService  %1    normal %1      değişmedi                                -> CPU'da masum
explorer     13 işl/sn normal 40      -27 işlem/sn — yavaşlık anında AZALDI    -> kurban
```

Aynı CrowdStrike process'i disk tablosunda 4500 işlem/sn ile tepededir: CPU'da
masum, I/O'da baskın.

### "Neden yavaştı" sütunu

YAVAŞ işaretli her satırın yanında nedeni düz Türkçe yazar:

```
06:01:00  0.63  YAVAŞ  RAM yetersizliği — boş RAM yalnızca 500 MB kaldı (toplamın
                       %3.05'i); saniyede 300 kez RAM'de bulunamayan veri diskten
                       okunuyor (takas)  |  CPU doluluğu — işlemci %95 dolu  |
                       CPU sırası — 28 iş işlemci sırasında bekliyor
```

### Terimler

"Bellek baskısı / memory pressure" gibi Türkçede karşılığı olmayan terimler
kullanılmaz. Bunun yerine:

| Kullanılan | Ne demek |
|---|---|
| **RAM yetersizliği** | Boş RAM tükenmiş. Windows çalışan programların belleğini diske yazıp yer açıyor; o programa dönüldüğünde diskten geri okuyor. Disk RAM'den binlerce kat yavaş olduğu için her geçiş beklemeye dönüşüyor. Kullanıcı bunu "pencereler arası geçişte donma" olarak hisseder. |
| **Sürücü yükü (DPC + kesme)** | Hiçbir programda görünmeyen, sürücülerden gelen yük. Normal %1–2. Üst üste binmiş dosya sistemi filtreleri ve ağ sürücüleri tipik kaynaktır. |
| **Disk yanıt süresi** | Diskin isteklere kaç ms'de cevap verdiği. NVMe 1–2 ms, SATA SSD 2–5 ms normal; 15 ms üzeri sorunlu. |
| **CPU sırası** | Çekirdek başına kaç işin sırada beklediği. İşlemci boş olmasa bile asıl sorun budur: tıkladığınız şey hemen başlamaz. |
| **Şüphe skoru** | Sıralama içindir, mutlak anlamı yoktur. Yük × yavaş anlarda görülme oranı × artış katsayısı. |

### İşlemci hızı: ayar okuması ile ölçüm ayrılmıştır

İlk sürümde yalnızca güç planı ayarına bakılıp "CPU tam hıza çıkamaz" deniyordu.
**Bu hataydı ve düzeltildi.** Üç nedenle:

1. Değer `powercfg` çıktısından ayrıştırılıyordu. O çıktı gerçek değerden önce
   `Minimum Possible Setting: 0x00000000` satırını içerir; sırasal ayrıştırma
   **%0** gibi tamamen yanlış sonuç üretiyordu. Artık değer kayıt defterinden
   okunuyor (dil bağımsız, adresi belli) ve 5–100 aralığı dışındaki değerler
   "ayrıştırma hatası" sayılıp atılıyor.
2. Windows 11'de işlemci hızı çoğunlukla donanım tarafından yönetilir (Intel
   Speed Shift / AMD CPPC); bu ayar fiilen uygulanmıyor olabilir.
3. **En önemlisi:** işlemci boştayken düşük frekansta çalışması NORMALDİR, hatta
   istenen davranıştır. Yük yokken 900 MHz görmek sorun değildir.

Artık iki şey ayrı raporlanır: **(a)** ayarın okunan değeri — iddia değil, kayıt;
**(b)** işlemci %60'ın üzerinde yüklüyken ölçülen gerçek hız — asıl kanıt. Ayar
sınırlı görünüyor ama ölçüm bunu doğrulamıyorsa rapor bunu açıkça yazar ve
ciddiyeti düşürür. Ölçüm düşüklüğü doğruluyorsa alternatif açıklamalar
(termal kısıtlama, firmware, pil modu) da listelenir.

### Ölçülemeyenler

"Sorun yok" demek değildir, "ölçülmedi" demektir. Erişilemeyen her kaynak nedeni
ile birlikte raporda listelenir.

## Bulgular eyleme nasıl dönüşür

Filtre yığını bulgusu çıktığında hedef ajanları kaldırmak değildir — politika
gereği zaten kaldırılamazlar. Hedef, **karşılıklı istisna (exclusion)**
tanımlamaktır: derleme dizinleri, sanal makine imajları, kod depoları,
veritabanı dosyaları ve yoğun I/O üreten uygulama klasörleri. Raporun disk
işlemi tablosu, hangi process'in hangi yükü ürettiğini BT ekibine somut sayıyla
gösterdiği için bu talebin dayanağı olur.

Maksimum işlemci durumu %100'ün altındaysa bu bir GPO ayarıdır; kullanıcı
değiştiremez, BT tarafından düzeltilmesi gerekir. Tek satırlık bir bulgu olduğu
halde etkisi sistem genelinde hissedilir.

## Doğrulama durumu

PowerShell 7.4.6 ile **64 sentetik test** yazıldı ve tamamı geçiyor:

| Test grubu | Kapsam |
|---|---|
| Sayaç matematiği | `PERF_AVERAGE_TIMER` = 8 ms, `PERF_100NSEC_TIMER` = %20, sayaç sarması, sıfır bölen → `null` |
| Örnek türetme | CPU %90, sürücü yükü %8, ayrılmış bellek %93.75, çekirdek sayısına bölme |
| Ajan kataloğu | katalog eşleşmesi, imzadan çözümleme, sivil process'te yanlış pozitif yok |
| Yavaş dönem + atıf | doğru suçlu birinci, sabit yüklü ajan suçlanmıyor, I/O'da ajan tepede |
| **Gruplama yok** | aynı exe'nin iki kopyası ayrı satır, her satır kendi PID'i, farklı metrikler |
| **Değişim metni** | ARTTI / AZALDI / değişmedi doğru üretiliyor, çıplak sayı değil cümle |
| Ajan vergisi | sağlayıcı tespiti, CPU/IO payı, kategori kırılımı, **her ajan satırında metrikler** |
| **İşlemci hızı** | yük altında düşük hız → bulgu var; boştayken düşük hız → **bulgu yok** (yanlış pozitif testi) |
| Bulgu üretimi | güç planı, filtre yığını, HDD, Event 2004, sürücü yükü, durdurulmuş filtre hariç tutma |
| HTML rapor | her bölümde "Neden bakıyoruz", sözlük, "Neden yavaştı" sütunu dolu, fark açıklaması, "bellek basıncı" terimi yok |
| Bozulma davranışı | hiçbir Windows API'si olmadan çökmeden çalışma |

Testler geliştirme sırasında **beş gerçek hata buldu**: (1) script parametresi
`$Samples` ile örnek dizisi değişkeninin ad çakışması — PowerShell değişken
adları büyük/küçük harf duyarsız olduğu için tehlikeli bir tuzak; (2)
`Join-Path $env:LOCALAPPDATA` değişken tanımsızsa tüm scripti düşürüyordu;
(3) `powercfg` çıktısının sırasal ayrıştırılması "Minimum Possible Setting"i
okuyup maksimum işlemci durumunu **%0** raporluyordu; (4) `Get-SlowReason`
fonksiyonu iki kez tanımlanmıştı ve ikincisi birincisini eziyordu; (5)
`Get-Findings` çağrısında `-SampleList` iki kez geçiyordu ve bulgu üretimi
sessizce tamamen başarısız oluyordu.

Testleri çalıştırmak için: `.\Test-WinPerfDiag.ps1`

### Doğrulanamayanlar — gerçek makinede ilk koşumda bakılacaklar

Bu ortamda Windows yoktu; aşağıdaki altı nokta **kör yazıldı**:

1. `Win32_PerfRawData_PerfProc_Process` standart kullanıcıya açık mı — WMI
   namespace ACL'leri GPO ile sıkılaştırılmış olabilir
2. `Services\<ad>\Instances\<DefaultInstance>\Altitude` standart kullanıcıya
   okunabiliyor mu — bazı EDR'ler kendi servis anahtarlarını korur
3. Maksimum işlemci durumunun kayıt defterindeki yolu ve `ACSettingIndex`
   değerinin standart kullanıcıya okunabilirliği; ayrıca GPO ile dayatılmış
   güç ayarının `HKLM\SOFTWARE\Policies\Microsoft\Power\PowerSettings`
   altındaki yerleşimi
   (bu okunamazsa rapor "okunamadı" der, yanlış sayı üretmez)
4. `Get-ScheduledTask` tetikleyici sınıf adlarının eşleşmesi
5. `Win32_SystemDriver.Started` alanının minifilter sürücüleri için doğru
   dolması
6. `Win32_PerfFormattedData_Counters_ProcessorInformation` sınıfının
   `PercentProcessorPerformance` alanını sağlaması (yoksa
   `PercentofMaximumFrequency` denenir, o da yoksa hız ölçümü atlanır)
7. `Microsoft-Windows-Diagnostics-Performance/Operational` kanalının sizin
   GPO yapılandırmanızda etkin olup olmadığı

İlk koşumda `-Mode Check` çalıştırın; kapalı çıkan kaynak olursa `-Mode Diag`
çıktısındaki "Erişilemeyenler" bölümünü bana getirin, o noktaları gerçek
çıktıya göre düzeltirim. Bu yedi madde netleşmeden rapordaki sayıları mutlak
doğru kabul etmeyin.

## Dosyalar

```
WinPerfDiag.ps1        ana script (tek dosya, UTF-8 BOM ile — PS 5.1 gerektirir)
Test-WinPerfDiag.ps1   sentetik doğrulama paketi (36 test)
ornek-rapor.html       sentetik veriyle üretilmiş örnek rapor
```

Script UTF-8 **BOM ile** kaydedilmiştir; PowerShell 5.1 Türkçe karakterleri
ancak BOM varsa doğru okur. Dosyayı kopyalarken veya e-postayla taşırken
kodlamanın korunduğundan emin olun.
