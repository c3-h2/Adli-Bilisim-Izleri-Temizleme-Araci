# WinPerfDiag

Windows 11 performans teşhis aracı. Domain ortamında, çok sayıda güvenlik ajanı
çalışan makinelerde yavaşlığın **nedenini** ölçümle isimlendirir.

Tek dosya PowerShell scripti. Harici modül veya bağımlılık yok.
**Standart kullanıcı yetkileriyle çalışır**; yönetici hakkı varsa ek ölçüm
kaynakları açılır ama gerekli değildir. Tüm veri yerelde kalır.

## Hızlı başlangıç

```powershell
# 0) Hangi ölçüm kaynağına erişebiliyorum? (hiçbir şey yazmaz, hiçbir şey ölçmez)
.\WinPerfDiag.ps1 -Mode Check

# 1) "Şu anda neden yavaş?" — 12 örnek, 5 sn aralık (~1 dk)
.\WinPerfDiag.ps1 -Mode Diag

# 2) Daha uzun ve sık örnekleme
.\WinPerfDiag.ps1 -Mode Diag -SampleCount 40 -Interval 3

# 3) "Aralıklı yavaşlığı yakala" — iş günü boyunca arka planda
.\WinPerfDiag.ps1 -Mode Monitor -Interval 30        # Ctrl-C ile bitir
.\WinPerfDiag.ps1 -Mode Monitor -Interval 30 -Duration 28800   # 8 saat

# 4) Yönetici hakkıyla (filtre yığınının gerçek yüklenme sırası + açılış olayları)
.\WinPerfDiag.ps1 -Mode Diag        # yükseltilmiş PowerShell içinde

# 5) Kaydedilmiş bir koşumdan raporu yeniden üret
.\WinPerfDiag.ps1 -Mode Report -InputFile .\winperfdiag-20260920-143000.json
```

Çıktı varsayılan olarak `%LOCALAPPDATA%\WinPerfDiag\` altına HTML + JSON olarak
düşer. `-OutFile` ile yol verebilir, `-Format Html` veya `-Format Json` ile
tek biçim seçebilirsiniz.

## Domain ortamında dağıtım — önce bunu okuyun

Kurumsal makinede scripti çalıştırmanın önünde iki engel olabilir:

**1. Yürütme ilkesi (ExecutionPolicy).** Önce kontrol edin:

```powershell
Get-ExecutionPolicy -List
```

`MachinePolicy` veya `UserPolicy` satırı `AllSigned` / `Restricted` ise,
`-ExecutionPolicy Bypass` bunu **geçemez** — GPO ile ayarlanan ilke komut
satırı parametresinden önceliklidir. Bu durumda tek yol scriptin kurumsal kod
imzalama sertifikanızla imzalanması veya BT tarafından istisna tanımlanmasıdır.
Yalnızca `LocalMachine` ayarlıysa şu çalışır:

```powershell
powershell.exe -ExecutionPolicy Bypass -File .\WinPerfDiag.ps1 -Mode Diag
```

**2. Kısıtlı dil modu (Constrained Language Mode).** AppLocker veya WDAC
uygulanmışsa PowerShell kısıtlı dil modunda çalışır. Script bunu gözeterek
yazıldı — `Add-Type` kullanılmaz, `New-Object` kullanılmaz, .NET tip erişimi
yalnızca kısıtlı modda da izin verilen tiplerle sınırlıdır. Tek istisna
`powercfg` çıktısındaki onaltılık değerin çevrilmesidir; kısıtlanırsa o tek
metrik eksik kalır, script çalışmaya devam eder.

`-Mode Check` çıktısında dil modu zaten raporlanır.

## Standart kullanıcı ile ne ölçülebiliyor

| Ölçüm | Standart kullanıcı | Not |
|---|---|---|
| Process başına CPU, bellek, disk işlemi | evet | `Win32_PerfRawData_PerfProc_Process` |
| DPC / kesme yüzdesi | evet | sürücü kaynaklı yükün tek göstergesi |
| Disk gecikmesi (ms) | evet | ham sayaçtan hesaplanır |
| İşlemci kuyruğu, bağlam değişimi | evet | |
| Bellek, commit, sabit sayfa hatası | evet | |
| **Minifilter altitude + sınıf** | **evet** | kayıt defterinden okunur |
| **Filtre sürücüsü çalışıyor mu** | **evet** | `Win32_SystemDriver.Started` |
| Servis, başlangıç öğesi, zamanlanmış görev | evet | |
| Güç planı, maksimum işlemci durumu | evet | |
| Disk doluluk, SSD/HDD ayrımı | evet | |
| Sistem olay günlüğü (Event ID 2004 vb.) | evet | |
| `fltmc filters` | **hayır** | yönetici; kayıt defteri ile telafi edilir |
| Açılış performansı olayları (ID 100–109) | genellikle hayır | yönetici |
| Grup İlkesi işleme süreleri | genellikle hayır | yönetici |

Yani **standart kullanıcıyla sizin senaryonuzun kalbi ölçülebiliyor**: hangi
dosya sistemi filtresinin yüklü ve çalışır olduğu, kaçının Anti-Virus sınıfında
olduğu, disk gecikmesinin kaç milisaniye olduğu ve DPC yüzdesinin ne kadar
yükseldiği. Yönetici hakkı bunların üstüne filtrelerin gerçek yüklenme sırasını
ve açılış olaylarını ekler.

## Üç tasarım kararı (yanlış yapılırsa araç sessizce yanlış sayı üretir)

**`Get-Counter` kullanılmıyor.** Türkçe Windows'ta performans sayacı isimleri de
Türkçedir (`\İşlemci(_Total)\...`). İngilizce sayaç adı kullanan her script bu
makinelerde patlar. Bunun yerine `Win32_PerfRawData_*` CIM sınıfları
kullanılıyor — bu sınıfların özellik adları işletim sistemi dilinden bağımsız
olarak İngilizcedir.

**`Win32_PerfFormattedData_PerfDisk_LogicalDisk.AvgDisksecPerRead`
kullanılmıyor.** Bu alan `UInt32` ve saniye cinsinden; 8 ms'lik gerçek bir
gecikme orada **0** görünür. AV taramasının en net kanıtı tam olarak bu metrik
olduğu için ham sayaçtan `PERF_AVERAGE_TIMER` formülüyle hesaplanıyor:
`((N₁−N₀) ÷ frekans) ÷ (B₁−B₀)`.

**Minifilter sınıflandırması altitude numarasından çıkarılmıyor.** Kayıt
defterindeki `Group` değeri zaten `"FSFilter Anti-Virus"` gibi açık yazıyor;
tahmin yerine o okunuyor. Altitude yalnızca sıralama için kullanılıyor.

Ayrıca: `Win32_Product` **asla** sorgulanmıyor — o sınıf her sorguda MSI yeniden
yapılandırma tetikler ve kendisi yavaşlığa sebep olur.

Yerelleştirme kaynaklı iki tuzak daha kapatıldı: `powercfg` çıktısı Türkçe
olduğu için etiket metnine göre değil `0x` değerlerinin sırasına göre okunuyor;
sürücü durumu için yerelleştirilebilen `State` metni yerine dil bağımsız
`Started` (boolean) alanı kullanılıyor.

## Raporu nasıl okumalı

**Fark sütunu belirleyicidir.** "En çok tüketen" ile "yavaşlığın nedeni" aynı
şey değildir. Sürekli %4 CPU yiyen bir EDR ajanı, yavaşlık anlarında da
%4'tedir — nedensel bağı yoktur. Araç her process için yavaş pencerelerdeki
ortalamayı normal pencerelerdekiyle karşılaştırır ve yalnızca **yükselen**
process'i aday olarak öne çıkarır. Örnek rapordaki tablo:

```
hog_app          yavaş %9   normal %0.12  fark +8.88   -> gerçek suçlu
CSFalconService  yavaş %1   normal %1     fark  0.00   -> gürültü (CPU'da)
```

Aynı CrowdStrike process'i disk işlemi tablosunda 4500 işlem/sn ile tepededir.
Bu, CPU'da masum ama I/O'da baskın olduğu anlamına gelir — sizin senaryonuzda
aranan tam olarak bu ayrımdır.

**DPC + kesme yüzdesi ayrı bir bileşendir.** Bu yük hiçbir kullanıcı
process'inde görünmez; sürücü kaynaklıdır. İstemci makinede normal değer
%1–2'dir. %9–10 ve üzeri, üst üste binmiş dosya sistemi filtrelerinin,
ağ filtre sürücülerinin veya eski depolama sürücülerinin parmak izidir.

**Disk gecikmesi.** NVMe SSD'de 1–2 ms, SATA SSD'de 2–5 ms beklenir. Sürekli
15 ms üzeri ya donanım sorunudur ya da her I/O işlemini inceleyen bir filtre
yığını.

**Ajan yükü bölümü ajanların doğrudan tükettiğidir.** Minifilter sürücülerinin
çekirdek modunda ürettiği gecikme oraya yansımaz — o yük, kurban uygulamaların
(Explorer, derleyici, Office) I/O bekleme süresi ve DPC yüzdesi olarak görünür.
Bu yüzden iki bölümü birlikte okumak gerekir.

**Ölçülemeyenler listesi "sorun yok" demek değildir, "ölçülmedi" demektir.**
Erişilemeyen her kaynak nedeniyle birlikte raporda listelenir.

## Bulgular eyleme nasıl dönüşür

Filtre yığını bulgusu çıktığında hedef ajanları kaldırmak değildir — politika
gereği zaten kaldırılamazlar. Hedef, **karşılıklı istisna (exclusion)**
tanımlamaktır: derleme dizinleri, sanal makine imajları, kod depoları,
veritabanı dosyaları ve yoğun I/O üreten uygulama klasörleri. Raporun disk
işlemi tablosu, hangi process'in hangi yükü ürettiğini BT ekibine somut sayıyla
gösterdiği için bu talebin dayanağı olur.

Maksimum işlemci durumu %100'ün altındaysa bu bir GPO ayarıdır; kullanıcı
değiştiremez, BT tarafından düzeltilmesi gerekir. Tek satırlık bir bulgu olduğu
halde etkisi sistem genelinde hissedilir.

## Doğrulama durumu

PowerShell 7.4.6 ile **36 sentetik test** yazıldı ve tamamı geçiyor:

| Test grubu | Kapsam |
|---|---|
| Sayaç matematiği | `PERF_AVERAGE_TIMER` = 8 ms, `PERF_100NSEC_TIMER` = %20, sayaç sarması, sıfır bölen → `null` |
| Örnek türetme | CPU %90, DPC %8, commit %93.75, çekirdek sayısına bölme, bellek MB |
| Ajan kataloğu | katalog eşleşmesi, imzadan çözümleme, sivil process'te yanlış pozitif yok |
| Yavaş pencere + atıf | doğru suçlu birinci, sabit yüklü ajan suçlanmıyor, I/O'da ajan tepede |
| Ajan vergisi | sağlayıcı tespiti, CPU/IO payı, kategori kırılımı |
| Bulgu üretimi | güç planı, filtre yığını, HDD, Event 2004, DPC, durdurulmuş filtre hariç tutma |
| HTML rapor | üretim, kapanış, Türkçe karakter korunumu, tablo içeriği |
| Bozulma davranışı | hiçbir Windows API'si olmadan çökmeden çalışma |

Testler geliştirme sırasında **iki gerçek hata buldu**: (1) script parametresi
`$Samples` ile örnek dizisi değişkeninin ad çakışması — PowerShell değişken
adları büyük/küçük harf duyarsız olduğu için tehlikeli bir tuzak, parametre
`$SampleCount` olarak yeniden adlandırıldı; (2) `Join-Path $env:LOCALAPPDATA`
değişken tanımsızsa param bloğunda bağlama hatası verip tüm scripti düşürüyordu.

Testleri çalıştırmak için: `.\Test-WinPerfDiag.ps1`

### Doğrulanamayanlar — gerçek makinede ilk koşumda bakılacaklar

Bu ortamda Windows yoktu; aşağıdaki altı nokta **kör yazıldı**:

1. `Win32_PerfRawData_PerfProc_Process` standart kullanıcıya açık mı — WMI
   namespace ACL'leri GPO ile sıkılaştırılmış olabilir
2. `Services\<ad>\Instances\<DefaultInstance>\Altitude` standart kullanıcıya
   okunabiliyor mu — bazı EDR'ler kendi servis anahtarlarını korur
3. `powercfg /query` çıktısında `0x` satır sırası (AC önce, DC sonra) Türkçe
   Windows'ta da geçerli mi
4. `Get-ScheduledTask` tetikleyici sınıf adlarının eşleşmesi
5. `Win32_SystemDriver.Started` alanının minifilter sürücüleri için doğru
   dolması
6. `Microsoft-Windows-Diagnostics-Performance/Operational` kanalının sizin
   GPO yapılandırmanızda etkin olup olmadığı

İlk koşumda `-Mode Check` çalıştırın; kapalı çıkan kaynak olursa `-Mode Diag`
çıktısındaki "Erişilemeyenler" bölümünü bana getirin, o noktaları gerçek
çıktıya göre düzeltirim. Bu altı madde netleşmeden rapordaki sayıları mutlak
doğru kabul etmeyin.

## Dosyalar

```
WinPerfDiag.ps1        ana script (tek dosya, UTF-8 BOM ile — PS 5.1 gerektirir)
Test-WinPerfDiag.ps1   sentetik doğrulama paketi (36 test)
ornek-rapor.html       sentetik veriyle üretilmiş örnek rapor
```

Script UTF-8 **BOM ile** kaydedilmiştir; PowerShell 5.1 Türkçe karakterleri
ancak BOM varsa doğru okur. Dosyayı kopyalarken veya e-postayla taşırken
kodlamanın korunduğundan emin olun.
