﻿<#
.SYNOPSIS
    WinPerfDiag - Windows 11 performans teshis araci (domain / cok ajanli ortamlar icin)

.DESCRIPTION
    Standart kullanici yetkileriyle calisir. Yonetici haklari varsa ek olcum
    kaynaklarini da acar, ancak gerekli degildir.

    Tasarim kararlari (onemli):
      * Get-Counter KULLANILMAZ. Turkce Windows'ta sayac isimleri de Turkcedir;
        Ingilizce isim kullanan scriptler o makinelerde calismaz. Bunun yerine
        Win32_PerfRawData_* CIM siniflari kullanilir -- bu siniflarin ozellik
        adlari isletim sistemi dilinden bagimsiz olarak Ingilizcedir.
      * Win32_PerfFormattedData_PerfDisk_LogicalDisk.AvgDisksecPerRead alani
        UInt32'dir ve saniye cinsindendir; 8 ms'lik gercek bir gecikme orada 0
        gorunur. Disk gecikmesi ham sayactan PERF_AVERAGE_TIMER formuluyle
        hesaplanir.
      * Minifilter siniflandirmasi altitude numarasindan CIKARILMAZ; kayit
        defterindeki Group degeri ("FSFilter Anti-Virus" gibi) dogrudan okunur.
      * Win32_Product ASLA sorgulanmaz -- MSI yeniden yapilandirma tetikler.

.NOTES
    PowerShell 5.1 uyumlu. Harici modul veya bagimlilik yoktur.
    Toplanan veri yerelde kalir; hicbir yere gonderilmez.
#>

[CmdletBinding()]
param(
    [ValidateSet('Check', 'Diag', 'Monitor', 'Report')]
    [string] $Mode = 'Diag',

    # DIKKAT: bu ORNEK SAYISIDIR, ornek dizisi degil. PowerShell degisken
    # adlari buyuk/kucuk harf duyarsiz oldugu icin $Samples adi, ornekleri
    # tutan $samples dizisiyle cakisiyordu; ad ayristirildi.
    [Alias('Samples')]
    [int]    $SampleCount = 12,
    [double] $Interval = 5,
    [int]    $Duration = 0,

    # Join-Path yerine string birlestirme: LOCALAPPDATA tanimsizsa Join-Path
    # parametre baglama hatasi verip tum scripti dusurur.
    [string] $DataPath = "$env:LOCALAPPDATA\WinPerfDiag",
    [string] $OutFile,
    [string] $InputFile,

    [ValidateSet('Html', 'Json', 'Both')]
    [string] $Format = 'Both',

    [int]    $TopN = 15,
    [switch] $NoEventLog,
    [switch] $Quiet
)

$ErrorActionPreference = 'Continue'
$ProgressPreference    = 'SilentlyContinue'
$script:Warnings       = @()

#region ---------------------------------------------------------- Yardimcilar

function Write-Info {
    param([string]$Message, [string]$Color = 'Gray')
    if (-not $Quiet) { Write-Host $Message -ForegroundColor $Color }
}

function Add-Gap {
    # Olculemeyen her sey kayit altina alinir. Rapor bunu "olculmedi" diye
    # gosterir; sessizce "sorun yok" diye gecmez.
    param([string]$Source, [string]$Reason)
    $script:Warnings += [pscustomobject]@{ Source = $Source; Reason = $Reason }
}

function Invoke-Safe {
    <# Hicbir olcum tum calismayi durdurmamali. Hata -> $null + kayit. #>
    param(
        [Parameter(Mandatory)] [scriptblock] $Script,
        [Parameter(Mandatory)] [string]      $Source
    )
    try {
        & $Script
    } catch {
        Add-Gap -Source $Source -Reason $_.Exception.Message
        $null
    }
}

function Get-Cim {
    # Kendi try/catch'ini tasir: scriptblock'un dinamik kapsamdan degisken
    # cozmesine guvenmez.
    param([string]$Class, [string]$Namespace = 'root\cimv2', [string]$Filter)
    $splat = @{ ClassName = $Class; Namespace = $Namespace; ErrorAction = 'Stop' }
    if ($Filter) { $splat['Filter'] = $Filter }
    try {
        Get-CimInstance @splat
    } catch {
        Add-Gap -Source "CIM:$Class" -Reason $_.Exception.Message
        $null
    }
}

function ConvertTo-Num {
    param($Value, $Default = 0)
    if ($null -eq $Value) { return $Default }
    try { return [double]$Value } catch { return $Default }
}

function Get-Rate {
    <# Kumulatif sayac -> saniyelik hiz. #>
    param($Current, $Previous, [double]$DeltaSec)
    if ($DeltaSec -le 0) { return 0 }
    $d = (ConvertTo-Num $Current) - (ConvertTo-Num $Previous)
    if ($d -lt 0) { return 0 }   # sayac sarmasi
    return $d / $DeltaSec
}

function Get-Pct100Ns {
    <# PERF_100NSEC_TIMER: 100ns birimli kumulatif sayac -> yuzde. #>
    param($Current, $Previous, $TsCurrent, $TsPrevious)
    $dt = (ConvertTo-Num $TsCurrent) - (ConvertTo-Num $TsPrevious)
    if ($dt -le 0) { return 0 }
    $dn = (ConvertTo-Num $Current) - (ConvertTo-Num $Previous)
    if ($dn -lt 0) { return 0 }
    return ($dn / $dt) * 100
}

function Get-AvgTimerMs {
    <#
      PERF_AVERAGE_TIMER (ornek: AvgDisksecPerRead).
      Deger = ((N1-N0) / Frequency) / (B1-B0), saniye cinsinden.
      Formatted sinif bu alani UInt32 saniye olarak verdigi icin milisaniyelik
      gecikmeler 0'a yuvarlanir; bu yuzden ham sayactan hesapliyoruz.
    #>
    param($N1, $N0, $B1, $B0, $Frequency)
    $dn = (ConvertTo-Num $N1) - (ConvertTo-Num $N0)
    $db = (ConvertTo-Num $B1) - (ConvertTo-Num $B0)
    $f  = ConvertTo-Num $Frequency
    if ($db -le 0 -or $f -le 0 -or $dn -lt 0) { return $null }
    return (($dn / $f) / $db) * 1000.0
}

function Round2 { param($v) if ($null -eq $v) { $null } else { [math]::Round([double]$v, 2) } }

#endregion

#region ------------------------------------------------- Yetenek / kapsam tespiti

function Test-Elevated {
    # Once whoami: ConstrainedLanguage modunda .NET tip erisimi bloke
    # olabilecegi icin harici komut daha guvenli. S-1-16-12288 = High
    # Mandatory Level, yani yukseltilmis token.
    try {
        $groups = & whoami.exe /groups 2>$null
        if ($LASTEXITCODE -eq 0 -and $groups) {
            return [bool](@($groups | Select-String -SimpleMatch 'S-1-16-12288').Count)
        }
    } catch { }
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $pr = [Security.Principal.WindowsPrincipal]$id
        return $pr.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch {
        Add-Gap -Source 'Elevation' -Reason 'Yetki seviyesi belirlenemedi; standart kullanici varsayildi'
        return $false
    }
}

function Get-Capabilities {
    $elev = Test-Elevated
    if ($null -eq $elev) { $elev = $false }

    $os  = Get-Cim -Class Win32_OperatingSystem
    $cs  = Get-Cim -Class Win32_ComputerSystem
    $cpu = @(Get-Cim -Class Win32_Processor)

    $ncpu = 0
    if ($cs) { $ncpu = [int](ConvertTo-Num $cs.NumberOfLogicalProcessors 0) }
    if ($ncpu -le 0) { $ncpu = [int](ConvertTo-Num $env:NUMBER_OF_PROCESSORS 1) }

    # Her veri kaynagini tek tek yokla: "erisebiliyor muyum?" sorusuna
    # varsayimla degil denemeyle cevap ver.
    $probe = @{}
    $probe['PerfProc']    = $null -ne (Get-Cim -Class Win32_PerfRawData_PerfProc_Process -Filter "IDProcess=4")
    $probe['PerfDisk']    = $null -ne (Get-Cim -Class Win32_PerfRawData_PerfDisk_LogicalDisk -Filter "Name='_Total'")
    $probe['PerfOS']      = $null -ne (Get-Cim -Class Win32_PerfRawData_PerfOS_System)
    $probe['PerfCpu']     = $null -ne (Get-Cim -Class Win32_PerfRawData_PerfOS_Processor -Filter "Name='_Total'")
    $probe['Services']    = $null -ne (Get-Cim -Class Win32_Service -Filter "Name='Schedule'")
    $probe['SysDriver']   = $null -ne (Get-Cim -Class Win32_SystemDriver -Filter "Name='FltMgr'")
    $probe['Registry']    = Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Services'
    $probe['SchedTask']   = $null -ne (Invoke-Safe -Source 'Get-ScheduledTask' -Script { Get-ScheduledTask -ErrorAction Stop | Select-Object -First 1 })
    $probe['EventSystem'] = $null -ne (Invoke-Safe -Source 'EventLog:System' -Script { Get-WinEvent -LogName System -MaxEvents 1 -ErrorAction Stop })
    $probe['EventBoot']   = $null -ne (Invoke-Safe -Source 'EventLog:Diagnostics-Performance' -Script {
                                Get-WinEvent -LogName 'Microsoft-Windows-Diagnostics-Performance/Operational' -MaxEvents 1 -ErrorAction Stop })
    $probe['EventGpo']    = $null -ne (Invoke-Safe -Source 'EventLog:GroupPolicy' -Script {
                                Get-WinEvent -LogName 'Microsoft-Windows-GroupPolicy/Operational' -MaxEvents 1 -ErrorAction Stop })
    $probe['Fltmc']       = $elev
    $probe['Defender']    = $null -ne (Invoke-Safe -Source 'Get-MpComputerStatus' -Script { Get-MpComputerStatus -ErrorAction Stop })
    $probe['PhysDisk']    = $null -ne (Invoke-Safe -Source 'Get-PhysicalDisk' -Script { Get-PhysicalDisk -ErrorAction Stop | Select-Object -First 1 })

    [pscustomobject]@{
        Elevated         = [bool]$elev
        UserName         = "$env:USERDOMAIN\$env:USERNAME"
        ComputerName     = $env:COMPUTERNAME
        DomainJoined     = if ($cs) { [bool]$cs.PartOfDomain } else { $null }
        Domain           = if ($cs) { $cs.Domain } else { $null }
        LogicalCpu       = $ncpu
        TotalMemoryMB    = if ($os) { [math]::Round((ConvertTo-Num $os.TotalVisibleMemorySize) / 1024, 0) } else { $null }
        OsCaption        = if ($os) { $os.Caption } else { $null }
        OsVersion        = if ($os) { $os.Version } else { $null }
        OsBuild          = if ($os) { $os.BuildNumber } else { $null }
        OsLanguage       = if ($os) { $os.OSLanguage } else { $null }
        LastBootUpTime   = if ($os) { $os.LastBootUpTime } else { $null }
        CpuName          = if ($cpu.Count -gt 0) { $cpu[0].Name } else { $null }
        Model            = if ($cs) { "$($cs.Manufacturer) $($cs.Model)" } else { $null }
        PsVersion        = $PSVersionTable.PSVersion.ToString()
        LanguageMode     = $ExecutionContext.SessionState.LanguageMode.ToString()
        Probe            = $probe
    }
}

#endregion

#region ------------------------------------------------- Guvenlik ajani katalogu

# Process adi (kucuk harf, .exe'siz) -> saglayici ve kategori.
# Kategori, yavaslik analizinde "ajan vergisi" hesabinda kullanilir.
$script:AgentCatalog = @{
    # --- EDR / AV ---
    'csfalconservice'      = @{ V = 'CrowdStrike Falcon';     C = 'EDR' }
    'csfalconcontainer'    = @{ V = 'CrowdStrike Falcon';     C = 'EDR' }
    'sentinelagent'        = @{ V = 'SentinelOne';            C = 'EDR' }
    'sentinelservicehost'  = @{ V = 'SentinelOne';            C = 'EDR' }
    'sentinelstaticengine' = @{ V = 'SentinelOne';            C = 'EDR' }
    'sentinelhelperservice'= @{ V = 'SentinelOne';            C = 'EDR' }
    'msmpeng'              = @{ V = 'Microsoft Defender';     C = 'AV' }
    'mpdefendercoreservice'= @{ V = 'Microsoft Defender';     C = 'AV' }
    'nissrv'               = @{ V = 'Microsoft Defender';     C = 'AV' }
    'mpcmdrun'             = @{ V = 'Microsoft Defender';     C = 'AV' }
    'mssense'              = @{ V = 'Defender for Endpoint';  C = 'EDR' }
    'senseir'              = @{ V = 'Defender for Endpoint';  C = 'EDR' }
    'sensece'              = @{ V = 'Defender for Endpoint';  C = 'EDR' }
    'sensendr'             = @{ V = 'Defender for Endpoint';  C = 'EDR' }
    'cyserver'             = @{ V = 'Palo Alto Cortex XDR';   C = 'EDR' }
    'cytool'               = @{ V = 'Palo Alto Cortex XDR';   C = 'EDR' }
    'cyveraservice'        = @{ V = 'Palo Alto Traps/Cortex'; C = 'EDR' }
    'repmgr'               = @{ V = 'VMware Carbon Black';    C = 'EDR' }
    'repux'                = @{ V = 'VMware Carbon Black';    C = 'EDR' }
    'repwsc'               = @{ V = 'VMware Carbon Black';    C = 'EDR' }
    'cb'                   = @{ V = 'Carbon Black';           C = 'EDR' }
    'mcshield'             = @{ V = 'Trellix / McAfee';       C = 'AV' }
    'masvc'                = @{ V = 'Trellix / McAfee ePO';   C = 'Yonetim' }
    'macmnsvc'             = @{ V = 'Trellix / McAfee ePO';   C = 'Yonetim' }
    'mfemms'               = @{ V = 'Trellix / McAfee';       C = 'AV' }
    'mfetp'                = @{ V = 'Trellix / McAfee';       C = 'AV' }
    'mfewc'                = @{ V = 'Trellix / McAfee';       C = 'AV' }
    'ccsvchst'             = @{ V = 'Symantec / Broadcom';    C = 'AV' }
    'sepmasterservice'     = @{ V = 'Symantec Endpoint';      C = 'AV' }
    'sisipsservice'        = @{ V = 'Symantec Endpoint';      C = 'EDR' }
    'tmlisten'             = @{ V = 'Trend Micro';            C = 'AV' }
    'tmbmsrv'              = @{ V = 'Trend Micro';            C = 'AV' }
    'ntrtscan'             = @{ V = 'Trend Micro';            C = 'AV' }
    'coreserviceshell'     = @{ V = 'Trend Micro Apex One';   C = 'AV' }
    'coreframeworkhost'    = @{ V = 'Trend Micro Apex One';   C = 'AV' }
    'sophosfilescanner'    = @{ V = 'Sophos';                 C = 'AV' }
    'sophosfs'             = @{ V = 'Sophos';                 C = 'AV' }
    'sophoshealth'         = @{ V = 'Sophos';                 C = 'AV' }
    'sophosntpservice'     = @{ V = 'Sophos';                 C = 'AV' }
    'avp'                  = @{ V = 'Kaspersky';              C = 'AV' }
    'ekrn'                 = @{ V = 'ESET';                   C = 'AV' }
    'bdservicehost'        = @{ V = 'Bitdefender';            C = 'AV' }
    'epsecurityservice'    = @{ V = 'Bitdefender GravityZone';C = 'AV' }
    'epintegrationservice' = @{ V = 'Bitdefender GravityZone';C = 'AV' }
    'sfc'                  = @{ V = 'Cisco Secure Endpoint';  C = 'EDR' }
    'darktraceagent'       = @{ V = 'Darktrace';              C = 'EDR' }

    # --- DLP / veri sizinti ---
    'dgagent'              = @{ V = 'Digital Guardian';       C = 'DLP' }
    'edpa'                 = @{ V = 'Symantec DLP';           C = 'DLP' }
    'dserui'               = @{ V = 'Forcepoint DLP';         C = 'DLP' }
    'wepsvc'               = @{ V = 'Forcepoint';             C = 'DLP' }
    'eipclient'            = @{ V = 'Forcepoint';             C = 'DLP' }

    # --- Ag / SWG / VPN ---
    'stagentsvc'           = @{ V = 'Netskope';               C = 'Ag/SWG' }
    'stagentui'            = @{ V = 'Netskope';               C = 'Ag/SWG' }
    'zsaservice'           = @{ V = 'Zscaler';                C = 'Ag/SWG' }
    'zsatunnel'            = @{ V = 'Zscaler';                C = 'Ag/SWG' }
    'zsatray'              = @{ V = 'Zscaler';                C = 'Ag/SWG' }
    'zsatraymanager'       = @{ V = 'Zscaler';                C = 'Ag/SWG' }
    'vpnagent'             = @{ V = 'Cisco Secure Client';    C = 'VPN' }
    'acwebsecagent'        = @{ V = 'Cisco Umbrella';         C = 'Ag/SWG' }
    'acumbrellaagent'      = @{ V = 'Cisco Umbrella';         C = 'Ag/SWG' }
    'pangps'               = @{ V = 'Palo Alto GlobalProtect';C = 'VPN' }
    'pangpa'               = @{ V = 'Palo Alto GlobalProtect';C = 'VPN' }

    # --- Yonetim / envanter / uyumluluk ---
    'ccmexec'              = @{ V = 'SCCM / MECM';            C = 'Yonetim' }
    'cmrcservice'          = @{ V = 'SCCM / MECM';            C = 'Yonetim' }
    'intunemanagementextension' = @{ V = 'Intune';            C = 'Yonetim' }
    'taniumclient'         = @{ V = 'Tanium';                 C = 'Yonetim' }
    'taniumcx'             = @{ V = 'Tanium';                 C = 'Yonetim' }
    'taniumdetectengine'   = @{ V = 'Tanium';                 C = 'EDR' }
    'besclient'            = @{ V = 'HCL BigFix';             C = 'Yonetim' }
    'qualysagent'          = @{ V = 'Qualys';                 C = 'Zafiyet' }
    'ir_agent'             = @{ V = 'Rapid7 InsightIDR';      C = 'EDR' }
    'nessusd'              = @{ V = 'Tenable Nessus';         C = 'Zafiyet' }
    'nxtsvc'               = @{ V = 'Nexthink';               C = 'Izleme' }
    'lsiagent'             = @{ V = 'Lakeside SysTrack';      C = 'Izleme' }
    '1e.client'            = @{ V = '1E Client';              C = 'Yonetim' }
    'epmagent'             = @{ V = 'Ivanti EPM';             C = 'Yonetim' }
    'rpcnet'               = @{ V = 'Absolute';               C = 'Yonetim' }

    # --- Yedekleme / senkron ---
    'code42service'        = @{ V = 'Code42 / CrashPlan';     C = 'Yedekleme' }
    'insyncclient'         = @{ V = 'Druva inSync';           C = 'Yedekleme' }
}

function Resolve-Agent {
    <# Process adindan saglayici/kategori cozumle; bilinmiyorsa imzaya bak. #>
    param([string]$Name, [string]$Company)
    $key = ($Name -replace '\.exe$', '').ToLowerInvariant()
    $key = ($key -replace '#\d+$', '')
    if ($script:AgentCatalog.ContainsKey($key)) {
        return [pscustomobject]@{
            Vendor   = $script:AgentCatalog[$key].V
            Category = $script:AgentCatalog[$key].C
            Source   = 'katalog'
        }
    }
    if ($Company) {
        $patterns = @(
            @{ P = 'crowdstrike';  V = 'CrowdStrike';        C = 'EDR' },
            @{ P = 'sentinelone';  V = 'SentinelOne';        C = 'EDR' },
            @{ P = 'mcafee';       V = 'Trellix / McAfee';   C = 'AV' },
            @{ P = 'trellix';      V = 'Trellix';            C = 'AV' },
            @{ P = 'symantec';     V = 'Symantec';           C = 'AV' },
            @{ P = 'broadcom';     V = 'Broadcom/Symantec';  C = 'AV' },
            @{ P = 'trend micro';  V = 'Trend Micro';        C = 'AV' },
            @{ P = 'sophos';       V = 'Sophos';             C = 'AV' },
            @{ P = 'kaspersky';    V = 'Kaspersky';          C = 'AV' },
            @{ P = 'eset';         V = 'ESET';               C = 'AV' },
            @{ P = 'bitdefender';  V = 'Bitdefender';        C = 'AV' },
            @{ P = 'palo alto';    V = 'Palo Alto Networks'; C = 'EDR' },
            @{ P = 'netskope';     V = 'Netskope';           C = 'Ag/SWG' },
            @{ P = 'zscaler';      V = 'Zscaler';            C = 'Ag/SWG' },
            @{ P = 'forcepoint';   V = 'Forcepoint';         C = 'DLP' },
            @{ P = 'tanium';       V = 'Tanium';             C = 'Yonetim' },
            @{ P = 'qualys';       V = 'Qualys';             C = 'Zafiyet' },
            @{ P = 'rapid7';       V = 'Rapid7';             C = 'EDR' },
            @{ P = 'carbon black'; V = 'Carbon Black';       C = 'EDR' },
            @{ P = 'digital guardian'; V = 'Digital Guardian'; C = 'DLP' },
            @{ P = 'ivanti';       V = 'Ivanti';             C = 'Yonetim' },
            @{ P = 'nexthink';     V = 'Nexthink';           C = 'Izleme' }
        )
        $lc = $Company.ToLowerInvariant()
        foreach ($p in $patterns) {
            if ($lc -like "*$($p.P)*") {
                return [pscustomobject]@{ Vendor = $p.V; Category = $p.C; Source = 'imza' }
            }
        }
    }
    return $null
}

#endregion
#region ------------------------------------------------------ Statik envanter

function Get-MiniFilterInventory {
    <#
      Dosya sistemi filtre suruculerini listeler.

      Neden onemli: her dosya acma/okuma/yazma islemi, yuklu her minifilter'in
      icinden gecer. Ust uste binmis AV/DLP/sifreleme filtreleri, tek basina
      olculebilir I/O gecikmesi uretir -- domain ortamlarinda yavasligin en sik
      yapisal nedeni budur.

      Standart kullanici ile: kayit defterinden Altitude + Group okunur,
      Win32_SystemDriver'dan calisma durumu alinir. fltmc'ye gerek yoktur.
      Yonetici ile: fltmc filters ciktisi da eklenir (gercekten YUKLU olanlar).

      Siniflandirma altitude numarasindan CIKARILMAZ; kayit defterindeki
      Group degeri zaten "FSFilter Anti-Virus" gibi acik yazar, o okunur.
    #>
    param($Caps)

    $result = @{ Registry = @(); Fltmc = $null; DriverState = @{} }

    # State alani yerellestirilebildigi icin calisma tespiti dile bagli
    # OLMAYAN Started (boolean) alanindan yapilir; State yalnizca gosterim.
    $drivers = @(Get-Cim -Class Win32_SystemDriver)
    foreach ($d in $drivers) {
        if ($d.Name) {
            $result.DriverState[$d.Name.ToLowerInvariant()] = [pscustomobject]@{
                Started = [bool]$d.Started
                State   = "$($d.State)"
            }
        }
    }

    $base = 'HKLM:\SYSTEM\CurrentControlSet\Services'
    if (Test-Path $base) {
        $keys = Invoke-Safe -Source 'Registry:Services' -Script {
            Get-ChildItem $base -ErrorAction Stop
        }
        foreach ($k in @($keys)) {
            $group = Invoke-Safe -Source 'Registry:Group' -Script {
                (Get-ItemProperty -Path $k.PSPath -Name 'Group' -ErrorAction Stop).Group
            }
            if (-not $group -or $group -notlike 'FSFilter*') { continue }

            $inst = Join-Path $k.PSPath 'Instances'
            $alt  = $null
            if (Test-Path $inst) {
                $def = Invoke-Safe -Source 'Registry:Instances' -Script {
                    (Get-ItemProperty -Path $inst -Name 'DefaultInstance' -ErrorAction Stop).DefaultInstance
                }
                if ($def) {
                    $altPath = Join-Path $inst $def
                    $alt = Invoke-Safe -Source 'Registry:Altitude' -Script {
                        (Get-ItemProperty -Path $altPath -Name 'Altitude' -ErrorAction Stop).Altitude
                    }
                }
            }
            $props = Invoke-Safe -Source 'Registry:FilterProps' -Script {
                Get-ItemProperty -Path $k.PSPath -ErrorAction Stop
            }
            $name = $k.PSChildName
            $ds = $result.DriverState[$name.ToLowerInvariant()]
            $running = $false
            $stateText = 'bilinmiyor'
            if ($ds) { $running = $ds.Started; $stateText = $ds.State }

            $result.Registry += [pscustomobject]@{
                Name        = $name
                DisplayName = if ($props) { $props.DisplayName } else { $null }
                Group       = $group
                Altitude    = $alt
                StartType   = if ($props) { $props.Start } else { $null }
                ImagePath   = if ($props) { $props.ImagePath } else { $null }
                Running     = $running
                State       = $stateText
            }
        }
    } else {
        Add-Gap -Source 'MiniFilter' -Reason 'HKLM Services anahtari okunamadi'
    }

    $result.Registry = @($result.Registry | Sort-Object { [int](ConvertTo-Num $_.Altitude 0) } -Descending)

    if ($Caps.Elevated) {
        $result.Fltmc = Invoke-Safe -Source 'fltmc' -Script {
            $raw = & fltmc.exe filters 2>&1
            if ($LASTEXITCODE -ne 0) { throw "fltmc cikis kodu $LASTEXITCODE" }
            @($raw | Where-Object { $_ -match '\S' })
        }
    } else {
        Add-Gap -Source 'fltmc' -Reason 'Yonetici gerekir; kayit defteri + Win32_SystemDriver ile telafi edildi'
    }

    return $result
}

function Get-ServiceInventory {
    $svc = @(Get-Cim -Class Win32_Service)
    $out = @()
    foreach ($s in $svc) {
        $out += [pscustomobject]@{
            Name        = $s.Name
            DisplayName = $s.DisplayName
            State       = $s.State
            StartMode   = $s.StartMode
            ProcessId   = [int](ConvertTo-Num $s.ProcessId 0)
            PathName    = $s.PathName
        }
    }
    return @($out)
}

function Get-StartupInventory {
    $items = @()

    foreach ($sc in @(Get-Cim -Class Win32_StartupCommand)) {
        $items += [pscustomobject]@{
            Name = $sc.Name; Command = $sc.Command; Location = $sc.Location; User = $sc.User
        }
    }

    $tasks = Invoke-Safe -Source 'Get-ScheduledTask' -Script {
        Get-ScheduledTask -ErrorAction Stop | Where-Object { $_.State -ne 'Disabled' }
    }
    $taskList = @()
    foreach ($t in @($tasks)) {
        $trigger = ''
        foreach ($tr in @($t.Triggers)) {
            $trigger = $tr.CimClass.CimClassName -replace '^MSFT_Task', '' -replace 'Trigger$', ''
            break
        }
        # Sadece surekli/olay tetikli veya acilista calisanlar ilginc.
        if ($trigger -match 'Logon|Boot|Registration|Event|Idle' -or $t.Settings.RunOnlyIfIdle) {
            $taskList += [pscustomobject]@{
                Path = $t.TaskPath; Name = $t.TaskName; Trigger = $trigger; State = "$($t.State)"
            }
        }
    }

    return [pscustomobject]@{ RunEntries = @($items); Tasks = @($taskList) }
}

function Get-PowerProfile {
    <#
      Domain GPO'su ile dayatilan guc plani, kullanicinin "bilgisayar yavas"
      sikayetinin sik ama gozden kacan nedenidir: maksimum islemci durumu
      %100'un altina cekilmisse CPU hicbir zaman tam hiza cikmaz.
    #>
    $active = Invoke-Safe -Source 'powercfg' -Script {
        $raw = & powercfg.exe /getactivescheme 2>&1
        if ($LASTEXITCODE -ne 0) { throw "powercfg cikis kodu $LASTEXITCODE" }
        ($raw -join ' ').Trim()
    }

    $throttle = Invoke-Safe -Source 'powercfg-proc' -Script {
        $raw = & powercfg.exe /query SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMAX 2>&1
        if ($LASTEXITCODE -ne 0) { throw "powercfg query cikis kodu $LASTEXITCODE" }
        # DIKKAT: powercfg ciktisi yerellestirilmistir -- Turkce Windows'ta
        # "AC Power Setting Index" Turkce yazar. Bu yuzden etiket metnine
        # gore DEGIL, 0x degerlerinin sirasina gore okunur: powercfg her
        # zaman once AC sonra DC degerini basar.
        $hex = @()
        foreach ($line in $raw) {
            if ($line -match ':\s*0x([0-9a-fA-F]+)\s*$') { $hex += $Matches[1] }
        }
        $ac = $null; $dc = $null
        if ($hex.Count -ge 1) { $ac = [int][uint32]"0x$($hex[0])" }
        if ($hex.Count -ge 2) { $dc = [int][uint32]"0x$($hex[1])" }
        [pscustomobject]@{ AcMaxPct = $ac; DcMaxPct = $dc }
    }

    $procs = @(Get-Cim -Class Win32_Processor)
    $clock = $null
    if ($procs.Count -gt 0) {
        $clock = [pscustomobject]@{
            CurrentMHz = [int](ConvertTo-Num $procs[0].CurrentClockSpeed 0)
            MaxMHz     = [int](ConvertTo-Num $procs[0].MaxClockSpeed 0)
        }
    }

    return [pscustomobject]@{ ActiveScheme = $active; ThrottleMax = $throttle; Clock = $clock }
}

function Get-StorageInventory {
    $disks = @()
    foreach ($d in @(Get-Cim -Class Win32_LogicalDisk -Filter 'DriveType=3')) {
        $size = ConvertTo-Num $d.Size 0
        $free = ConvertTo-Num $d.FreeSpace 0
        $disks += [pscustomobject]@{
            Drive     = $d.DeviceID
            SizeGB    = [math]::Round($size / 1GB, 1)
            FreeGB    = [math]::Round($free / 1GB, 1)
            FreePct   = if ($size -gt 0) { [math]::Round($free / $size * 100, 1) } else { $null }
            FileSystem= $d.FileSystem
        }
    }

    $phys = Invoke-Safe -Source 'Get-PhysicalDisk' -Script {
        Get-PhysicalDisk -ErrorAction Stop | Select-Object FriendlyName, MediaType, BusType, Size, HealthStatus
    }
    $physList = @()
    foreach ($p in @($phys)) {
        $physList += [pscustomobject]@{
            Name = $p.FriendlyName; MediaType = "$($p.MediaType)"; BusType = "$($p.BusType)"
            SizeGB = [math]::Round((ConvertTo-Num $p.Size 0) / 1GB, 1); Health = "$($p.HealthStatus)"
        }
    }

    $page = @()
    foreach ($pf in @(Get-Cim -Class Win32_PageFileUsage)) {
        $page += [pscustomobject]@{
            Path = $pf.Name; AllocatedMB = [int](ConvertTo-Num $pf.AllocatedBaseSize 0)
            CurrentMB = [int](ConvertTo-Num $pf.CurrentUsage 0); PeakMB = [int](ConvertTo-Num $pf.PeakUsage 0)
        }
    }

    return [pscustomobject]@{ Volumes = @($disks); Physical = @($physList); PageFiles = @($page) }
}

function Get-SecurityPosture {
    $vbs = $null
    $dgPath = 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard'
    if (Test-Path $dgPath) {
        $vbs = Invoke-Safe -Source 'Registry:DeviceGuard' -Script {
            $p = Get-ItemProperty -Path $dgPath -ErrorAction Stop
            $hvci = $null
            $sPath = Join-Path $dgPath 'Scenarios\HypervisorEnforcedCodeIntegrity'
            if (Test-Path $sPath) {
                $hvci = (Get-ItemProperty -Path $sPath -ErrorAction SilentlyContinue).Enabled
            }
            [pscustomobject]@{
                EnableVirtualizationBasedSecurity = $p.EnableVirtualizationBasedSecurity
                RequirePlatformSecurityFeatures   = $p.RequirePlatformSecurityFeatures
                HvciEnabled                       = $hvci
            }
        }
    }

    $defender = Invoke-Safe -Source 'Get-MpComputerStatus' -Script {
        $s = Get-MpComputerStatus -ErrorAction Stop
        [pscustomobject]@{
            RealTimeProtection = $s.RealTimeProtectionEnabled
            AntivirusEnabled   = $s.AntivirusEnabled
            AMRunningMode      = "$($s.AMRunningMode)"
            QuickScanAge       = $s.QuickScanAge
        }
    }

    $avProducts = Invoke-Safe -Source 'SecurityCenter2' -Script {
        Get-CimInstance -Namespace 'root\SecurityCenter2' -ClassName AntiVirusProduct -ErrorAction Stop |
            Select-Object displayName, pathToSignedProductExe
    }

    return [pscustomobject]@{
        DeviceGuard = $vbs
        Defender    = $defender
        AvProducts  = @($avProducts | ForEach-Object { [pscustomobject]@{ Name = $_.displayName; Path = $_.pathToSignedProductExe } })
    }
}

function Get-BootAndGpoEvents {
    <#
      Microsoft-Windows-Diagnostics-Performance/Operational kanali, acilisi
      yavaslatan uygulamayi ADIYLA ve milisaniye cinsinden sureyle verir.
      Bu kanal genellikle yonetici hakki ister.

      GroupPolicy/Operational kanali, her GPO istemci eklentisinin (CSE)
      isleme suresini verir -- domain ortaminda oturum acma yavasliginin
      dogrudan kanitidir.
    #>
    param($Caps)

    $boot = @()
    if ($Caps.Probe['EventBoot']) {
        $evts = Invoke-Safe -Source 'EventLog:BootPerf' -Script {
            Get-WinEvent -FilterHashtable @{
                LogName = 'Microsoft-Windows-Diagnostics-Performance/Operational'
                Id      = 100, 101, 102, 103, 109, 110
            } -MaxEvents 80 -ErrorAction Stop
        }
        foreach ($e in @($evts)) {
            $boot += [pscustomobject]@{
                Time = $e.TimeCreated; Id = $e.Id
                Message = ($e.Message -replace '\s+', ' ').Trim()
            }
        }
    } else {
        Add-Gap -Source 'BootPerf' -Reason 'Diagnostics-Performance kanali okunamadi (genellikle yonetici gerekir)'
    }

    $gpo = @()
    if ($Caps.Probe['EventGpo']) {
        $evts = Invoke-Safe -Source 'EventLog:GroupPolicy' -Script {
            Get-WinEvent -FilterHashtable @{
                LogName = 'Microsoft-Windows-GroupPolicy/Operational'
                Id      = 8000, 8001, 8005, 8006, 5016, 6016, 7016
            } -MaxEvents 120 -ErrorAction Stop
        }
        foreach ($e in @($evts)) {
            $gpo += [pscustomobject]@{
                Time = $e.TimeCreated; Id = $e.Id
                Message = ($e.Message -replace '\s+', ' ').Trim()
            }
        }
    } else {
        Add-Gap -Source 'GroupPolicy' -Reason 'GroupPolicy/Operational kanali okunamadi'
    }

    $sys = @()
    if ($Caps.Probe['EventSystem']) {
        $evts = Invoke-Safe -Source 'EventLog:System' -Script {
            Get-WinEvent -FilterHashtable @{
                LogName   = 'System'
                Id        = 2004, 2019, 2020, 41, 1001, 6008, 129, 153, 157
                StartTime = (Get-Date).AddDays(-7)
            } -MaxEvents 100 -ErrorAction Stop
        }
        foreach ($e in @($evts)) {
            $sys += [pscustomobject]@{
                Time = $e.TimeCreated; Id = $e.Id; Provider = $e.ProviderName
                Message = ($e.Message -replace '\s+', ' ').Trim()
            }
        }
    }

    return [pscustomobject]@{ Boot = @($boot); Gpo = @($gpo); System = @($sys) }
}

function Get-StaticInventory {
    param($Caps)
    Write-Info '  - dosya sistemi filtreleri...'
    $mf = Get-MiniFilterInventory -Caps $Caps
    Write-Info '  - servisler ve baslangic ogeleri...'
    $svc = Get-ServiceInventory
    $startup = Get-StartupInventory
    Write-Info '  - guc plani, depolama, guvenlik durumu...'
    $power = Get-PowerProfile
    $storage = Get-StorageInventory
    $posture = Get-SecurityPosture
    $events = $null
    if (-not $NoEventLog) {
        Write-Info '  - olay gunlukleri (acilis / GPO / sistem)...'
        $events = Get-BootAndGpoEvents -Caps $Caps
    }

    [pscustomobject]@{
        MiniFilters = $mf
        Services    = $svc
        Startup     = $startup
        Power       = $power
        Storage     = $storage
        Posture     = $posture
        Events      = $events
    }
}

#endregion
#region --------------------------------------------------------- Ornekleme

$script:ProcFields = @(
    'IDProcess', 'Name', 'PercentProcessorTime', 'PercentPrivilegedTime',
    'WorkingSetPrivate', 'PrivateBytes', 'HandleCount', 'ThreadCount',
    'IOReadOperationsPersec', 'IOWriteOperationsPersec',
    'IOReadBytesPersec', 'IOWriteBytesPersec', 'PageFaultsPersec',
    'CreatingProcessID', 'Timestamp_Sys100NS'
)

function Get-RawSnapshot {
    <# Tek bir zaman noktasinda tum ham sayaclari topla. #>
    $ts = Get-Date

    $proc = Invoke-Safe -Source 'Perf:Process' -Script {
        Get-CimInstance -ClassName Win32_PerfRawData_PerfProc_Process `
            -Property $script:ProcFields -ErrorAction Stop
    }
    $disk = Invoke-Safe -Source 'Perf:LogicalDisk' -Script {
        Get-CimInstance -ClassName Win32_PerfRawData_PerfDisk_LogicalDisk `
            -Filter "Name='_Total'" -ErrorAction Stop
    }
    $mem = Invoke-Safe -Source 'Perf:Memory' -Script {
        Get-CimInstance -ClassName Win32_PerfRawData_PerfOS_Memory -ErrorAction Stop
    }
    $sys = Invoke-Safe -Source 'Perf:System' -Script {
        Get-CimInstance -ClassName Win32_PerfRawData_PerfOS_System -ErrorAction Stop
    }
    $cpu = Invoke-Safe -Source 'Perf:Processor' -Script {
        Get-CimInstance -ClassName Win32_PerfRawData_PerfOS_Processor `
            -Filter "Name='_Total'" -ErrorAction Stop
    }

    [pscustomobject]@{
        Ts = $ts; Proc = @($proc); Disk = $disk; Mem = $mem; Sys = $sys; Cpu = $cpu
    }
}

function ConvertTo-Sample {
    <#
      Iki ham anlik goruntuden turetilmis metrikleri hesapla.

      _Total ornegindeki islemci sayaclari tum cekirdeklerin TOPLAMIDIR, bu
      yuzden mantiksal cekirdek sayisina bolunur. Ayni sey process basina
      PercentProcessorTime icin de gecerli: bolmezsek 8 cekirdekli makinede
      %800 gorunur. Gorev Yoneticisi semantigi icin bolunur.
    #>
    param($Cur, $Prev, [int]$Ncpu)

    if (-not $Prev) { return $null }
    $dt = ($Cur.Ts - $Prev.Ts).TotalSeconds
    if ($dt -le 0) { return $null }
    if ($Ncpu -le 0) { $Ncpu = 1 }

    $m = [ordered]@{ Ts = $Cur.Ts; DeltaSec = [math]::Round($dt, 3) }

    # --- islemci ---
    if ($Cur.Cpu -and $Prev.Cpu) {
        $t1 = $Cur.Cpu.Timestamp_Sys100NS; $t0 = $Prev.Cpu.Timestamp_Sys100NS
        $idle = (Get-Pct100Ns $Cur.Cpu.PercentIdleTime      $Prev.Cpu.PercentIdleTime      $t1 $t0) / $Ncpu
        $dpc  = (Get-Pct100Ns $Cur.Cpu.PercentDPCTime       $Prev.Cpu.PercentDPCTime       $t1 $t0) / $Ncpu
        $intr = (Get-Pct100Ns $Cur.Cpu.PercentInterruptTime $Prev.Cpu.PercentInterruptTime $t1 $t0) / $Ncpu
        $priv = (Get-Pct100Ns $Cur.Cpu.PercentPrivilegedTime $Prev.Cpu.PercentPrivilegedTime $t1 $t0) / $Ncpu
        $total = 100 - $idle
        if ($total -lt 0) { $total = 0 }; if ($total -gt 100) { $total = 100 }
        $m['CpuTotalPct']      = Round2 $total
        $m['CpuPrivilegedPct'] = Round2 $priv
        $m['CpuDpcPct']        = Round2 $dpc
        $m['CpuInterruptPct']  = Round2 $intr
    }

    # --- sistem ---
    if ($Cur.Sys -and $Prev.Sys) {
        $m['ProcessorQueueLength'] = [int](ConvertTo-Num $Cur.Sys.ProcessorQueueLength 0)
        $m['ContextSwitchesPerSec'] = [int](Get-Rate $Cur.Sys.ContextSwitchesPersec $Prev.Sys.ContextSwitchesPersec $dt)
        $m['SystemCallsPerSec']     = [int](Get-Rate $Cur.Sys.SystemCallsPersec     $Prev.Sys.SystemCallsPersec     $dt)
    }

    # --- bellek ---
    if ($Cur.Mem -and $Prev.Mem) {
        $m['AvailableMB']      = [int](ConvertTo-Num $Cur.Mem.AvailableMBytes 0)
        $m['HardFaultsPerSec'] = [int](Get-Rate $Cur.Mem.PagesInputPersec $Prev.Mem.PagesInputPersec $dt)
        $m['PageFaultsPerSec'] = [int](Get-Rate $Cur.Mem.PageFaultsPersec $Prev.Mem.PageFaultsPersec $dt)
        $committed = ConvertTo-Num $Cur.Mem.CommittedBytes 0
        $limit     = ConvertTo-Num $Cur.Mem.CommitLimit 0
        $m['CommitPct']      = if ($limit -gt 0) { Round2 ($committed / $limit * 100) } else { $null }
        $m['PoolNonpagedMB'] = [int]((ConvertTo-Num $Cur.Mem.PoolNonpagedBytes 0) / 1MB)
        $m['PoolPagedMB']    = [int]((ConvertTo-Num $Cur.Mem.PoolPagedBytes 0) / 1MB)
    }

    # --- disk ---
    if ($Cur.Disk -and $Prev.Disk) {
        $freq = $Cur.Disk.Frequency_PerfTime
        $m['DiskReadMs'] = Round2 (Get-AvgTimerMs $Cur.Disk.AvgDisksecPerRead  $Prev.Disk.AvgDisksecPerRead `
                                                  $Cur.Disk.AvgDisksecPerRead_Base  $Prev.Disk.AvgDisksecPerRead_Base  $freq)
        $m['DiskWriteMs'] = Round2 (Get-AvgTimerMs $Cur.Disk.AvgDisksecPerWrite $Prev.Disk.AvgDisksecPerWrite `
                                                   $Cur.Disk.AvgDisksecPerWrite_Base $Prev.Disk.AvgDisksecPerWrite_Base $freq)
        $m['DiskQueueLength'] = [int](ConvertTo-Num $Cur.Disk.CurrentDiskQueueLength 0)
        $m['DiskReadsPerSec'] = [int](Get-Rate $Cur.Disk.DiskReadsPersec  $Prev.Disk.DiskReadsPersec  $dt)
        $m['DiskWritesPerSec']= [int](Get-Rate $Cur.Disk.DiskWritesPersec $Prev.Disk.DiskWritesPersec $dt)
    }

    # --- process basina ---
    $prevByPid = @{}
    foreach ($p in $Prev.Proc) {
        $pid_ = [int](ConvertTo-Num $p.IDProcess -1)
        if ($pid_ -ge 0) { $prevByPid[$pid_] = $p }
    }

    $procs = @()
    foreach ($c in $Cur.Proc) {
        $name = "$($c.Name)"
        if ($name -eq '_Total' -or $name -eq 'Idle') { continue }
        $pid_ = [int](ConvertTo-Num $c.IDProcess -1)
        if ($pid_ -le 0) { continue }
        $p = $prevByPid[$pid_]
        if (-not $p) { continue }   # yeni dogmus process: delta yok, atla

        $cpuPct = (Get-Pct100Ns $c.PercentProcessorTime $p.PercentProcessorTime `
                                $c.Timestamp_Sys100NS   $p.Timestamp_Sys100NS) / $Ncpu

        $procs += [pscustomobject]@{
            Pid             = $pid_
            Name            = ($name -replace '#\d+$', '')
            Instance        = $name
            CpuPct          = Round2 $cpuPct
            PrivateMB       = [int]((ConvertTo-Num $c.PrivateBytes 0) / 1MB)
            WorkingSetMB    = [int]((ConvertTo-Num $c.WorkingSetPrivate 0) / 1MB)
            Handles         = [int](ConvertTo-Num $c.HandleCount 0)
            Threads         = [int](ConvertTo-Num $c.ThreadCount 0)
            IoReadOpsPerSec = [int](Get-Rate $c.IOReadOperationsPersec  $p.IOReadOperationsPersec  $dt)
            IoWriteOpsPerSec= [int](Get-Rate $c.IOWriteOperationsPersec $p.IOWriteOperationsPersec $dt)
            IoReadKBPerSec  = [int]((Get-Rate $c.IOReadBytesPersec  $p.IOReadBytesPersec  $dt) / 1KB)
            IoWriteKBPerSec = [int]((Get-Rate $c.IOWriteBytesPersec $p.IOWriteBytesPersec $dt) / 1KB)
            HardFaultsPerSec= [int](Get-Rate $c.PageFaultsPersec $p.PageFaultsPersec $dt)
        }
    }

    [pscustomobject]@{ Metrics = [pscustomobject]$m; Processes = @($procs) }
}

function Get-ProcessEnrichment {
    <#
      Process -> yol, yayinci, servis, guvenlik ajani etiketi.
      Ornekleme dongusunun DISINDA, bir kez calisir.

      Korumali process'lerin (MsMpEng, CSFalconService gibi PPL olanlar) yolu
      standart kullaniciya kapalidir; o durumda servis kaydindaki ImagePath'e
      dusulur.
    #>
    param($Services)

    $svcByPid  = @{}
    $svcByExe  = @{}
    foreach ($s in @($Services)) {
        if ($s.ProcessId -gt 0) {
            if (-not $svcByPid.ContainsKey($s.ProcessId)) { $svcByPid[$s.ProcessId] = @() }
            $svcByPid[$s.ProcessId] += $s.Name
        }
        if ($s.PathName -and $s.PathName -match '([^\\/"]+\.exe)') {
            $exe = $Matches[1].ToLowerInvariant()
            if (-not $svcByExe.ContainsKey($exe)) { $svcByExe[$exe] = $s }
        }
    }

    $live = Invoke-Safe -Source 'Get-Process' -Script { Get-Process -ErrorAction Stop }
    $map = @{}
    foreach ($p in @($live)) {
        $path = $null; $company = $null; $desc = $null
        try { $path = $p.Path } catch { $path = $null }
        try { $company = $p.Company } catch { $company = $null }
        try { $desc = $p.Description } catch { $desc = $null }

        if (-not $path) {
            $exe = ($p.ProcessName + '.exe').ToLowerInvariant()
            if ($svcByExe.ContainsKey($exe)) { $path = $svcByExe[$exe].PathName }
        }

        $agent = Resolve-Agent -Name $p.ProcessName -Company $company
        $svcNames = @()
        if ($svcByPid.ContainsKey($p.Id)) { $svcNames = $svcByPid[$p.Id] }

        $map[[int]$p.Id] = [pscustomobject]@{
            Path        = $path
            Company     = $company
            Description = $desc
            Services    = @($svcNames)
            Vendor      = if ($agent) { $agent.Vendor } else { $null }
            Category    = if ($agent) { $agent.Category } else { $null }
            AgentSource = if ($agent) { $agent.Source } else { $null }
        }
    }
    return $map
}

function Invoke-SamplingLoop {
    <# Diag ve Monitor modlarinin ortak ornekleme dongusu. #>
    param(
        [int]$Count, [double]$IntervalSec, [int]$Ncpu,
        [scriptblock]$OnSample, [int]$DurationSec = 0
    )

    $samples = @()
    $prev = Get-RawSnapshot
    $i = 0
    $start = Get-Date

    while ($true) {
        Start-Sleep -Milliseconds ([int]($IntervalSec * 1000))
        $cur = Get-RawSnapshot
        $s = ConvertTo-Sample -Cur $cur -Prev $prev -Ncpu $Ncpu
        $prev = $cur
        if ($s) {
            $samples += $s
            $i++
            if ($OnSample) { & $OnSample $s $i }
        }
        if ($Count -gt 0 -and $i -ge $Count) { break }
        if ($DurationSec -gt 0 -and ((Get-Date) - $start).TotalSeconds -ge $DurationSec) { break }
    }
    return @($samples)
}

#endregion
#region ------------------------------------------------------------- Analiz

$script:SlowThreshold = 0.40

$script:ScoreWeights = @{
    CpuSaturation = 0.18
    CpuQueue      = 0.15
    DpcInterrupt  = 0.12
    Memory        = 0.25
    DiskLatency   = 0.22
    DiskQueue     = 0.08
}

function Get-Component {
    param([double]$Value, [double]$Floor, [double]$Span, [string]$Evidence)
    if ($null -eq $Value -or $Value -le $Floor) {
        return [pscustomobject]@{ Score = 0.0; Evidence = $null }
    }
    $s = ($Value - $Floor) / $Span
    if ($s -gt 1) { $s = 1.0 }
    [pscustomobject]@{ Score = [math]::Round($s, 3); Evidence = $Evidence }
}

function Get-SampleScore {
    param($Sample, [int]$Ncpu, [double]$TotalMemMB)
    $m = $Sample.Metrics
    $c = [ordered]@{}

    $cpu = ConvertTo-Num $m.CpuTotalPct 0
    $c['CpuSaturation'] = Get-Component -Value $cpu -Floor 80 -Span 20 `
        -Evidence ("CPU toplam %{0}" -f (Round2 $cpu))

    $q = ConvertTo-Num $m.ProcessorQueueLength 0
    $qr = if ($Ncpu -gt 0) { $q / $Ncpu } else { $q }
    $c['CpuQueue'] = Get-Component -Value $qr -Floor 1 -Span 3 `
        -Evidence ("islemci kuyrugu {0} / {1} cekirdek = {2}x" -f [int]$q, $Ncpu, (Round2 $qr))

    # DPC + kesme suresi: surucu kaynakli yuk. Dosya sistemi filtresi, ag
    # filtresi veya bozuk surucu burada gorunur; kullanici process'lerinde
    # gorunmez. Bu yuzden ayri bir bilesen.
    $dpc = (ConvertTo-Num $m.CpuDpcPct 0) + (ConvertTo-Num $m.CpuInterruptPct 0)
    $c['DpcInterrupt'] = Get-Component -Value $dpc -Floor 5 -Span 15 `
        -Evidence ("DPC+kesme %{0} (surucu/filtre kaynakli cekirdek modu yuku)" -f (Round2 $dpc))

    $memScore = 0.0; $memEv = @()
    $avail = ConvertTo-Num $m.AvailableMB 0
    if ($TotalMemMB -gt 0) {
        $availPct = $avail / $TotalMemMB * 100
        if ($availPct -lt 12) {
            $s = (12 - $availPct) / 12; if ($s -gt 1) { $s = 1 }
            if ($s -gt $memScore) { $memScore = $s }
            $memEv += ("kullanilabilir bellek %{0} ({1} MB)" -f (Round2 $availPct), [int]$avail)
        }
    }
    $commit = ConvertTo-Num $m.CommitPct 0
    if ($commit -gt 85) {
        $s = ($commit - 85) / 15; if ($s -gt 1) { $s = 1 }
        if ($s -gt $memScore) { $memScore = $s }
        $memEv += ("commit orani %{0}" -f (Round2 $commit))
    }
    $hard = ConvertTo-Num $m.HardFaultsPerSec 0
    if ($hard -gt 50) {
        $s = ($hard - 50) / 450; if ($s -gt 1) { $s = 1 }
        if ($s -gt $memScore) { $memScore = $s }
        $memEv += ("sabit sayfa hatasi {0}/sn (disk'e takas)" -f [int]$hard)
    }
    $c['Memory'] = [pscustomobject]@{
        Score = [math]::Round($memScore, 3)
        Evidence = if ($memEv.Count) { $memEv -join '; ' } else { $null }
    }

    $dr = ConvertTo-Num $m.DiskReadMs 0
    $dw = ConvertTo-Num $m.DiskWriteMs 0
    $dmax = [math]::Max($dr, $dw)
    $c['DiskLatency'] = Get-Component -Value $dmax -Floor 15 -Span 60 `
        -Evidence ("disk gecikmesi okuma {0} ms / yazma {1} ms" -f (Round2 $dr), (Round2 $dw))

    $dq = ConvertTo-Num $m.DiskQueueLength 0
    $c['DiskQueue'] = Get-Component -Value $dq -Floor 2 -Span 8 `
        -Evidence ("disk kuyrugu {0}" -f [int]$dq)

    $total = 0.0
    foreach ($k in $script:ScoreWeights.Keys) { $total += $script:ScoreWeights[$k] * $c[$k].Score }

    [pscustomobject]@{
        Ts = $m.Ts
        Score = [math]::Round($total, 3)
        Components = [pscustomobject]$c
    }
}

function Get-SlowWindows {
    param($Scores, [double]$Threshold = $script:SlowThreshold)
    $windows = @(); $cur = $null
    foreach ($s in @($Scores)) {
        if ($s.Score -ge $Threshold) {
            if (-not $cur) { $cur = [ordered]@{ Start = $s.Ts; End = $s.Ts; Items = @($s) } }
            else { $cur.End = $s.Ts; $cur.Items += $s }
        } elseif ($cur) {
            $windows += [pscustomobject]$cur; $cur = $null
        }
    }
    if ($cur) { $windows += [pscustomobject]$cur }
    foreach ($w in $windows) {
        $w | Add-Member -NotePropertyName Peak       -NotePropertyValue (@($w.Items | ForEach-Object { $_.Score }) | Measure-Object -Maximum).Maximum
        $w | Add-Member -NotePropertyName SampleCount -NotePropertyValue @($w.Items).Count
        $w | Add-Member -NotePropertyName DurationSec -NotePropertyValue ([math]::Round(($w.End - $w.Start).TotalSeconds, 1))
    }
    return @($windows)
}

function Get-Attribution {
    <#
      Yavas pencerelerdeki process davranisini normal pencerelerle karsilastirir.

      Kritik nokta: "en cok tuketen" ile "yavasligin nedeni" ayni sey degildir.
      Surekli %4 CPU yiyen bir EDR ajani, yavaslik anlarinda da %4'tedir --
      nedensel bagi yoktur. Yalnizca yavaslik aninda yukselen process aday olur.
      Bu yuzden siralama Fark (delta) ile agirliklandirilir.
    #>
    param($SampleList, $Scores, $Enrichment, [double]$Threshold = $script:SlowThreshold, [int]$TopN = 15)

    $slowTs = @{}; $normTs = @{}
    foreach ($s in @($Scores)) {
        $key = $s.Ts.Ticks
        if ($s.Score -ge $Threshold) { $slowTs[$key] = $true } else { $normTs[$key] = $true }
    }

    $agg = @{}
    foreach ($smp in @($SampleList)) {
        $key = $smp.Metrics.Ts.Ticks
        $isSlow = $slowTs.ContainsKey($key)
        $isNorm = $normTs.ContainsKey($key)
        if (-not ($isSlow -or $isNorm)) { continue }
        foreach ($p in @($smp.Processes)) {
            $n = $p.Name
            if (-not $agg.ContainsKey($n)) {
                $agg[$n] = [ordered]@{
                    SlowCpu = @(); NormCpu = @(); SlowMem = @(); SlowIo = @(); NormIo = @(); Pids = @{}
                }
            }
            $a = $agg[$n]
            $a.Pids[$p.Pid] = $true
            $io = (ConvertTo-Num $p.IoReadOpsPerSec 0) + (ConvertTo-Num $p.IoWriteOpsPerSec 0)
            if ($isSlow) {
                $a.SlowCpu += (ConvertTo-Num $p.CpuPct 0)
                $a.SlowMem += (ConvertTo-Num $p.PrivateMB 0)
                $a.SlowIo  += $io
            } else {
                $a.NormCpu += (ConvertTo-Num $p.CpuPct 0)
                $a.NormIo  += $io
            }
        }
    }

    $slowCount = $slowTs.Count
    $rows = @()
    foreach ($n in $agg.Keys) {
        $a = $agg[$n]
        if (@($a.SlowCpu).Count -eq 0) { continue }
        $slowCpu = (@($a.SlowCpu) | Measure-Object -Average).Average
        $normCpu = $null
        if (@($a.NormCpu).Count -gt 0) { $normCpu = (@($a.NormCpu) | Measure-Object -Average).Average }
        $slowIo  = (@($a.SlowIo) | Measure-Object -Average).Average
        $normIo  = $null
        if (@($a.NormIo).Count -gt 0) { $normIo = (@($a.NormIo) | Measure-Object -Average).Average }
        $presence = if ($slowCount -gt 0) { @($a.SlowCpu).Count / $slowCount } else { 0 }

        $delta = $null
        if ($null -ne $normCpu) { $delta = $slowCpu - $normCpu }
        $boost = 1.0
        if ($null -ne $delta -and $delta -gt 0) {
            $b = $delta; if ($b -gt 50) { $b = 50 }
            $boost = 1.0 + ($b / 25)
        }

        $e = $null
        foreach ($pid_ in $a.Pids.Keys) { if ($Enrichment.ContainsKey($pid_)) { $e = $Enrichment[$pid_]; break } }

        $rows += [pscustomobject]@{
            Name          = $n
            Pids          = @($a.Pids.Keys | Sort-Object | Select-Object -First 4)
            SlowCpuPct    = Round2 $slowCpu
            NormCpuPct    = Round2 $normCpu
            CpuDelta      = Round2 $delta
            SlowPrivateMB = [int]((@($a.SlowMem) | Measure-Object -Average).Average)
            SlowIoOps     = [int]$slowIo
            NormIoOps     = if ($null -ne $normIo) { [int]$normIo } else { $null }
            IoDelta       = if ($null -ne $normIo) { [int]($slowIo - $normIo) } else { $null }
            SamplesSlow   = @($a.SlowCpu).Count
            SamplesNormal = @($a.NormCpu).Count
            Presence      = [math]::Round($presence, 2)
            Vendor        = if ($e) { $e.Vendor } else { $null }
            Category      = if ($e) { $e.Category } else { $null }
            Services      = if ($e) { @($e.Services) } else { @() }
            Path          = if ($e) { $e.Path } else { $null }
            Score         = [math]::Round($slowCpu * $presence * $boost, 2)
        }
    }

    [pscustomobject]@{
        SlowSampleCount   = $slowCount
        NormalSampleCount = $normTs.Count
        Comparable        = ($normTs.Count -gt 0)
        ByCpu             = @($rows | Sort-Object Score -Descending | Select-Object -First $TopN)
        ByIo              = @($rows | Sort-Object SlowIoOps -Descending | Select-Object -First $TopN)
        ByMemory          = @($rows | Sort-Object SlowPrivateMB -Descending | Select-Object -First $TopN)
        All               = @($rows)
    }
}

function Get-AgentTax {
    <#
      "Guvenlik ajani vergisi": etiketlenmis ajanlarin toplam CPU, disk islemi
      ve bellek payi. Kullanicinin "bir suru ajan var" sezgisini sayiya cevirir.

      Onemli sinir: bu, ajanlarin DOGRUDAN tukettigidir. Minifilter suruculerinin
      cekirdek modunda urettigi gecikme buraya YANSIMAZ -- o, kurbanin
      (Explorer, derleyici, Office) I/O bekleme suresi olarak gorunur. Bu yuzden
      DPC/kesme yuzdesi ve disk gecikmesi ayrica raporlanir.
    #>
    param($SampleList, $Enrichment)

    $byCat = @{}
    $totalCpu = 0.0; $agentCpu = 0.0
    $totalIo  = 0.0; $agentIo  = 0.0
    $agentMem = 0.0
    $n = 0

    foreach ($smp in @($SampleList)) {
        $n++
        foreach ($p in @($smp.Processes)) {
            $cpu = ConvertTo-Num $p.CpuPct 0
            $io  = (ConvertTo-Num $p.IoReadOpsPerSec 0) + (ConvertTo-Num $p.IoWriteOpsPerSec 0)
            $totalCpu += $cpu; $totalIo += $io
            $e = $Enrichment[$p.Pid]
            if ($e -and $e.Category) {
                $agentCpu += $cpu; $agentIo += $io
                $agentMem += (ConvertTo-Num $p.PrivateMB 0)
                $cat = $e.Category
                if (-not $byCat.ContainsKey($cat)) {
                    $byCat[$cat] = [ordered]@{ Cpu = 0.0; Io = 0.0; Mem = 0.0; Vendors = @{} }
                }
                $byCat[$cat].Cpu += $cpu
                $byCat[$cat].Io  += $io
                $byCat[$cat].Mem += (ConvertTo-Num $p.PrivateMB 0)
                if ($e.Vendor) { $byCat[$cat].Vendors[$e.Vendor] = $true }
            }
        }
    }
    if ($n -eq 0) { $n = 1 }

    $cats = @()
    foreach ($k in $byCat.Keys) {
        $cats += [pscustomobject]@{
            Category      = $k
            AvgCpuPct     = Round2 ($byCat[$k].Cpu / $n)
            AvgIoOpsPerSec= [int]($byCat[$k].Io / $n)
            AvgPrivateMB  = [int]($byCat[$k].Mem / $n)
            Vendors       = @($byCat[$k].Vendors.Keys | Sort-Object)
        }
    }

    $identified = @()
    foreach ($pid_ in $Enrichment.Keys) {
        $e = $Enrichment[$pid_]
        if ($e.Category) {
            $identified += [pscustomobject]@{
                Pid = $pid_; Vendor = $e.Vendor; Category = $e.Category
                Source = $e.AgentSource; Path = $e.Path; Services = @($e.Services)
            }
        }
    }

    [pscustomobject]@{
        AgentAvgCpuPct   = Round2 ($agentCpu / $n)
        SystemAvgCpuPct  = Round2 ($totalCpu / $n)
        CpuSharePct      = if ($totalCpu -gt 0) { Round2 ($agentCpu / $totalCpu * 100) } else { $null }
        AgentAvgIoOps    = [int]($agentIo / $n)
        SystemAvgIoOps   = [int]($totalIo / $n)
        IoSharePct       = if ($totalIo -gt 0) { Round2 ($agentIo / $totalIo * 100) } else { $null }
        AgentAvgMemMB    = [int]($agentMem / $n)
        ByCategory       = @($cats | Sort-Object AvgCpuPct -Descending)
        Identified       = @($identified | Sort-Object Vendor, Pid)
        DistinctVendors  = @($identified | ForEach-Object { $_.Vendor } | Sort-Object -Unique)
    }
}

function New-Finding {
    param([string]$Severity, [string]$Title, [string[]]$Evidence, [string]$Note)
    [pscustomobject]@{ Severity = $Severity; Title = $Title; Evidence = @($Evidence); Note = $Note }
}

function Get-Findings {
    param($Caps, $Static, $Scores, $Windows, $Attribution, $AgentTax)

    $f = @()
    $sev = @{ K = 'kritik'; Y = 'yuksek'; O = 'orta'; B = 'bilgi' }

    # --- dinamik ---
    if (@($Scores).Count -gt 0) {
        $avg  = (@($Scores) | ForEach-Object { $_.Score } | Measure-Object -Average).Average
        $peak = (@($Scores) | ForEach-Object { $_.Score } | Measure-Object -Maximum).Maximum

        if (@($Windows).Count -eq 0) {
            $f += New-Finding $sev.B 'Olcum suresince yavas pencere olusmadi' `
                @(("ortalama basinc skoru {0}, tepe {1} (esik {2})" -f (Round2 $avg), (Round2 $peak), $script:SlowThreshold)) `
                'Yavaslik araliksa Monitor modunu is gunu boyunca calistirip olayin yasandigi ani yakalamak gerekir.'
        } else {
            $slowN = (@($Windows) | ForEach-Object { $_.SampleCount } | Measure-Object -Sum).Sum
            $ratio = $slowN / @($Scores).Count
            $ev = @()
            $i = 0
            foreach ($w in @($Windows) | Select-Object -First 6) {
                $i++
                $ev += ("pencere {0}: {1}, {2} sn, tepe skor {3}" -f $i, $w.Start.ToString('HH:mm:ss'), $w.DurationSec, (Round2 $w.Peak))
            }
            $f += New-Finding $(if ($ratio -gt 0.3) { $sev.Y } else { $sev.O }) `
                ("{0} yavas pencere tespit edildi ({1}/{2} ornek)" -f @($Windows).Count, $slowN, @($Scores).Count) `
                $ev ''

            # baskin bilesen (agirlikli katki)
            $tot = @{}
            foreach ($s in @($Scores)) {
                if ($s.Score -lt $script:SlowThreshold) { continue }
                foreach ($k in $script:ScoreWeights.Keys) {
                    if (-not $tot.ContainsKey($k)) { $tot[$k] = 0.0 }
                    $tot[$k] += $script:ScoreWeights[$k] * $s.Components.$k.Score
                }
            }
            $labels = @{
                CpuSaturation = 'CPU doygunlugu'; CpuQueue = 'islemci kuyrugu'
                DpcInterrupt  = 'surucu/filtre kaynakli cekirdek modu yuku (DPC+kesme)'
                Memory = 'bellek basinci'; DiskLatency = 'disk gecikmesi'; DiskQueue = 'disk kuyrugu'
            }
            $ranked = @($tot.GetEnumerator() | Sort-Object Value -Descending)
            if ($ranked.Count -gt 0 -and $ranked[0].Value -gt 0) {
                $ev = @()
                foreach ($r in $ranked | Select-Object -First 3) {
                    if ($r.Value -le 0) { continue }
                    $sample = $null
                    foreach ($s in @($Scores)) {
                        if ($s.Score -ge $script:SlowThreshold -and $s.Components.($r.Key).Evidence) {
                            $sample = $s.Components.($r.Key).Evidence; break
                        }
                    }
                    $line = "{0} (agirlikli katki {1})" -f $labels[$r.Key], (Round2 $r.Value)
                    if ($sample) { $line += " -- ornek: $sample" }
                    $ev += $line
                }
                $f += New-Finding $sev.Y ("Yavasligin baskin bileseni: {0}" -f $labels[$ranked[0].Key]) $ev `
                    'Iyilestirme cabasi once bu bilesene yonelmelidir.'
            }
        }

        # DPC/kesme ozel uyarisi -- filtre surucusu parmak izi
        # 0.30 skor ~ %9.5 DPC+kesme demektir. Istemci makinesinde normal deger
        # %1-2'dir; surekli %9-10, surucu yiginini incelemek icin yeterli sinyaldir.
        $dpcVals = @($Scores | ForEach-Object { $_.Components.DpcInterrupt.Score })
        if (($dpcVals | Measure-Object -Maximum).Maximum -ge 0.30) {
            $f += New-Finding $sev.Y 'Cekirdek modu (DPC + kesme) yuku yuksek' `
                @($Scores | Where-Object { $_.Components.DpcInterrupt.Evidence } |
                    Select-Object -First 4 | ForEach-Object { "$($_.Ts.ToString('HH:mm:ss')): $($_.Components.DpcInterrupt.Evidence)" }) `
                ('Bu yuk hicbir kullanici process''inde gorunmez; surucu kaynaklidir. En sik nedenleri: ust uste binmis dosya sistemi filtreleri (AV/DLP/sifreleme), ag filtre suruculeri ve eski depolama suruculeri. Rapordaki filtre yigini bolumuyle birlikte degerlendirin.')
        }

        # disk gecikmesi
        $lat = @($Scores | Where-Object { $_.Components.DiskLatency.Score -gt 0.3 })
        if ($lat.Count -gt 0) {
            $f += New-Finding $sev.Y 'Disk gecikmesi normalin uzerinde' `
                @($lat | Select-Object -First 4 | ForEach-Object { "$($_.Ts.ToString('HH:mm:ss')): $($_.Components.DiskLatency.Evidence)" }) `
                'NVMe SSD''de 1-2 ms, SATA SSD''de 2-5 ms beklenir. 15 ms uzeri surekli degerler, ya donanim sorununu ya da her I/O islemini inceleyen bir filtre yiginini gosterir.'
        }
    }

    # --- suclu adaylari ---
    if (@($Attribution.ByCpu).Count -gt 0 -and $Attribution.SlowSampleCount -gt 0) {
        $ev = @()
        foreach ($r in @($Attribution.ByCpu) | Select-Object -First 5) {
            $line = "{0} (PID {1}): yavas pencerelerde ort. CPU %{2}" -f $r.Name, ($r.Pids -join ','), $r.SlowCpuPct
            if ($null -ne $r.NormCpuPct) { $line += ", normalde %{0} (fark {1:+0.00;-0.00;0})" -f $r.NormCpuPct, $r.CpuDelta }
            $line += "; {0}/{1} yavas ornekte mevcut" -f $r.SamplesSlow, $Attribution.SlowSampleCount
            if ($r.Vendor) { $line += " [{0} / {1}]" -f $r.Vendor, $r.Category }
            $ev += $line
        }
        $note = ''
        if (-not $Attribution.Comparable) {
            $note = 'UYARI: karsilastirilacak normal pencere yok. Bu siralama "yavaslik aninda en cok tuketenler" demektir; nedensellik KANITLANMAMISTIR.'
        }
        $f += New-Finding $sev.Y 'CPU tarafinda basli adaylar' $ev $note
    }

    # --- ajan vergisi ---
    if ($AgentTax.DistinctVendors.Count -gt 0) {
        $ev = @(("Tespit edilen guvenlik/yonetim saglayicisi: {0}" -f ($AgentTax.DistinctVendors -join ', ')))
        if ($null -ne $AgentTax.CpuSharePct) {
            $ev += ("Ajanlarin CPU payi: olculen toplam CPU'nun %{0}'i (ort. %{1} mutlak)" -f $AgentTax.CpuSharePct, $AgentTax.AgentAvgCpuPct)
        }
        if ($null -ne $AgentTax.IoSharePct) {
            $ev += ("Ajanlarin disk islemi payi: %{0} ({1} islem/sn)" -f $AgentTax.IoSharePct, $AgentTax.AgentAvgIoOps)
        }
        $ev += ("Ajanlarin ozel bellek toplami: {0} MB" -f $AgentTax.AgentAvgMemMB)
        $sevAgent = $sev.B
        if ($AgentTax.CpuSharePct -gt 25 -or $AgentTax.IoSharePct -gt 40) { $sevAgent = $sev.Y }
        elseif ($AgentTax.CpuSharePct -gt 12) { $sevAgent = $sev.O }
        $f += New-Finding $sevAgent ("Guvenlik/yonetim ajani yuku: {0} farkli saglayici" -f $AgentTax.DistinctVendors.Count) $ev `
            'Bu rakam ajanlarin DOGRUDAN tukettigidir. Filtre suruculerinin cekirdek modunda urettigi gecikme buraya yansimaz; o, kurban uygulamalarin I/O bekleme suresi olarak gorunur.'
    }

    # --- filtre yigini ---
    $mf = @($Static.MiniFilters.Registry | Where-Object { $_.Running })
    if ($mf.Count -gt 0) {
        $byGroup = @($mf | Group-Object Group | Sort-Object Count -Descending)
        $ev = @()
        foreach ($g in $byGroup) {
            $ev += "{0}: {1} adet -- {2}" -f $g.Name, $g.Count, (@($g.Group | ForEach-Object { $_.Name }) -join ', ')
        }
        $avCount = @($mf | Where-Object { $_.Group -like '*Anti-Virus*' }).Count
        $sevMf = $sev.B
        if ($avCount -ge 3 -or $mf.Count -ge 12) { $sevMf = $sev.Y }
        elseif ($avCount -ge 2 -or $mf.Count -ge 8) { $sevMf = $sev.O }
        $f += New-Finding $sevMf ("Calisan dosya sistemi filtre surucusu: {0} adet ({1} tanesi Anti-Virus sinifinda)" -f $mf.Count, $avCount) $ev `
            'Her dosya acma/okuma/yazma islemi bu filtrelerin HEPSININ icinden gecer. Ayni sinifta birden fazla filtre varsa ayni dosya birden fazla kez taranir. Bunlar politika geregi kaldirilamaz; hedef, derleme dizinleri, sanal makine imajlari, kod depolari ve veritabani dosyalari icin karsilikli istisna (exclusion) tanimlamaktir.'
    }

    # --- guc plani ---
    $tm = $Static.Power.ThrottleMax
    if ($tm -and $null -ne $tm.AcMaxPct -and $tm.AcMaxPct -lt 100) {
        $f += New-Finding $sev.Y 'Maksimum islemci durumu %100''un altinda sinirlandirilmis' `
            @(("AC (prize takili) maksimum islemci durumu: %{0}" -f $tm.AcMaxPct),
              ("DC (pil) maksimum islemci durumu: %{0}" -f $tm.DcMaxPct),
              ("Aktif plan: {0}" -f $Static.Power.ActiveScheme)) `
            'CPU hicbir zaman tam hiza cikamaz. Domain GPO''su ile dayatilmissa degisiklik BT tarafindan yapilmalidir; kullanici degistiremez.'
    }
    $clk = $Static.Power.Clock
    if ($clk -and $clk.MaxMHz -gt 0 -and $clk.CurrentMHz -gt 0) {
        $ratio = $clk.CurrentMHz / $clk.MaxMHz
        if ($ratio -lt 0.75) {
            $f += New-Finding $sev.O 'islemci frekansi nominalin belirgin altinda' `
                @(("anlik {0} MHz / nominal {1} MHz (%{2})" -f $clk.CurrentMHz, $clk.MaxMHz, [math]::Round($ratio * 100, 0))) `
                'Termal kisitlama, guc plani siniri veya firmware ayari olabilir. Guc plani zaten %100 ise termal tarafi incelenmelidir.'
        }
    }

    # --- disk doluluk ---
    foreach ($v in @($Static.Storage.Volumes)) {
        if ($null -ne $v.FreePct -and $v.FreePct -lt 12) {
            $f += New-Finding $(if ($v.FreePct -lt 6) { $sev.Y } else { $sev.O }) `
                ("Disk doluluk orani kritik: {0}" -f $v.Drive) `
                @(("{0} bos {1} GB / {2} GB (%{3})" -f $v.Drive, $v.FreeGB, $v.SizeGB, $v.FreePct)) `
                'Bos alan azaldiginda sayfa dosyasi genisleyemez ve NTFS parcalanmasi artar; sistem geneli yavaslar.'
        }
    }

    # --- donen disk ---
    $hdd = @($Static.Storage.Physical | Where-Object { $_.MediaType -eq 'HDD' })
    if ($hdd.Count -gt 0) {
        $f += New-Finding $sev.Y 'Sistemde mekanik disk (HDD) var' `
            @($hdd | ForEach-Object { "{0} -- {1} GB, {2}" -f $_.Name, $_.SizeGB, $_.BusType }) `
            'Windows 11 + bir AV ajani + mekanik disk kombinasyonu tek basina ciddi yavaslik uretir. Filtre yigini ile birleştiginde etki carpanlanir. Kalici cozum SSD''dir.'
    }

    # --- VBS / HVCI ---
    $dg = $Static.Posture.DeviceGuard
    if ($dg -and ($dg.EnableVirtualizationBasedSecurity -eq 1 -or $dg.HvciEnabled -eq 1)) {
        $f += New-Finding $sev.B 'Sanallastirma tabanli guvenlik (VBS/HVCI) etkin' `
            @(("VBS: {0}, HVCI: {1}" -f $dg.EnableVirtualizationBasedSecurity, $dg.HvciEnabled)) `
            'HVCI, surucu yogun ve I/O yogun is yuklerinde olculebilir ek yuk getirir. Guvenlik gereksinimi oldugu icin kapatmak genellikle secenek degildir; not olarak kayda gecirilir.'
    }

    # --- acilis olaylari ---
    if ($Static.Events -and @($Static.Events.Boot).Count -gt 0) {
        $degr = @($Static.Events.Boot | Where-Object { $_.Id -in 101, 102, 103, 109 } | Select-Object -First 6)
        if ($degr.Count -gt 0) {
            $f += New-Finding $sev.O 'Acilisi yavaslatan bilesenler olay gunlugunde kayitli' `
                @($degr | ForEach-Object { "{0} [ID {1}] {2}" -f $_.Time, $_.Id, ($_.Message.Substring(0, [math]::Min(220, $_.Message.Length))) }) `
                'Bu olaylar yavaslatan uygulamayi/servisi adiyla ve milisaniye cinsinden sureyle verir; dogrudan eyleme donusturulebilir.'
        }
    }

    # --- kaynak tukenmesi ---
    if ($Static.Events) {
        $ex = @($Static.Events.System | Where-Object { $_.Id -eq 2004 } | Select-Object -First 3)
        if ($ex.Count -gt 0) {
            $f += New-Finding $sev.Y 'Windows kaynak tukenmesi uyarisi vermis (Event ID 2004)' `
                @($ex | ForEach-Object { "{0}: {1}" -f $_.Time, ($_.Message.Substring(0, [math]::Min(220, $_.Message.Length))) }) `
                'Bu, sanal bellegin gercekten tukendiginin kesin kanitidir. Ayar degil, es zamanli is yukunun azaltilmasi veya RAM artirimi gerekir.'
        }
    }

    # --- olculemeyenler ---
    foreach ($w in @($script:Warnings | Group-Object Source)) {
        $null = $w
    }
    if (-not $Caps.Elevated) {
        $f += New-Finding $sev.B 'Standart kullanici yetkisiyle calisildi' `
            @('fltmc (yuklu filtre yigini) okunamadi -- kayit defteri + Win32_SystemDriver ile telafi edildi',
              'Acilis performans olaylari ve bazi olay gunlukleri erisilemeyebilir') `
            'Yonetici hesabiyla tekrar calistirmak filtre yigininin GERCEK yuklenme sirasini ve acilis olaylarini ekler. Mevcut bulgular bundan bagimsiz olarak gecerlidir.'
    }

    return @($f)
}

#endregion
#region -------------------------------------------------------------- Rapor

function ConvertTo-HtmlText {
    param($Value)
    if ($null -eq $Value) { return '-' }
    $s = [string]$Value
    $s = $s -replace '&', '&amp;' -replace '<', '&lt;' -replace '>', '&gt;' -replace '"', '&quot;'
    return $s
}

function New-HtmlTable {
    param([string[]]$Headers, $Rows, [string[]]$Fields)
    $sb = @()
    $sb += '<table><thead><tr>'
    foreach ($h in $Headers) { $sb += "<th>$(ConvertTo-HtmlText $h)</th>" }
    $sb += '</tr></thead><tbody>'
    foreach ($r in @($Rows)) {
        $sb += '<tr>'
        foreach ($fld in $Fields) {
            $v = $r.$fld
            if ($v -is [array]) { $v = ($v -join ', ') }
            $sb += "<td>$(ConvertTo-HtmlText $v)</td>"
        }
        $sb += '</tr>'
    }
    $sb += '</tbody></table>'
    return ($sb -join '')
}

$script:HtmlStyle = @'
<style>
:root{--bg:#0f1115;--card:#171a21;--fg:#e6e8ee;--mut:#9aa3b2;--line:#262b36;
--k:#ff5c5c;--y:#ff9f43;--o:#ffd166;--b:#5aa9e6;--ok:#4cc38a}
*{box-sizing:border-box}
body{margin:0;padding:24px;background:var(--bg);color:var(--fg);
font-family:"Segoe UI",system-ui,sans-serif;font-size:14px;line-height:1.55}
h1{font-size:22px;margin:0 0 4px}h2{font-size:17px;margin:28px 0 10px;
padding-bottom:6px;border-bottom:1px solid var(--line)}h3{font-size:15px;margin:18px 0 8px}
.sub{color:var(--mut);margin-bottom:18px}
.card{background:var(--card);border:1px solid var(--line);border-radius:8px;
padding:14px 16px;margin:10px 0}
table{border-collapse:collapse;width:100%;margin:8px 0;font-size:13px}
th,td{border:1px solid var(--line);padding:6px 9px;text-align:left;vertical-align:top}
th{background:#1d212a;color:var(--mut);font-weight:600;white-space:nowrap}
tr:nth-child(even) td{background:#13161c}
code{background:#0b0d11;padding:2px 5px;border-radius:3px;font-size:12px;
color:#c8d3e0;word-break:break-all}
.sev{display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px;
font-weight:700;letter-spacing:.4px;margin-right:8px}
.sev-kritik{background:var(--k);color:#111}.sev-yuksek{background:var(--y);color:#111}
.sev-orta{background:var(--o);color:#111}.sev-bilgi{background:var(--b);color:#111}
ul{margin:6px 0 6px 18px;padding:0}li{margin:3px 0}
.note{color:var(--mut);font-size:13px;margin-top:8px;border-left:2px solid var(--line);padding-left:10px}
.warn{border-left:3px solid var(--y);padding-left:12px;margin:10px 0;color:#ffd7a8}
.slow{color:var(--k);font-weight:700}
.metric{display:inline-block;margin-right:26px}
.metric b{display:block;font-size:20px}.metric span{color:var(--mut);font-size:12px}
footer{margin-top:34px;color:var(--mut);font-size:12px;border-top:1px solid var(--line);padding-top:12px}
</style>
'@

function New-HtmlReport {
    param($Run)

    $caps  = $Run.Capabilities
    $stat  = $Run.Static
    $scr   = @($Run.Scores)
    $win   = @($Run.SlowWindows)
    $attr  = $Run.Attribution
    $tax   = $Run.AgentTax
    $find  = @($Run.Findings)

    $h = @()
    $h += '<!DOCTYPE html><html lang="tr"><head><meta charset="utf-8">'
    $h += '<title>WinPerfDiag Raporu</title>' + $script:HtmlStyle + '</head><body>'
    $h += "<h1>WinPerfDiag Performans Raporu</h1>"
    $h += "<div class='sub'>$(ConvertTo-HtmlText $caps.ComputerName) &nbsp;|&nbsp; $(ConvertTo-HtmlText $caps.UserName) &nbsp;|&nbsp; $($Run.StartedAt) &nbsp;|&nbsp; $(@($Run.Samples).Count) örnek &nbsp;|&nbsp; $(if ($caps.Elevated) { 'yönetici' } else { 'standart kullanıcı' })</div>"

    # --- 1. Özet ---
    $h += '<h2>1. Yönetici özeti</h2>'
    $order = @{ kritik = 0; yuksek = 1; orta = 2; bilgi = 3 }
    $ranked = @($find | Sort-Object { $order[$_.Severity] })
    $action = @($ranked | Where-Object { $_.Severity -ne 'bilgi' })
    if ($action.Count -eq 0) {
        $h += "<div class='card'>Eyleme dönük bulgu yok. Ölçülemeyen kaynaklar listesini yine de gözden geçirin.</div>"
    } else {
        $h += "<div class='card'><ul>"
        foreach ($f in $action | Select-Object -First 8) {
            $h += "<li><span class='sev sev-$($f.Severity)'>$($f.Severity.ToUpper())</span>$(ConvertTo-HtmlText $f.Title)</li>"
        }
        $h += '</ul></div>'
    }

    if ($tax -and $tax.DistinctVendors.Count -gt 0) {
        $h += "<div class='card'>"
        $h += "<span class='metric'><b>$($tax.DistinctVendors.Count)</b><span>farklı güvenlik/yönetim sağlayıcısı</span></span>"
        $h += "<span class='metric'><b>%$($tax.CpuSharePct)</b><span>ölçülen CPU'nun ajan payı</span></span>"
        $h += "<span class='metric'><b>%$($tax.IoSharePct)</b><span>disk işlemlerinin ajan payı</span></span>"
        $h += "<span class='metric'><b>$($tax.AgentAvgMemMB) MB</b><span>ajanların özel belleği</span></span>"
        $h += '</div>'
    }

    # --- 2. Kapsam ---
    $h += '<h2>2. Ölçüm kapsamı ve sınırları</h2>'
    $probeRows = @()
    $probeLabels = [ordered]@{
        PerfProc    = 'Process başına performans sayaçları'
        PerfDisk    = 'Disk performans sayaçları (gecikme)'
        PerfOS      = 'Sistem sayaçları (kuyruk, bağlam değişimi)'
        PerfCpu     = 'İşlemci sayaçları (DPC/kesme)'
        Services    = 'Servis envanteri'
        SysDriver   = 'Sürücü durumu (Win32_SystemDriver)'
        Registry    = 'Kayıt defteri (minifilter altitude/Group)'
        SchedTask   = 'Zamanlanmış görevler'
        EventSystem = 'Sistem olay günlüğü'
        EventBoot   = 'Açılış performansı olay günlüğü'
        EventGpo    = 'Grup İlkesi olay günlüğü'
        Fltmc       = 'fltmc (yüklü filtre yığını) — yönetici gerekir'
        Defender    = 'Microsoft Defender durumu'
        PhysDisk    = 'Fiziksel disk bilgisi (SSD/HDD)'
    }
    foreach ($k in $probeLabels.Keys) {
        $ok = $false
        if ($caps.Probe -and $caps.Probe[$k]) { $ok = [bool]$caps.Probe[$k] }
        $probeRows += [pscustomobject]@{
            Kaynak = $probeLabels[$k]
            Durum  = $(if ($ok) { 'açık' } else { 'KAPALI' })
        }
    }
    $h += (New-HtmlTable -Headers @('Kaynak', 'Durum') -Rows $probeRows -Fields @('Kaynak', 'Durum'))

    if (@($Run.Gaps).Count -gt 0) {
        $h += "<h3>Ölçülemeyenler</h3><div class='card'><ul>"
        foreach ($g in @($Run.Gaps | Group-Object Source | Select-Object -First 20)) {
            $h += "<li><code>$(ConvertTo-HtmlText $g.Name)</code> — $(ConvertTo-HtmlText $g.Group[0].Reason)</li>"
        }
        $h += '</ul><div class="note">Bu satırlar raporda &quot;sorun yok&quot; anlamına gelmez; &quot;ölçülmedi&quot; anlamına gelir.</div></div>'
    }

    # --- 3. Sistem ---
    $h += '<h2>3. Sistem</h2>'
    $sysRows = @(
        [pscustomobject]@{ A = 'Model';       B = $caps.Model },
        [pscustomobject]@{ A = 'İşlemci';     B = $caps.CpuName },
        [pscustomobject]@{ A = 'Mantıksal çekirdek'; B = $caps.LogicalCpu },
        [pscustomobject]@{ A = 'RAM';         B = "$($caps.TotalMemoryMB) MB" },
        [pscustomobject]@{ A = 'İşletim sistemi'; B = "$($caps.OsCaption) ($($caps.OsVersion) build $($caps.OsBuild))" },
        [pscustomobject]@{ A = 'Son açılış';  B = $caps.LastBootUpTime },
        [pscustomobject]@{ A = 'Domain';      B = $(if ($caps.DomainJoined) { $caps.Domain } else { 'domaine dahil değil' }) },
        [pscustomobject]@{ A = 'PowerShell';  B = "$($caps.PsVersion) / dil modu: $($caps.LanguageMode)" },
        [pscustomobject]@{ A = 'Aktif güç planı'; B = $stat.Power.ActiveScheme }
    )
    $h += (New-HtmlTable -Headers @('Alan', 'Değer') -Rows $sysRows -Fields @('A', 'B'))

    # --- 4. Zaman serisi ---
    if ($scr.Count -gt 0) {
        $h += '<h2>4. Basınç skoru zaman serisi</h2>'
        $h += "<div class='note'>Skor 0..1 arasındadır; $($script:SlowThreshold) ve üstü &quot;yavaş pencere&quot; sayılır. Bileşen ağırlıkları: bellek 0.25, disk gecikmesi 0.22, CPU doygunluğu 0.18, işlemci kuyruğu 0.15, DPC+kesme 0.12, disk kuyruğu 0.08.</div>"
        $tsRows = @()
        foreach ($s in $scr) {
            $c = $s.Components
            $tsRows += [pscustomobject]@{
                Saat = $s.Ts.ToString('HH:mm:ss'); Skor = $s.Score
                CPU = $c.CpuSaturation.Score; Kuyruk = $c.CpuQueue.Score
                DPC = $c.DpcInterrupt.Score;  Bellek = $c.Memory.Score
                Disk = $c.DiskLatency.Score;  DKuyruk = $c.DiskQueue.Score
                Durum = $(if ($s.Score -ge $script:SlowThreshold) { 'YAVAŞ' } else { '' })
            }
        }
        $h += (New-HtmlTable -Headers @('Saat','Skor','CPU','Kuyruk','DPC','Bellek','Disk gec.','Disk kuy.','Durum') `
                             -Rows $tsRows -Fields @('Saat','Skor','CPU','Kuyruk','DPC','Bellek','Disk','DKuyruk','Durum'))

        $h += '<h3>Ham sistem metrikleri</h3>'
        $mRows = @()
        foreach ($smp in @($Run.Samples)) {
            $m = $smp.Metrics
            $mRows += [pscustomobject]@{
                Saat = $m.Ts.ToString('HH:mm:ss'); Cpu = $m.CpuTotalPct; Dpc = $m.CpuDpcPct
                Int = $m.CpuInterruptPct; Kuyruk = $m.ProcessorQueueLength
                Bos = $m.AvailableMB; Commit = $m.CommitPct; Hard = $m.HardFaultsPerSec
                DR = $m.DiskReadMs; DW = $m.DiskWriteMs; DQ = $m.DiskQueueLength
                Ctx = $m.ContextSwitchesPerSec
            }
        }
        $h += (New-HtmlTable -Headers @('Saat','CPU %','DPC %','Kesme %','İşlemci kuyruğu','Boş MB','Commit %','Sabit hata/sn','Disk okuma ms','Disk yazma ms','Disk kuyruğu','Bağlam değişimi/sn') `
                             -Rows $mRows -Fields @('Saat','Cpu','Dpc','Int','Kuyruk','Bos','Commit','Hard','DR','DW','DQ','Ctx'))
    }

    if ($win.Count -gt 0) {
        $h += '<h3>Yavaş pencereler</h3>'
        $wRows = @()
        $i = 0
        foreach ($w in $win) {
            $i++
            $wRows += [pscustomobject]@{ No = $i; Bas = $w.Start.ToString('HH:mm:ss'); Sure = $w.DurationSec; Ornek = $w.SampleCount; Tepe = [math]::Round($w.Peak, 3) }
        }
        $h += (New-HtmlTable -Headers @('#','Başlangıç','Süre (sn)','Örnek','Tepe skor') -Rows $wRows -Fields @('No','Bas','Sure','Ornek','Tepe'))
    }

    # --- 5. Suçlu adayları ---
    $h += '<h2>5. Suçlu adayları</h2>'
    if (-not $attr -or @($attr.ByCpu).Count -eq 0 -or $attr.SlowSampleCount -eq 0) {
        $h += "<div class='card'>Yavaş pencere oluşmadığı için atıf yapılamadı.</div>"
    } else {
        if (-not $attr.Comparable) {
            $h += "<div class='warn'><b>Uyarı:</b> Tüm örnekler yavaş pencerede. Karşılaştırılacak normal dönem yok; aşağıdaki tablo <i>nedensellik</i> değil <i>eş zamanlı tüketim</i> gösterir.</div>"
        }
        $h += "<div class='note'><b>Fark</b> sütunu belirleyicidir: sürekli aynı yükü üreten bir process yavaşlığın nedeni olmayabilir. Yalnızca yavaşlık anında yükselen process güçlü adaydır.</div>"
        $h += (New-HtmlTable -Headers @('Process','PID','Yavaş CPU %','Normal CPU %','Fark','Özel bellek MB','Disk işl/sn','Yavaş örnekte','Sağlayıcı','Kategori','Atıf skoru') `
                             -Rows @($attr.ByCpu) `
                             -Fields @('Name','Pids','SlowCpuPct','NormCpuPct','CpuDelta','SlowPrivateMB','SlowIoOps','SamplesSlow','Vendor','Category','Score'))
        $h += '<h3>Disk işlemi üretenler</h3>'
        $h += (New-HtmlTable -Headers @('Process','PID','Yavaş disk işl/sn','Normal disk işl/sn','Fark','Sağlayıcı','Kategori') `
                             -Rows @($attr.ByIo) -Fields @('Name','Pids','SlowIoOps','NormIoOps','IoDelta','Vendor','Category'))
        $h += '<h3>Bellek tüketenler</h3>'
        $h += (New-HtmlTable -Headers @('Process','Özel bellek MB','Yavaş CPU %','Sağlayıcı') `
                             -Rows @($attr.ByMemory) -Fields @('Name','SlowPrivateMB','SlowCpuPct','Vendor'))
    }

    # --- 6. Ajan yükü ---
    $h += '<h2>6. Güvenlik ve yönetim ajanı yükü</h2>'
    if ($tax -and $tax.DistinctVendors.Count -gt 0) {
        $h += (New-HtmlTable -Headers @('Kategori','Ort. CPU %','Ort. disk işl/sn','Ort. özel bellek MB','Sağlayıcılar') `
                             -Rows @($tax.ByCategory) -Fields @('Category','AvgCpuPct','AvgIoOpsPerSec','AvgPrivateMB','Vendors'))
        $h += '<h3>Tespit edilen ajan process''leri</h3>'
        $h += (New-HtmlTable -Headers @('PID','Sağlayıcı','Kategori','Tespit kaynağı','Servis','Yol') `
                             -Rows @($tax.Identified) -Fields @('Pid','Vendor','Category','Source','Services','Path'))
        $h += "<div class='note'>Bu rakamlar ajanların <b>doğrudan</b> tükettiğidir. Minifilter sürücülerinin çekirdek modunda ürettiği gecikme buraya yansımaz; o yük, kurban uygulamaların I/O bekleme süresi ve DPC yüzdesi olarak görünür.</div>"
    } else {
        $h += "<div class='card'>Katalogda tanınan güvenlik/yönetim ajanı process'i tespit edilmedi.</div>"
    }

    # --- 7. Filtre yığını ---
    $h += '<h2>7. Dosya sistemi filtre yığını</h2>'
    $mfAll = @($stat.MiniFilters.Registry)
    $mfRun = @($mfAll | Where-Object { $_.Running })
    $h += "<div class='note'>Her dosya açma/okuma/yazma işlemi, çalışan bu filtrelerin <b>hepsinin</b> içinden geçer. Sınıflandırma altitude numarasından tahmin edilmez; kayıt defterindeki <code>Group</code> değeri doğrudan okunur. Yükseklik (altitude) azalan sırada listelenir — üsttekiler I/O yolunda önce çalışır.</div>"
    $h += "<div class='card'>Kayıtlı: $($mfAll.Count) &nbsp;|&nbsp; Çalışıyor: $($mfRun.Count)</div>"
    $h += (New-HtmlTable -Headers @('Sürücü','Görünen ad','Grup (sınıf)','Altitude','Çalışıyor','Durum') `
                         -Rows $mfAll -Fields @('Name','DisplayName','Group','Altitude','Running','State'))
    if ($stat.MiniFilters.Fltmc) {
        $h += '<h3>fltmc filters (yönetici ile okundu)</h3>'
        $h += "<div class='card'><code>$(ConvertTo-HtmlText (($stat.MiniFilters.Fltmc) -join "`n"))</code></div>"
    }

    # --- 8. Depolama ve güç ---
    $h += '<h2>8. Depolama ve güç</h2>'
    $h += (New-HtmlTable -Headers @('Sürücü','Boyut GB','Boş GB','Boş %','Dosya sistemi') `
                         -Rows @($stat.Storage.Volumes) -Fields @('Drive','SizeGB','FreeGB','FreePct','FileSystem'))
    if (@($stat.Storage.Physical).Count -gt 0) {
        $h += (New-HtmlTable -Headers @('Fiziksel disk','Ortam','Bağlantı','Boyut GB','Sağlık') `
                             -Rows @($stat.Storage.Physical) -Fields @('Name','MediaType','BusType','SizeGB','Health'))
    }
    if (@($stat.Storage.PageFiles).Count -gt 0) {
        $h += (New-HtmlTable -Headers @('Sayfa dosyası','Ayrılan MB','Kullanılan MB','Tepe MB') `
                             -Rows @($stat.Storage.PageFiles) -Fields @('Path','AllocatedMB','CurrentMB','PeakMB'))
    }
    $tm = $stat.Power.ThrottleMax
    if ($tm) {
        $h += "<div class='card'>Maksimum işlemci durumu — AC: <b>%$($tm.AcMaxPct)</b>, DC (pil): <b>%$($tm.DcMaxPct)</b></div>"
    }

    # --- 9. Açılış / GPO ---
    if ($stat.Events) {
        $h += '<h2>9. Açılış ve Grup İlkesi olayları</h2>'
        $bootD = @($stat.Events.Boot | Where-Object { $_.Id -in 101,102,103,109 } | Select-Object -First 25)
        if ($bootD.Count -gt 0) {
            $h += '<h3>Açılışı yavaşlatan bileşenler</h3>'
            $h += (New-HtmlTable -Headers @('Zaman','Olay','Açıklama') -Rows $bootD -Fields @('Time','Id','Message'))
        }
        $gpoS = @($stat.Events.Gpo | Select-Object -First 20)
        if ($gpoS.Count -gt 0) {
            $h += '<h3>Grup İlkesi işleme</h3>'
            $h += (New-HtmlTable -Headers @('Zaman','Olay','Açıklama') -Rows $gpoS -Fields @('Time','Id','Message'))
        }
        $sysE = @($stat.Events.System | Select-Object -First 20)
        if ($sysE.Count -gt 0) {
            $h += '<h3>Sistem olayları (kaynak tükenmesi, disk, güç)</h3>'
            $h += (New-HtmlTable -Headers @('Zaman','Olay','Kaynak','Açıklama') -Rows $sysE -Fields @('Time','Id','Provider','Message'))
        }
    }

    # --- 10. Bulgular ---
    $h += '<h2>10. Bulgular (tamamı)</h2>'
    foreach ($f in $ranked) {
        $h += "<div class='card'><h3><span class='sev sev-$($f.Severity)'>$($f.Severity.ToUpper())</span>$(ConvertTo-HtmlText $f.Title)</h3>"
        if (@($f.Evidence).Count -gt 0) {
            $h += '<b>Kanıt</b><ul>'
            foreach ($e in @($f.Evidence)) { $h += "<li><code>$(ConvertTo-HtmlText $e)</code></li>" }
            $h += '</ul>'
        }
        if ($f.Note) { $h += "<div class='note'><b>Değerlendirme:</b> $(ConvertTo-HtmlText $f.Note)</div>" }
        $h += '</div>'
    }

    $h += "<footer>WinPerfDiag — tüm veri yerelde kalır, hiçbir yere gönderilmez. Üretim zamanı: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</footer>"
    $h += '</body></html>'
    return ($h -join "`n")
}

function Write-ConsoleSummary {
    param($Run)
    $tax = $Run.AgentTax
    Write-Info ''
    Write-Info '=============================================================' 'DarkGray'
    Write-Info " OZET - $($Run.Capabilities.ComputerName)" 'White'
    Write-Info '=============================================================' 'DarkGray'
    $order = @{ kritik = 0; yuksek = 1; orta = 2; bilgi = 3 }
    foreach ($f in @($Run.Findings | Sort-Object { $order[$_.Severity] }) | Where-Object { $_.Severity -ne 'bilgi' } | Select-Object -First 8) {
        $col = 'Yellow'
        if ($f.Severity -eq 'kritik') { $col = 'Red' }
        elseif ($f.Severity -eq 'orta') { $col = 'DarkYellow' }
        Write-Info ("  [{0}] {1}" -f $f.Severity.ToUpper(), $f.Title) $col
    }
    if ($tax -and $tax.DistinctVendors.Count -gt 0) {
        Write-Info ''
        Write-Info ("  Guvenlik/yonetim saglayicisi : {0}" -f ($tax.DistinctVendors -join ', ')) 'Cyan'
        Write-Info ("  Ajanlarin CPU payi           : %{0}" -f $tax.CpuSharePct) 'Cyan'
        Write-Info ("  Ajanlarin disk islemi payi   : %{0}" -f $tax.IoSharePct) 'Cyan'
    }
    Write-Info ''
}

#endregion

#region ------------------------------------------------------ Mod yurutucusu

function New-RunObject {
    param($Caps, $Static, $SampleList, $Enrichment)
    $memMB = ConvertTo-Num $Caps.TotalMemoryMB 0
    $scores = @()
    foreach ($s in @($SampleList)) { $scores += Get-SampleScore -Sample $s -Ncpu $Caps.LogicalCpu -TotalMemMB $memMB }
    $windows = Get-SlowWindows -Scores $scores
    $attr = Get-Attribution -SampleList $SampleList -Scores $scores -Enrichment $Enrichment -TopN $TopN
    $tax  = Get-AgentTax -SampleList $SampleList -Enrichment $Enrichment
    $find = Get-Findings -Caps $Caps -Static $Static -Scores $scores -Windows $windows -Attribution $attr -AgentTax $tax

    [pscustomobject]@{
        Tool         = 'WinPerfDiag'
        Version      = '1.0.0'
        StartedAt    = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
        Mode         = $Mode
        Capabilities = $Caps
        Static       = $Static
        Samples      = @($SampleList)
        Scores       = @($scores)
        SlowWindows  = @($windows)
        Attribution  = $attr
        AgentTax     = $tax
        Findings     = @($find)
        Gaps         = @($script:Warnings)
    }
}

function Resolve-DataPath {
    # LOCALAPPDATA tanimsizsa (nadir; kisitli servis hesaplari) calisma dizinine dus.
    $dp = $DataPath
    if ([string]::IsNullOrWhiteSpace($dp) -or $dp.StartsWith('\')) {
        $dp = Join-Path (Get-Location).Path 'WinPerfDiag'
    }
    if (-not (Test-Path $dp)) { $null = New-Item -ItemType Directory -Path $dp -Force }
    return $dp
}

function Save-Run {
    param($Run)
    $DataPath = Resolve-DataPath
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $base = if ($OutFile) { $OutFile -replace '\.(html?|json)$', '' } else { Join-Path $DataPath "winperfdiag-$stamp" }
    $written = @()

    if ($Format -in 'Json', 'Both') {
        $jsonPath = "$base.json"
        $Run | ConvertTo-Json -Depth 8 | Out-File -FilePath $jsonPath -Encoding UTF8
        $written += $jsonPath
    }
    if ($Format -in 'Html', 'Both') {
        $htmlPath = "$base.html"
        New-HtmlReport -Run $Run | Out-File -FilePath $htmlPath -Encoding UTF8
        $written += $htmlPath
    }
    return $written
}

function Invoke-Check {
    $caps = Get-Capabilities
    Write-Info ''
    Write-Info " Bilgisayar   : $($caps.ComputerName)" 'White'
    Write-Info " Kullanici    : $($caps.UserName)"
    Write-Info " Yetki        : $(if ($caps.Elevated) { 'YONETICI' } else { 'standart kullanici' })"
    Write-Info " Domain       : $(if ($caps.DomainJoined) { $caps.Domain } else { 'dahil degil' })"
    Write-Info " Isletim sis. : $($caps.OsCaption) build $($caps.OsBuild)"
    Write-Info " Islemci      : $($caps.CpuName) ($($caps.LogicalCpu) mantiksal cekirdek)"
    Write-Info " RAM          : $($caps.TotalMemoryMB) MB"
    Write-Info " PowerShell   : $($caps.PsVersion), dil modu: $($caps.LanguageMode)"
    Write-Info ''
    Write-Info ' Olcum kaynaklari:' 'White'
    foreach ($k in @($caps.Probe.Keys | Sort-Object)) {
        $ok = [bool]$caps.Probe[$k]
        Write-Info ("   [{0}] {1}" -f $(if ($ok) { 'x' } else { ' ' }), $k) $(if ($ok) { 'Green' } else { 'DarkGray' })
    }
    if ($caps.LanguageMode -ne 'FullLanguage') {
        Write-Info ''
        Write-Info " ! Dil modu $($caps.LanguageMode). Bazi olcumler kisitlanabilir." 'Yellow'
    }
    if (@($script:Warnings).Count -gt 0) {
        Write-Info ''
        Write-Info ' Erisilemeyenler:' 'Yellow'
        foreach ($w in @($script:Warnings | Group-Object Source)) {
            Write-Info ("   - {0}: {1}" -f $w.Name, $w.Group[0].Reason) 'DarkGray'
        }
    }
    Write-Info ''
}

function Invoke-Diag {
    Write-Info 'WinPerfDiag - tek seferlik teshis' 'White'
    Write-Info '[1/4] Yetenek tespiti...'
    $caps = Get-Capabilities
    Write-Info ("      {0} / {1} cekirdek / {2} MB RAM / {3}" -f $caps.ComputerName, $caps.LogicalCpu, $caps.TotalMemoryMB, $(if ($caps.Elevated) { 'yonetici' } else { 'standart kullanici' }))

    Write-Info '[2/4] Statik envanter...'
    $static = Get-StaticInventory -Caps $caps

    Write-Info ("[3/4] {0} ornek aliniyor (aralik {1} sn, tahmini {2} sn)..." -f $SampleCount, $Interval, [int]($SampleCount * $Interval))
    $cb = {
        param($s, $i)
        $m = $s.Metrics
        Write-Info ("      ornek {0}/{1}  CPU %{2}  DPC %{3}  bos {4} MB  disk R/W {5}/{6} ms" -f `
            $i, $SampleCount, $m.CpuTotalPct, $m.CpuDpcPct, $m.AvailableMB, $m.DiskReadMs, $m.DiskWriteMs)
    }
    $samples = Invoke-SamplingLoop -Count $SampleCount -IntervalSec $Interval -Ncpu $caps.LogicalCpu -OnSample $cb

    Write-Info '[4/4] Zenginlestirme, analiz ve rapor...'
    $enrich = Get-ProcessEnrichment -Services $static.Services
    $run = New-RunObject -Caps $caps -Static $static -SampleList $samples -Enrichment $enrich
    $files = Save-Run -Run $run
    Write-ConsoleSummary -Run $run
    foreach ($fp in $files) { Write-Info " Rapor: $fp" 'Green' }
    return $run
}

function Invoke-Monitor {
    Write-Info 'WinPerfDiag - surekli izleme (durdurmak icin Ctrl-C)' 'White'
    $caps = Get-Capabilities
    $static = Get-StaticInventory -Caps $caps
    $dp = Resolve-DataPath
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $jsonl = Join-Path $dp "monitor-$stamp.jsonl"
    Write-Info " Ham ornekler: $jsonl"

    # Monitor modunda -SampleCount / -Samples acikca verilmediyse SINIRSIZ
    # calis: "surekli izleme"nin 12 ornekte durmasi beklenmez.
    $limit = 0
    if ($PSBoundParameters.ContainsKey('SampleCount') -or $PSBoundParameters.ContainsKey('Samples')) {
        $limit = $SampleCount
    }
    if ($limit -eq 0 -and $Duration -eq 0) {
        Write-Info ' Sinirsiz izleme: durdurmak icin Ctrl-C (rapor yine de uretilir).' 'Yellow'
    }

    $samples = @()
    $cb = {
        param($s, $i)
        $m = $s.Metrics
        $line = $s | ConvertTo-Json -Depth 5 -Compress
        Add-Content -Path $jsonl -Value $line -Encoding UTF8
        Write-Info ("{0}  CPU %{1}  DPC %{2}  kuyruk {3}  bos {4} MB  disk {5}/{6} ms" -f `
            $m.Ts.ToString('HH:mm:ss'), $m.CpuTotalPct, $m.CpuDpcPct, $m.ProcessorQueueLength, $m.AvailableMB, $m.DiskReadMs, $m.DiskWriteMs)
    }

    try {
        $samples = Invoke-SamplingLoop -Count $limit -IntervalSec $Interval -Ncpu $caps.LogicalCpu `
                                       -OnSample $cb -DurationSec $Duration
    } finally {
        Write-Info ''
        Write-Info (" {0} ornek kaydedildi. Analiz ediliyor..." -f @($samples).Count)
        if (@($samples).Count -gt 0) {
            $enrich = Get-ProcessEnrichment -Services $static.Services
            $run = New-RunObject -Caps $caps -Static $static -SampleList $samples -Enrichment $enrich
            $files = Save-Run -Run $run
            Write-ConsoleSummary -Run $run
            foreach ($fp in $files) { Write-Info " Rapor: $fp" 'Green' }
        }
    }
}

function Invoke-ReportFromFile {
    if (-not $InputFile -or -not (Test-Path $InputFile)) {
        Write-Info ' -InputFile ile bir .json kosum dosyasi belirtin.' 'Red'
        return
    }
    $run = Get-Content -Path $InputFile -Raw -Encoding UTF8 | ConvertFrom-Json
    $htmlPath = if ($OutFile) { $OutFile } else { ($InputFile -replace '\.json$', '') + '.html' }
    New-HtmlReport -Run $run | Out-File -FilePath $htmlPath -Encoding UTF8
    Write-Info " Rapor: $htmlPath" 'Green'
}

#endregion

switch ($Mode) {
    'Check'   { Invoke-Check }
    'Diag'    { $null = Invoke-Diag }
    'Monitor' { Invoke-Monitor }
    'Report'  { Invoke-ReportFromFile }
}
