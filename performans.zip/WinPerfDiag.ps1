﻿<#
.SYNOPSIS
    WinPerfDiag - Windows 11 performans teshis araci (domain / cok ajanli ortamlar icin)

.DESCRIPTION
    Standart kullanici yetkileriyle calisir. Yonetici haklari varsa ek olcum
    kaynaklarini da acar, ancak gerekli degildir.

    Tasarim kararlari (onemli):
      * Get-Counter KULLANILMAZ. Turkce Windows'ta sayac isimleri de Turkcedir;
        Ingilizce isim kullanan scriptler o makinelerde calismaz. Bunun yerine
        Win32_PerfRawData_* CIM siniflari kullanilir -- bu siniflarin ozellik
        adlari isletim sistemi dilinden bagimsiz olarak Ingilizcedir.
      * Win32_PerfFormattedData_PerfDisk_LogicalDisk.AvgDisksecPerRead alani
        UInt32'dir ve saniye cinsindendir; 8 ms'lik gercek bir gecikme orada 0
        gorunur. Disk gecikmesi ham sayactan PERF_AVERAGE_TIMER formuluyle
        hesaplanir.
      * Minifilter siniflandirmasi altitude numarasindan CIKARILMAZ; kayit
        defterindeki Group degeri ("FSFilter Anti-Virus" gibi) dogrudan okunur.
      * Win32_Product ASLA sorgulanmaz -- MSI yeniden yapilandirma tetikler.

.NOTES
    PowerShell 5.1 uyumlu. Harici modul veya bagimlilik yoktur.
    Toplanan veri yerelde kalir; hicbir yere gonderilmez.
#>

[CmdletBinding()]
param(
    [ValidateSet('Check', 'Diag', 'Monitor', 'Report')]
    [string] $Mode = 'Diag',

    # DIKKAT: bu ORNEK SAYISIDIR, ornek dizisi degil. PowerShell degisken
    # adlari buyuk/kucuk harf duyarsiz oldugu icin $Samples adi, ornekleri
    # tutan $samples dizisiyle cakisiyordu; ad ayristirildi.
    [Alias('Samples')]
    [int]    $SampleCount = 12,
    [double] $Interval = 5,
    [int]    $Duration = 0,

    # Join-Path yerine string birlestirme: LOCALAPPDATA tanimsizsa Join-Path
    # parametre baglama hatasi verip tum scripti dusurur.
    [string] $DataPath = "$env:LOCALAPPDATA\WinPerfDiag",
    [string] $OutFile,
    [string] $InputFile,

    [ValidateSet('Html', 'Json', 'Both')]
    [string] $Format = 'Both',

    [int]    $TopN = 15,
    [switch] $NoEventLog,
    [switch] $Quiet
)

$ErrorActionPreference = 'Continue'
$ProgressPreference    = 'SilentlyContinue'
$script:Warnings       = @()

#region ---------------------------------------------------------- Yardimcilar

function Write-Info {
    param([string]$Message, [string]$Color = 'Gray')
    if (-not $Quiet) { Write-Host $Message -ForegroundColor $Color }
}

function Add-Gap {
    # Olculemeyen her sey kayit altina alinir. Rapor bunu "olculmedi" diye
    # gosterir; sessizce "sorun yok" diye gecmez.
    param([string]$Source, [string]$Reason)
    $script:Warnings += [pscustomobject]@{ Source = $Source; Reason = $Reason }
}

function Invoke-Safe {
    <# Hicbir olcum tum calismayi durdurmamali. Hata -> $null + kayit. #>
    param(
        [Parameter(Mandatory)] [scriptblock] $Script,
        [Parameter(Mandatory)] [string]      $Source
    )
    try {
        & $Script
    } catch {
        Add-Gap -Source $Source -Reason $_.Exception.Message
        $null
    }
}

function Get-Cim {
    # Kendi try/catch'ini tasir: scriptblock'un dinamik kapsamdan degisken
    # cozmesine guvenmez.
    param([string]$Class, [string]$Namespace = 'root\cimv2', [string]$Filter)
    $splat = @{ ClassName = $Class; Namespace = $Namespace; ErrorAction = 'Stop' }
    if ($Filter) { $splat['Filter'] = $Filter }
    try {
        Get-CimInstance @splat
    } catch {
        Add-Gap -Source "CIM:$Class" -Reason $_.Exception.Message
        $null
    }
}

function ConvertTo-Num {
    param($Value, $Default = 0)
    if ($null -eq $Value) { return $Default }
    try { return [double]$Value } catch { return $Default }
}

function Get-Rate {
    <# Kumulatif sayac -> saniyelik hiz. #>
    param($Current, $Previous, [double]$DeltaSec)
    if ($DeltaSec -le 0) { return 0 }
    $d = (ConvertTo-Num $Current) - (ConvertTo-Num $Previous)
    if ($d -lt 0) { return 0 }   # sayac sarmasi
    return $d / $DeltaSec
}

function Get-Pct100Ns {
    <# PERF_100NSEC_TIMER: 100ns birimli kumulatif sayac -> yuzde. #>
    param($Current, $Previous, $TsCurrent, $TsPrevious)
    $dt = (ConvertTo-Num $TsCurrent) - (ConvertTo-Num $TsPrevious)
    if ($dt -le 0) { return 0 }
    $dn = (ConvertTo-Num $Current) - (ConvertTo-Num $Previous)
    if ($dn -lt 0) { return 0 }
    return ($dn / $dt) * 100
}

function Get-AvgTimerMs {
    <#
      PERF_AVERAGE_TIMER (ornek: AvgDisksecPerRead).
      Deger = ((N1-N0) / Frequency) / (B1-B0), saniye cinsinden.
      Formatted sinif bu alani UInt32 saniye olarak verdigi icin milisaniyelik
      gecikmeler 0'a yuvarlanir; bu yuzden ham sayactan hesapliyoruz.
    #>
    param($N1, $N0, $B1, $B0, $Frequency)
    $dn = (ConvertTo-Num $N1) - (ConvertTo-Num $N0)
    $db = (ConvertTo-Num $B1) - (ConvertTo-Num $B0)
    $f  = ConvertTo-Num $Frequency
    if ($db -le 0 -or $f -le 0 -or $dn -lt 0) { return $null }
    return (($dn / $f) / $db) * 1000.0
}

function Round2 { param($v) if ($null -eq $v) { $null } else { [math]::Round([double]$v, 2) } }

#endregion

#region ------------------------------------------------- Yetenek / kapsam tespiti

function Test-Elevated {
    # Once whoami: ConstrainedLanguage modunda .NET tip erisimi bloke
    # olabilecegi icin harici komut daha guvenli. S-1-16-12288 = High
    # Mandatory Level, yani yukseltilmis token.
    try {
        $groups = & whoami.exe /groups 2>$null
        if ($LASTEXITCODE -eq 0 -and $groups) {
            return [bool](@($groups | Select-String -SimpleMatch 'S-1-16-12288').Count)
        }
    } catch { }
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $pr = [Security.Principal.WindowsPrincipal]$id
        return $pr.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch {
        Add-Gap -Source 'Elevation' -Reason 'Yetki seviyesi belirlenemedi; standart kullanici varsayildi'
        return $false
    }
}

function Get-Capabilities {
    $elev = Test-Elevated
    if ($null -eq $elev) { $elev = $false }

    $os  = Get-Cim -Class Win32_OperatingSystem
    $cs  = Get-Cim -Class Win32_ComputerSystem
    $cpu = @(Get-Cim -Class Win32_Processor)

    $ncpu = 0
    if ($cs) { $ncpu = [int](ConvertTo-Num $cs.NumberOfLogicalProcessors 0) }
    if ($ncpu -le 0) { $ncpu = [int](ConvertTo-Num $env:NUMBER_OF_PROCESSORS 1) }

    # Her veri kaynagini tek tek yokla: "erisebiliyor muyum?" sorusuna
    # varsayimla degil denemeyle cevap ver.
    $probe = @{}
    $probe['PerfProc']    = $null -ne (Get-Cim -Class Win32_PerfRawData_PerfProc_Process -Filter "IDProcess=4")
    $probe['PerfDisk']    = $null -ne (Get-Cim -Class Win32_PerfRawData_PerfDisk_LogicalDisk -Filter "Name='_Total'")
    $probe['PerfOS']      = $null -ne (Get-Cim -Class Win32_PerfRawData_PerfOS_System)
    $probe['PerfCpu']     = $null -ne (Get-Cim -Class Win32_PerfRawData_PerfOS_Processor -Filter "Name='_Total'")
    $probe['Services']    = $null -ne (Get-Cim -Class Win32_Service -Filter "Name='Schedule'")
    $probe['SysDriver']   = $null -ne (Get-Cim -Class Win32_SystemDriver -Filter "Name='FltMgr'")
    $probe['Registry']    = Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Services'
    $probe['SchedTask']   = $null -ne (Invoke-Safe -Source 'Get-ScheduledTask' -Script { Get-ScheduledTask -ErrorAction Stop | Select-Object -First 1 })
    $probe['EventSystem'] = $null -ne (Invoke-Safe -Source 'EventLog:System' -Script { Get-WinEvent -LogName System -MaxEvents 1 -ErrorAction Stop })
    $probe['EventBoot']   = $null -ne (Invoke-Safe -Source 'EventLog:Diagnostics-Performance' -Script {
                                Get-WinEvent -LogName 'Microsoft-Windows-Diagnostics-Performance/Operational' -MaxEvents 1 -ErrorAction Stop })
    $probe['EventGpo']    = $null -ne (Invoke-Safe -Source 'EventLog:GroupPolicy' -Script {
                                Get-WinEvent -LogName 'Microsoft-Windows-GroupPolicy/Operational' -MaxEvents 1 -ErrorAction Stop })
    $probe['Fltmc']       = $elev
    $probe['Defender']    = $null -ne (Invoke-Safe -Source 'Get-MpComputerStatus' -Script { Get-MpComputerStatus -ErrorAction Stop })
    $probe['PhysDisk']    = $null -ne (Invoke-Safe -Source 'Get-PhysicalDisk' -Script { Get-PhysicalDisk -ErrorAction Stop | Select-Object -First 1 })

    [pscustomobject]@{
        Elevated         = [bool]$elev
        UserName         = "$env:USERDOMAIN\$env:USERNAME"
        ComputerName     = $env:COMPUTERNAME
        DomainJoined     = if ($cs) { [bool]$cs.PartOfDomain } else { $null }
        Domain           = if ($cs) { $cs.Domain } else { $null }
        LogicalCpu       = $ncpu
        TotalMemoryMB    = if ($os) { [math]::Round((ConvertTo-Num $os.TotalVisibleMemorySize) / 1024, 0) } else { $null }
        OsCaption        = if ($os) { $os.Caption } else { $null }
        OsVersion        = if ($os) { $os.Version } else { $null }
        OsBuild          = if ($os) { $os.BuildNumber } else { $null }
        OsLanguage       = if ($os) { $os.OSLanguage } else { $null }
        LastBootUpTime   = if ($os) { $os.LastBootUpTime } else { $null }
        CpuName          = if ($cpu.Count -gt 0) { $cpu[0].Name } else { $null }
        Model            = if ($cs) { "$($cs.Manufacturer) $($cs.Model)" } else { $null }
        PsVersion        = $PSVersionTable.PSVersion.ToString()
        LanguageMode     = $ExecutionContext.SessionState.LanguageMode.ToString()
        Probe            = $probe
    }
}

#endregion

#region ------------------------------------------------- Guvenlik ajani katalogu

# Process adi (kucuk harf, .exe'siz) -> saglayici ve kategori.
# Kategori, yavaslik analizinde "ajan vergisi" hesabinda kullanilir.
$script:AgentCatalog = @{
    # --- EDR / AV ---
    'csfalconservice'      = @{ V = 'CrowdStrike Falcon';     C = 'EDR' }
    'csfalconcontainer'    = @{ V = 'CrowdStrike Falcon';     C = 'EDR' }
    'sentinelagent'        = @{ V = 'SentinelOne';            C = 'EDR' }
    'sentinelservicehost'  = @{ V = 'SentinelOne';            C = 'EDR' }
    'sentinelstaticengine' = @{ V = 'SentinelOne';            C = 'EDR' }
    'sentinelhelperservice'= @{ V = 'SentinelOne';            C = 'EDR' }
    'msmpeng'              = @{ V = 'Microsoft Defender';     C = 'AV' }
    'mpdefendercoreservice'= @{ V = 'Microsoft Defender';     C = 'AV' }
    'nissrv'               = @{ V = 'Microsoft Defender';     C = 'AV' }
    'mpcmdrun'             = @{ V = 'Microsoft Defender';     C = 'AV' }
    'mssense'              = @{ V = 'Defender for Endpoint';  C = 'EDR' }
    'senseir'              = @{ V = 'Defender for Endpoint';  C = 'EDR' }
    'sensece'              = @{ V = 'Defender for Endpoint';  C = 'EDR' }
    'sensendr'             = @{ V = 'Defender for Endpoint';  C = 'EDR' }
    'cyserver'             = @{ V = 'Palo Alto Cortex XDR';   C = 'EDR' }
    'cytool'               = @{ V = 'Palo Alto Cortex XDR';   C = 'EDR' }
    'cyveraservice'        = @{ V = 'Palo Alto Traps/Cortex'; C = 'EDR' }
    'repmgr'               = @{ V = 'VMware Carbon Black';    C = 'EDR' }
    'repux'                = @{ V = 'VMware Carbon Black';    C = 'EDR' }
    'repwsc'               = @{ V = 'VMware Carbon Black';    C = 'EDR' }
    'cb'                   = @{ V = 'Carbon Black';           C = 'EDR' }
    'mcshield'             = @{ V = 'Trellix / McAfee';       C = 'AV' }
    'masvc'                = @{ V = 'Trellix / McAfee ePO';   C = 'Yonetim' }
    'macmnsvc'             = @{ V = 'Trellix / McAfee ePO';   C = 'Yonetim' }
    'mfemms'               = @{ V = 'Trellix / McAfee';       C = 'AV' }
    'mfetp'                = @{ V = 'Trellix / McAfee';       C = 'AV' }
    'mfewc'                = @{ V = 'Trellix / McAfee';       C = 'AV' }
    'ccsvchst'             = @{ V = 'Symantec / Broadcom';    C = 'AV' }
    'sepmasterservice'     = @{ V = 'Symantec Endpoint';      C = 'AV' }
    'sisipsservice'        = @{ V = 'Symantec Endpoint';      C = 'EDR' }
    'tmlisten'             = @{ V = 'Trend Micro';            C = 'AV' }
    'tmbmsrv'              = @{ V = 'Trend Micro';            C = 'AV' }
    'ntrtscan'             = @{ V = 'Trend Micro';            C = 'AV' }
    'coreserviceshell'     = @{ V = 'Trend Micro Apex One';   C = 'AV' }
    'coreframeworkhost'    = @{ V = 'Trend Micro Apex One';   C = 'AV' }
    'sophosfilescanner'    = @{ V = 'Sophos';                 C = 'AV' }
    'sophosfs'             = @{ V = 'Sophos';                 C = 'AV' }
    'sophoshealth'         = @{ V = 'Sophos';                 C = 'AV' }
    'sophosntpservice'     = @{ V = 'Sophos';                 C = 'AV' }
    'avp'                  = @{ V = 'Kaspersky';              C = 'AV' }
    'ekrn'                 = @{ V = 'ESET';                   C = 'AV' }
    'bdservicehost'        = @{ V = 'Bitdefender';            C = 'AV' }
    'epsecurityservice'    = @{ V = 'Bitdefender GravityZone';C = 'AV' }
    'epintegrationservice' = @{ V = 'Bitdefender GravityZone';C = 'AV' }
    'sfc'                  = @{ V = 'Cisco Secure Endpoint';  C = 'EDR' }
    'darktraceagent'       = @{ V = 'Darktrace';              C = 'EDR' }

    # --- DLP / veri sizinti ---
    'dgagent'              = @{ V = 'Digital Guardian';       C = 'DLP' }
    'edpa'                 = @{ V = 'Symantec DLP';           C = 'DLP' }
    'dserui'               = @{ V = 'Forcepoint DLP';         C = 'DLP' }
    'wepsvc'               = @{ V = 'Forcepoint';             C = 'DLP' }
    'eipclient'            = @{ V = 'Forcepoint';             C = 'DLP' }

    # --- Ag / SWG / VPN ---
    'stagentsvc'           = @{ V = 'Netskope';               C = 'Ag/SWG' }
    'stagentui'            = @{ V = 'Netskope';               C = 'Ag/SWG' }
    'zsaservice'           = @{ V = 'Zscaler';                C = 'Ag/SWG' }
    'zsatunnel'            = @{ V = 'Zscaler';                C = 'Ag/SWG' }
    'zsatray'              = @{ V = 'Zscaler';                C = 'Ag/SWG' }
    'zsatraymanager'       = @{ V = 'Zscaler';                C = 'Ag/SWG' }
    'vpnagent'             = @{ V = 'Cisco Secure Client';    C = 'VPN' }
    'acwebsecagent'        = @{ V = 'Cisco Umbrella';         C = 'Ag/SWG' }
    'acumbrellaagent'      = @{ V = 'Cisco Umbrella';         C = 'Ag/SWG' }
    'pangps'               = @{ V = 'Palo Alto GlobalProtect';C = 'VPN' }
    'pangpa'               = @{ V = 'Palo Alto GlobalProtect';C = 'VPN' }

    # --- Yonetim / envanter / uyumluluk ---
    'ccmexec'              = @{ V = 'SCCM / MECM';            C = 'Yonetim' }
    'cmrcservice'          = @{ V = 'SCCM / MECM';            C = 'Yonetim' }
    'intunemanagementextension' = @{ V = 'Intune';            C = 'Yonetim' }
    'taniumclient'         = @{ V = 'Tanium';                 C = 'Yonetim' }
    'taniumcx'             = @{ V = 'Tanium';                 C = 'Yonetim' }
    'taniumdetectengine'   = @{ V = 'Tanium';                 C = 'EDR' }
    'besclient'            = @{ V = 'HCL BigFix';             C = 'Yonetim' }
    'qualysagent'          = @{ V = 'Qualys';                 C = 'Zafiyet' }
    'ir_agent'             = @{ V = 'Rapid7 InsightIDR';      C = 'EDR' }
    'nessusd'              = @{ V = 'Tenable Nessus';         C = 'Zafiyet' }
    'nxtsvc'               = @{ V = 'Nexthink';               C = 'Izleme' }
    'lsiagent'             = @{ V = 'Lakeside SysTrack';      C = 'Izleme' }
    '1e.client'            = @{ V = '1E Client';              C = 'Yonetim' }
    'epmagent'             = @{ V = 'Ivanti EPM';             C = 'Yonetim' }
    'rpcnet'               = @{ V = 'Absolute';               C = 'Yonetim' }

    # --- Yedekleme / senkron ---
    'code42service'        = @{ V = 'Code42 / CrashPlan';     C = 'Yedekleme' }
    'insyncclient'         = @{ V = 'Druva inSync';           C = 'Yedekleme' }
}

function Resolve-Agent {
    <# Process adindan saglayici/kategori cozumle; bilinmiyorsa imzaya bak. #>
    param([string]$Name, [string]$Company)
    $key = ($Name -replace '\.exe$', '').ToLowerInvariant()
    $key = ($key -replace '#\d+$', '')
    if ($script:AgentCatalog.ContainsKey($key)) {
        return [pscustomobject]@{
            Vendor   = $script:AgentCatalog[$key].V
            Category = $script:AgentCatalog[$key].C
            Source   = 'katalog'
        }
    }
    if ($Company) {
        $patterns = @(
            @{ P = 'crowdstrike';  V = 'CrowdStrike';        C = 'EDR' },
            @{ P = 'sentinelone';  V = 'SentinelOne';        C = 'EDR' },
            @{ P = 'mcafee';       V = 'Trellix / McAfee';   C = 'AV' },
            @{ P = 'trellix';      V = 'Trellix';            C = 'AV' },
            @{ P = 'symantec';     V = 'Symantec';           C = 'AV' },
            @{ P = 'broadcom';     V = 'Broadcom/Symantec';  C = 'AV' },
            @{ P = 'trend micro';  V = 'Trend Micro';        C = 'AV' },
            @{ P = 'sophos';       V = 'Sophos';             C = 'AV' },
            @{ P = 'kaspersky';    V = 'Kaspersky';          C = 'AV' },
            @{ P = 'eset';         V = 'ESET';               C = 'AV' },
            @{ P = 'bitdefender';  V = 'Bitdefender';        C = 'AV' },
            @{ P = 'palo alto';    V = 'Palo Alto Networks'; C = 'EDR' },
            @{ P = 'netskope';     V = 'Netskope';           C = 'Ag/SWG' },
            @{ P = 'zscaler';      V = 'Zscaler';            C = 'Ag/SWG' },
            @{ P = 'forcepoint';   V = 'Forcepoint';         C = 'DLP' },
            @{ P = 'tanium';       V = 'Tanium';             C = 'Yonetim' },
            @{ P = 'qualys';       V = 'Qualys';             C = 'Zafiyet' },
            @{ P = 'rapid7';       V = 'Rapid7';             C = 'EDR' },
            @{ P = 'carbon black'; V = 'Carbon Black';       C = 'EDR' },
            @{ P = 'digital guardian'; V = 'Digital Guardian'; C = 'DLP' },
            @{ P = 'ivanti';       V = 'Ivanti';             C = 'Yonetim' },
            @{ P = 'nexthink';     V = 'Nexthink';           C = 'Izleme' }
        )
        $lc = $Company.ToLowerInvariant()
        foreach ($p in $patterns) {
            if ($lc -like "*$($p.P)*") {
                return [pscustomobject]@{ Vendor = $p.V; Category = $p.C; Source = 'imza' }
            }
        }
    }
    return $null
}

#endregion
#region ------------------------------------------------------ Statik envanter

function Get-MiniFilterInventory {
    <#
      Dosya sistemi filtre suruculerini listeler.

      Neden onemli: her dosya acma/okuma/yazma islemi, yuklu her minifilter'in
      icinden gecer. Ust uste binmis AV/DLP/sifreleme filtreleri, tek basina
      olculebilir I/O gecikmesi uretir -- domain ortamlarinda yavasligin en sik
      yapisal nedeni budur.

      Standart kullanici ile: kayit defterinden Altitude + Group okunur,
      Win32_SystemDriver'dan calisma durumu alinir. fltmc'ye gerek yoktur.
      Yonetici ile: fltmc filters ciktisi da eklenir (gercekten YUKLU olanlar).

      Siniflandirma altitude numarasindan CIKARILMAZ; kayit defterindeki
      Group degeri zaten "FSFilter Anti-Virus" gibi acik yazar, o okunur.
    #>
    param($Caps)

    $result = @{ Registry = @(); Fltmc = $null; DriverState = @{} }

    # State alani yerellestirilebildigi icin calisma tespiti dile bagli
    # OLMAYAN Started (boolean) alanindan yapilir; State yalnizca gosterim.
    $drivers = @(Get-Cim -Class Win32_SystemDriver)
    foreach ($d in $drivers) {
        if ($d.Name) {
            $result.DriverState[$d.Name.ToLowerInvariant()] = [pscustomobject]@{
                Started = [bool]$d.Started
                State   = "$($d.State)"
            }
        }
    }

    $base = 'HKLM:\SYSTEM\CurrentControlSet\Services'
    if (Test-Path $base) {
        $keys = Invoke-Safe -Source 'Registry:Services' -Script {
            Get-ChildItem $base -ErrorAction Stop
        }
        foreach ($k in @($keys)) {
            $group = Invoke-Safe -Source 'Registry:Group' -Script {
                (Get-ItemProperty -Path $k.PSPath -Name 'Group' -ErrorAction Stop).Group
            }
            if (-not $group -or $group -notlike 'FSFilter*') { continue }

            $inst = Join-Path $k.PSPath 'Instances'
            $alt  = $null
            if (Test-Path $inst) {
                $def = Invoke-Safe -Source 'Registry:Instances' -Script {
                    (Get-ItemProperty -Path $inst -Name 'DefaultInstance' -ErrorAction Stop).DefaultInstance
                }
                if ($def) {
                    $altPath = Join-Path $inst $def
                    $alt = Invoke-Safe -Source 'Registry:Altitude' -Script {
                        (Get-ItemProperty -Path $altPath -Name 'Altitude' -ErrorAction Stop).Altitude
                    }
                }
            }
            $props = Invoke-Safe -Source 'Registry:FilterProps' -Script {
                Get-ItemProperty -Path $k.PSPath -ErrorAction Stop
            }
            $name = $k.PSChildName
            $ds = $result.DriverState[$name.ToLowerInvariant()]
            $running = $false
            $stateText = 'bilinmiyor'
            if ($ds) { $running = $ds.Started; $stateText = $ds.State }

            $result.Registry += [pscustomobject]@{
                Name        = $name
                DisplayName = if ($props) { $props.DisplayName } else { $null }
                Group       = $group
                Altitude    = $alt
                StartType   = if ($props) { $props.Start } else { $null }
                ImagePath   = if ($props) { $props.ImagePath } else { $null }
                Running     = $running
                State       = $stateText
            }
        }
    } else {
        Add-Gap -Source 'MiniFilter' -Reason 'HKLM Services anahtari okunamadi'
    }

    $result.Registry = @($result.Registry | Sort-Object { [int](ConvertTo-Num $_.Altitude 0) } -Descending)

    if ($Caps.Elevated) {
        $result.Fltmc = Invoke-Safe -Source 'fltmc' -Script {
            $raw = & fltmc.exe filters 2>&1
            if ($LASTEXITCODE -ne 0) { throw "fltmc cikis kodu $LASTEXITCODE" }
            @($raw | Where-Object { $_ -match '\S' })
        }
    } else {
        Add-Gap -Source 'fltmc' -Reason 'Yonetici gerekir; kayit defteri + Win32_SystemDriver ile telafi edildi'
    }

    return $result
}

function Get-ServiceInventory {
    $svc = @(Get-Cim -Class Win32_Service)
    $out = @()
    foreach ($s in $svc) {
        $out += [pscustomobject]@{
            Name        = $s.Name
            DisplayName = $s.DisplayName
            State       = $s.State
            StartMode   = $s.StartMode
            ProcessId   = [int](ConvertTo-Num $s.ProcessId 0)
            PathName    = $s.PathName
        }
    }
    return @($out)
}

function Get-StartupInventory {
    $items = @()

    foreach ($sc in @(Get-Cim -Class Win32_StartupCommand)) {
        $items += [pscustomobject]@{
            Name = $sc.Name; Command = $sc.Command; Location = $sc.Location; User = $sc.User
        }
    }

    $tasks = Invoke-Safe -Source 'Get-ScheduledTask' -Script {
        Get-ScheduledTask -ErrorAction Stop | Where-Object { $_.State -ne 'Disabled' }
    }
    $taskList = @()
    foreach ($t in @($tasks)) {
        $trigger = ''
        foreach ($tr in @($t.Triggers)) {
            $trigger = $tr.CimClass.CimClassName -replace '^MSFT_Task', '' -replace 'Trigger$', ''
            break
        }
        # Sadece surekli/olay tetikli veya acilista calisanlar ilginc.
        if ($trigger -match 'Logon|Boot|Registration|Event|Idle' -or $t.Settings.RunOnlyIfIdle) {
            $taskList += [pscustomobject]@{
                Path = $t.TaskPath; Name = $t.TaskName; Trigger = $trigger; State = "$($t.State)"
            }
        }
    }

    return [pscustomobject]@{ RunEntries = @($items); Tasks = @($taskList) }
}

function Get-PowerProfile {
    <#
      Maksimum islemci durumu (Maximum processor state) okunur.

      ONEMLI: Bu deger powercfg CIKTISINDAN AYRISTIRILMAZ. powercfg /query
      ciktisi hem yerellestirilmistir hem de gercek degerden once
      "Minimum Possible Setting: 0x00000000" gibi satirlar icerir; sirasal
      ayristirma %0 gibi tamamen yanlis sonuc uretir.

      Bunun yerine kayit defteri okunur: dil bagimsiz, sirasal degil, adres
      belli. Deger yoksa ayar varsayilandadir (%100) -- "okunamadi" ile
      "sinirlandirilmis" birbirine karistirilmaz.
    #>
    $schemesRoot = 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\User\PowerSchemes'
    $SUB_PROCESSOR   = '54533251-82be-4824-96c1-47b60b740d00'
    $PROCTHROTTLEMAX = 'bc5038f7-23e0-4960-96da-33abaf5935ec'

    $activeGuid = $null
    if (Test-Path $schemesRoot) {
        $activeGuid = Invoke-Safe -Source 'Registry:ActivePowerScheme' -Script {
            (Get-ItemProperty -Path $schemesRoot -Name 'ActivePowerScheme' -ErrorAction Stop).ActivePowerScheme
        }
    }

    $ac = $null; $dc = $null; $source = $null
    if ($activeGuid) {
        $settingPath = Join-Path (Join-Path (Join-Path $schemesRoot $activeGuid) $SUB_PROCESSOR) $PROCTHROTTLEMAX
        if (Test-Path $settingPath) {
            $vals = Invoke-Safe -Source 'Registry:ProcThrottleMax' -Script {
                Get-ItemProperty -Path $settingPath -ErrorAction Stop
            }
            if ($vals) {
                if ($null -ne $vals.ACSettingIndex) { $ac = [int]$vals.ACSettingIndex }
                if ($null -ne $vals.DCSettingIndex) { $dc = [int]$vals.DCSettingIndex }
                $source = 'kayit defteri (aktif plan)'
            }
        }
    }

    # GPO ile dayatilan guc ayari ayri bir anahtarda tutulur ve aktif plani
    # ezer. Varsa onu gosteririz -- kullanicinin degistiremeyecegi ayar budur.
    $policyPath = "HKLM:\SOFTWARE\Policies\Microsoft\Power\PowerSettings\$PROCTHROTTLEMAX"
    $policyAc = $null; $policyDc = $null
    if (Test-Path $policyPath) {
        $pv = Invoke-Safe -Source 'Registry:PowerPolicy' -Script {
            Get-ItemProperty -Path $policyPath -ErrorAction Stop
        }
        if ($pv) {
            if ($null -ne $pv.ACSettingIndex) { $policyAc = [int]$pv.ACSettingIndex }
            if ($null -ne $pv.DCSettingIndex) { $policyDc = [int]$pv.DCSettingIndex }
        }
    }
    if ($null -ne $policyAc) { $ac = $policyAc; $source = 'Grup Ilkesi (GPO) ile dayatilmis' }
    if ($null -ne $policyDc) { $dc = $policyDc }

    # Akil saglamasi: %0 bir makineyi tamamen durdururdu. Boyle bir deger
    # okunduysa bu bir ayristirma hatasidir, bulgu degildir.
    $sane = $true
    foreach ($v in @($ac, $dc)) {
        if ($null -ne $v -and ($v -lt 5 -or $v -gt 100)) { $sane = $false }
    }
    if (-not $sane) {
        Add-Gap -Source 'ProcThrottleMax' -Reason "Mantiksiz deger okundu (AC=$ac DC=$dc); yok sayildi"
        $ac = $null; $dc = $null; $source = $null
    }

    # Deger hic yoksa ayar varsayilandadir. Bu "sinirlandirilmamis" demektir.
    $defaulted = ($null -eq $ac -and $null -eq $dc -and $null -ne $activeGuid)
    if ($defaulted) { $source = 'kayitta ayar yok -- varsayilan (%100)' }

    $activeName = Invoke-Safe -Source 'powercfg' -Script {
        $raw = & powercfg.exe /getactivescheme 2>&1
        if ($LASTEXITCODE -ne 0) { throw "powercfg cikis kodu $LASTEXITCODE" }
        ($raw -join ' ').Trim()
    }

    $procs = @(Get-Cim -Class Win32_Processor)
    $clock = $null
    if ($procs.Count -gt 0) {
        $clock = [pscustomobject]@{
            CurrentMHz = [int](ConvertTo-Num $procs[0].CurrentClockSpeed 0)
            MaxMHz     = [int](ConvertTo-Num $procs[0].MaxClockSpeed 0)
        }
    }

    return [pscustomobject]@{
        ActiveScheme = $activeName
        ActiveGuid   = $activeGuid
        ThrottleMax  = [pscustomobject]@{
            AcMaxPct  = $ac
            DcMaxPct  = $dc
            Source    = $source
            Defaulted = $defaulted
            ByPolicy  = ($null -ne $policyAc)
        }
        Clock = $clock
    }
}

function Get-StorageInventory {
    $disks = @()
    foreach ($d in @(Get-Cim -Class Win32_LogicalDisk -Filter 'DriveType=3')) {
        $size = ConvertTo-Num $d.Size 0
        $free = ConvertTo-Num $d.FreeSpace 0
        $disks += [pscustomobject]@{
            Drive     = $d.DeviceID
            SizeGB    = [math]::Round($size / 1GB, 1)
            FreeGB    = [math]::Round($free / 1GB, 1)
            FreePct   = if ($size -gt 0) { [math]::Round($free / $size * 100, 1) } else { $null }
            FileSystem= $d.FileSystem
        }
    }

    $phys = Invoke-Safe -Source 'Get-PhysicalDisk' -Script {
        Get-PhysicalDisk -ErrorAction Stop | Select-Object FriendlyName, MediaType, BusType, Size, HealthStatus
    }
    $physList = @()
    foreach ($p in @($phys)) {
        $physList += [pscustomobject]@{
            Name = $p.FriendlyName; MediaType = "$($p.MediaType)"; BusType = "$($p.BusType)"
            SizeGB = [math]::Round((ConvertTo-Num $p.Size 0) / 1GB, 1); Health = "$($p.HealthStatus)"
        }
    }

    $page = @()
    foreach ($pf in @(Get-Cim -Class Win32_PageFileUsage)) {
        $page += [pscustomobject]@{
            Path = $pf.Name; AllocatedMB = [int](ConvertTo-Num $pf.AllocatedBaseSize 0)
            CurrentMB = [int](ConvertTo-Num $pf.CurrentUsage 0); PeakMB = [int](ConvertTo-Num $pf.PeakUsage 0)
        }
    }

    return [pscustomobject]@{ Volumes = @($disks); Physical = @($physList); PageFiles = @($page) }
}

function Get-SecurityPosture {
    $vbs = $null
    $dgPath = 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard'
    if (Test-Path $dgPath) {
        $vbs = Invoke-Safe -Source 'Registry:DeviceGuard' -Script {
            $p = Get-ItemProperty -Path $dgPath -ErrorAction Stop
            $hvci = $null
            $sPath = Join-Path $dgPath 'Scenarios\HypervisorEnforcedCodeIntegrity'
            if (Test-Path $sPath) {
                $hvci = (Get-ItemProperty -Path $sPath -ErrorAction SilentlyContinue).Enabled
            }
            [pscustomobject]@{
                EnableVirtualizationBasedSecurity = $p.EnableVirtualizationBasedSecurity
                RequirePlatformSecurityFeatures   = $p.RequirePlatformSecurityFeatures
                HvciEnabled                       = $hvci
            }
        }
    }

    $defender = Invoke-Safe -Source 'Get-MpComputerStatus' -Script {
        $s = Get-MpComputerStatus -ErrorAction Stop
        [pscustomobject]@{
            RealTimeProtection = $s.RealTimeProtectionEnabled
            AntivirusEnabled   = $s.AntivirusEnabled
            AMRunningMode      = "$($s.AMRunningMode)"
            QuickScanAge       = $s.QuickScanAge
        }
    }

    $avProducts = Invoke-Safe -Source 'SecurityCenter2' -Script {
        Get-CimInstance -Namespace 'root\SecurityCenter2' -ClassName AntiVirusProduct -ErrorAction Stop |
            Select-Object displayName, pathToSignedProductExe
    }

    return [pscustomobject]@{
        DeviceGuard = $vbs
        Defender    = $defender
        AvProducts  = @($avProducts | ForEach-Object { [pscustomobject]@{ Name = $_.displayName; Path = $_.pathToSignedProductExe } })
    }
}

function Get-BootAndGpoEvents {
    <#
      Microsoft-Windows-Diagnostics-Performance/Operational kanali, acilisi
      yavaslatan uygulamayi ADIYLA ve milisaniye cinsinden sureyle verir.
      Bu kanal genellikle yonetici hakki ister.

      GroupPolicy/Operational kanali, her GPO istemci eklentisinin (CSE)
      isleme suresini verir -- domain ortaminda oturum acma yavasliginin
      dogrudan kanitidir.
    #>
    param($Caps)

    $boot = @()
    if ($Caps.Probe['EventBoot']) {
        $evts = Invoke-Safe -Source 'EventLog:BootPerf' -Script {
            Get-WinEvent -FilterHashtable @{
                LogName = 'Microsoft-Windows-Diagnostics-Performance/Operational'
                Id      = 100, 101, 102, 103, 109, 110
            } -MaxEvents 80 -ErrorAction Stop
        }
        foreach ($e in @($evts)) {
            $boot += [pscustomobject]@{
                Time = $e.TimeCreated; Id = $e.Id
                Message = ($e.Message -replace '\s+', ' ').Trim()
            }
        }
    } else {
        Add-Gap -Source 'BootPerf' -Reason 'Diagnostics-Performance kanali okunamadi (genellikle yonetici gerekir)'
    }

    $gpo = @()
    if ($Caps.Probe['EventGpo']) {
        $evts = Invoke-Safe -Source 'EventLog:GroupPolicy' -Script {
            Get-WinEvent -FilterHashtable @{
                LogName = 'Microsoft-Windows-GroupPolicy/Operational'
                Id      = 8000, 8001, 8005, 8006, 5016, 6016, 7016
            } -MaxEvents 120 -ErrorAction Stop
        }
        foreach ($e in @($evts)) {
            $gpo += [pscustomobject]@{
                Time = $e.TimeCreated; Id = $e.Id
                Message = ($e.Message -replace '\s+', ' ').Trim()
            }
        }
    } else {
        Add-Gap -Source 'GroupPolicy' -Reason 'GroupPolicy/Operational kanali okunamadi'
    }

    $sys = @()
    if ($Caps.Probe['EventSystem']) {
        $evts = Invoke-Safe -Source 'EventLog:System' -Script {
            Get-WinEvent -FilterHashtable @{
                LogName   = 'System'
                Id        = 2004, 2019, 2020, 41, 1001, 6008, 129, 153, 157
                StartTime = (Get-Date).AddDays(-7)
            } -MaxEvents 100 -ErrorAction Stop
        }
        foreach ($e in @($evts)) {
            $sys += [pscustomobject]@{
                Time = $e.TimeCreated; Id = $e.Id; Provider = $e.ProviderName
                Message = ($e.Message -replace '\s+', ' ').Trim()
            }
        }
    }

    return [pscustomobject]@{ Boot = @($boot); Gpo = @($gpo); System = @($sys) }
}

function Get-StaticInventory {
    param($Caps)
    Write-Info '  - dosya sistemi filtreleri...'
    $mf = Get-MiniFilterInventory -Caps $Caps
    Write-Info '  - servisler ve baslangic ogeleri...'
    $svc = Get-ServiceInventory
    $startup = Get-StartupInventory
    Write-Info '  - guc plani, depolama, guvenlik durumu...'
    $power = Get-PowerProfile
    $storage = Get-StorageInventory
    $posture = Get-SecurityPosture
    $events = $null
    if (-not $NoEventLog) {
        Write-Info '  - olay gunlukleri (acilis / GPO / sistem)...'
        $events = Get-BootAndGpoEvents -Caps $Caps
    }

    [pscustomobject]@{
        MiniFilters = $mf
        Services    = $svc
        Startup     = $startup
        Power       = $power
        Storage     = $storage
        Posture     = $posture
        Events      = $events
    }
}

#endregion
#region --------------------------------------------------------- Ornekleme

$script:ProcFields = @(
    'IDProcess', 'Name', 'PercentProcessorTime', 'PercentPrivilegedTime',
    'WorkingSetPrivate', 'PrivateBytes', 'HandleCount', 'ThreadCount',
    'IOReadOperationsPersec', 'IOWriteOperationsPersec',
    'IOReadBytesPersec', 'IOWriteBytesPersec', 'PageFaultsPersec',
    'CreatingProcessID', 'Timestamp_Sys100NS'
)

function Get-RawSnapshot {
    <# Tek bir zaman noktasinda tum ham sayaclari topla. #>
    $ts = Get-Date

    $proc = Invoke-Safe -Source 'Perf:Process' -Script {
        Get-CimInstance -ClassName Win32_PerfRawData_PerfProc_Process `
            -Property $script:ProcFields -ErrorAction Stop
    }
    $disk = Invoke-Safe -Source 'Perf:LogicalDisk' -Script {
        Get-CimInstance -ClassName Win32_PerfRawData_PerfDisk_LogicalDisk `
            -Filter "Name='_Total'" -ErrorAction Stop
    }
    $mem = Invoke-Safe -Source 'Perf:Memory' -Script {
        Get-CimInstance -ClassName Win32_PerfRawData_PerfOS_Memory -ErrorAction Stop
    }
    $sys = Invoke-Safe -Source 'Perf:System' -Script {
        Get-CimInstance -ClassName Win32_PerfRawData_PerfOS_System -ErrorAction Stop
    }
    $cpu = Invoke-Safe -Source 'Perf:Processor' -Script {
        Get-CimInstance -ClassName Win32_PerfRawData_PerfOS_Processor `
            -Filter "Name='_Total'" -ErrorAction Stop
    }
    # Islemcinin GERCEKTEN hangi hizda calistigi. Win32_Processor.CurrentClockSpeed
    # guvenilmezdir (cogu sistemde nominal degeri tekrarlar veya bosta olcum verir).
    # PercentProcessorPerformance nominal hiza gore yuzdedir: 100 = nominal,
    # >100 = turbo, <100 = gercekten yavaslatilmis.
    $perf = Invoke-Safe -Source 'Perf:ProcessorInformation' -Script {
        Get-CimInstance -ClassName Win32_PerfFormattedData_Counters_ProcessorInformation `
            -Filter "Name='_Total'" -ErrorAction Stop
    }

    [pscustomobject]@{
        Ts = $ts; Proc = @($proc); Disk = $disk; Mem = $mem; Sys = $sys; Cpu = $cpu; Perf = $perf
    }
}

function ConvertTo-Sample {
    <#
      Iki ham anlik goruntuden turetilmis metrikleri hesapla.

      _Total ornegindeki islemci sayaclari tum cekirdeklerin TOPLAMIDIR, bu
      yuzden mantiksal cekirdek sayisina bolunur. Ayni sey process basina
      PercentProcessorTime icin de gecerli: bolmezsek 8 cekirdekli makinede
      %800 gorunur. Gorev Yoneticisi semantigi icin bolunur.
    #>
    param($Cur, $Prev, [int]$Ncpu)

    if (-not $Prev) { return $null }
    $dt = ($Cur.Ts - $Prev.Ts).TotalSeconds
    if ($dt -le 0) { return $null }
    if ($Ncpu -le 0) { $Ncpu = 1 }

    $m = [ordered]@{ Ts = $Cur.Ts; DeltaSec = [math]::Round($dt, 3) }

    # --- islemci ---
    if ($Cur.Cpu -and $Prev.Cpu) {
        $t1 = $Cur.Cpu.Timestamp_Sys100NS; $t0 = $Prev.Cpu.Timestamp_Sys100NS
        $idle = (Get-Pct100Ns $Cur.Cpu.PercentIdleTime      $Prev.Cpu.PercentIdleTime      $t1 $t0) / $Ncpu
        $dpc  = (Get-Pct100Ns $Cur.Cpu.PercentDPCTime       $Prev.Cpu.PercentDPCTime       $t1 $t0) / $Ncpu
        $intr = (Get-Pct100Ns $Cur.Cpu.PercentInterruptTime $Prev.Cpu.PercentInterruptTime $t1 $t0) / $Ncpu
        $priv = (Get-Pct100Ns $Cur.Cpu.PercentPrivilegedTime $Prev.Cpu.PercentPrivilegedTime $t1 $t0) / $Ncpu
        $total = 100 - $idle
        if ($total -lt 0) { $total = 0 }; if ($total -gt 100) { $total = 100 }
        $m['CpuTotalPct']      = Round2 $total
        $m['CpuPrivilegedPct'] = Round2 $priv
        $m['CpuDpcPct']        = Round2 $dpc
        $m['CpuInterruptPct']  = Round2 $intr
    }

    # --- islemcinin GERCEK hizi ---
    # Guc plani ayarini okumak yeterli degil; asil soru "CPU mesgulken tam
    # hiza cikabiliyor mu". PercentProcessorPerformance nominal hiza gore
    # yuzdedir: 100 = nominal, >100 = turbo, <100 = gercekten yavaslatilmis.
    # Bazi surumlerde bu sayac yerine PercentofMaximumFrequency bulunur.
    if ($Cur.Perf) {
        $pp = $null
        if ($null -ne $Cur.Perf.PercentProcessorPerformance) {
            $pp = ConvertTo-Num $Cur.Perf.PercentProcessorPerformance -1
        } elseif ($null -ne $Cur.Perf.PercentofMaximumFrequency) {
            $pp = ConvertTo-Num $Cur.Perf.PercentofMaximumFrequency -1
        }
        if ($null -ne $pp -and $pp -ge 0) { $m['CpuPerfPct'] = Round2 $pp }
        $pf = ConvertTo-Num $Cur.Perf.ProcessorFrequency -1
        if ($pf -gt 0) { $m['CpuFreqMHz'] = [int]$pf }
    }

    # --- sistem ---
    if ($Cur.Sys -and $Prev.Sys) {
        $m['ProcessorQueueLength'] = [int](ConvertTo-Num $Cur.Sys.ProcessorQueueLength 0)
        $m['ContextSwitchesPerSec'] = [int](Get-Rate $Cur.Sys.ContextSwitchesPersec $Prev.Sys.ContextSwitchesPersec $dt)
        $m['SystemCallsPerSec']     = [int](Get-Rate $Cur.Sys.SystemCallsPersec     $Prev.Sys.SystemCallsPersec     $dt)
    }

    # --- bellek ---
    if ($Cur.Mem -and $Prev.Mem) {
        $m['AvailableMB']      = [int](ConvertTo-Num $Cur.Mem.AvailableMBytes 0)
        $m['HardFaultsPerSec'] = [int](Get-Rate $Cur.Mem.PagesInputPersec $Prev.Mem.PagesInputPersec $dt)
        $m['PageFaultsPerSec'] = [int](Get-Rate $Cur.Mem.PageFaultsPersec $Prev.Mem.PageFaultsPersec $dt)
        $committed = ConvertTo-Num $Cur.Mem.CommittedBytes 0
        $limit     = ConvertTo-Num $Cur.Mem.CommitLimit 0
        $m['CommitPct']      = if ($limit -gt 0) { Round2 ($committed / $limit * 100) } else { $null }
        $m['PoolNonpagedMB'] = [int]((ConvertTo-Num $Cur.Mem.PoolNonpagedBytes 0) / 1MB)
        $m['PoolPagedMB']    = [int]((ConvertTo-Num $Cur.Mem.PoolPagedBytes 0) / 1MB)
    }

    # --- disk ---
    if ($Cur.Disk -and $Prev.Disk) {
        $freq = $Cur.Disk.Frequency_PerfTime
        $m['DiskReadMs'] = Round2 (Get-AvgTimerMs $Cur.Disk.AvgDisksecPerRead  $Prev.Disk.AvgDisksecPerRead `
                                                  $Cur.Disk.AvgDisksecPerRead_Base  $Prev.Disk.AvgDisksecPerRead_Base  $freq)
        $m['DiskWriteMs'] = Round2 (Get-AvgTimerMs $Cur.Disk.AvgDisksecPerWrite $Prev.Disk.AvgDisksecPerWrite `
                                                   $Cur.Disk.AvgDisksecPerWrite_Base $Prev.Disk.AvgDisksecPerWrite_Base $freq)
        $m['DiskQueueLength'] = [int](ConvertTo-Num $Cur.Disk.CurrentDiskQueueLength 0)
        $m['DiskReadsPerSec'] = [int](Get-Rate $Cur.Disk.DiskReadsPersec  $Prev.Disk.DiskReadsPersec  $dt)
        $m['DiskWritesPerSec']= [int](Get-Rate $Cur.Disk.DiskWritesPersec $Prev.Disk.DiskWritesPersec $dt)
    }

    # --- process basina ---
    $prevByPid = @{}
    foreach ($p in $Prev.Proc) {
        $pid_ = [int](ConvertTo-Num $p.IDProcess -1)
        if ($pid_ -ge 0) { $prevByPid[$pid_] = $p }
    }

    $procs = @()
    foreach ($c in $Cur.Proc) {
        $name = "$($c.Name)"
        if ($name -eq '_Total' -or $name -eq 'Idle') { continue }
        $pid_ = [int](ConvertTo-Num $c.IDProcess -1)
        if ($pid_ -le 0) { continue }
        $p = $prevByPid[$pid_]
        if (-not $p) { continue }   # yeni dogmus process: delta yok, atla

        $cpuPct = (Get-Pct100Ns $c.PercentProcessorTime $p.PercentProcessorTime `
                                $c.Timestamp_Sys100NS   $p.Timestamp_Sys100NS) / $Ncpu

        $procs += [pscustomobject]@{
            Pid             = $pid_
            Name            = ($name -replace '#\d+$', '')
            Instance        = $name
            CpuPct          = Round2 $cpuPct
            PrivateMB       = [int]((ConvertTo-Num $c.PrivateBytes 0) / 1MB)
            WorkingSetMB    = [int]((ConvertTo-Num $c.WorkingSetPrivate 0) / 1MB)
            Handles         = [int](ConvertTo-Num $c.HandleCount 0)
            Threads         = [int](ConvertTo-Num $c.ThreadCount 0)
            IoReadOpsPerSec = [int](Get-Rate $c.IOReadOperationsPersec  $p.IOReadOperationsPersec  $dt)
            IoWriteOpsPerSec= [int](Get-Rate $c.IOWriteOperationsPersec $p.IOWriteOperationsPersec $dt)
            IoReadKBPerSec  = [int]((Get-Rate $c.IOReadBytesPersec  $p.IOReadBytesPersec  $dt) / 1KB)
            IoWriteKBPerSec = [int]((Get-Rate $c.IOWriteBytesPersec $p.IOWriteBytesPersec $dt) / 1KB)
            HardFaultsPerSec= [int](Get-Rate $c.PageFaultsPersec $p.PageFaultsPersec $dt)
        }
    }

    [pscustomobject]@{ Metrics = [pscustomobject]$m; Processes = @($procs) }
}

function Get-ProcessEnrichment {
    <#
      Process -> yol, yayinci, servis, guvenlik ajani etiketi.
      Ornekleme dongusunun DISINDA, bir kez calisir.

      Korumali process'lerin (MsMpEng, CSFalconService gibi PPL olanlar) yolu
      standart kullaniciya kapalidir; o durumda servis kaydindaki ImagePath'e
      dusulur.
    #>
    param($Services)

    $svcByPid  = @{}
    $svcByExe  = @{}
    foreach ($s in @($Services)) {
        if ($s.ProcessId -gt 0) {
            if (-not $svcByPid.ContainsKey($s.ProcessId)) { $svcByPid[$s.ProcessId] = @() }
            $svcByPid[$s.ProcessId] += $s.Name
        }
        if ($s.PathName -and $s.PathName -match '([^\\/"]+\.exe)') {
            $exe = $Matches[1].ToLowerInvariant()
            if (-not $svcByExe.ContainsKey($exe)) { $svcByExe[$exe] = $s }
        }
    }

    $live = Invoke-Safe -Source 'Get-Process' -Script { Get-Process -ErrorAction Stop }
    $map = @{}
    foreach ($p in @($live)) {
        $path = $null; $company = $null; $desc = $null
        try { $path = $p.Path } catch { $path = $null }
        try { $company = $p.Company } catch { $company = $null }
        try { $desc = $p.Description } catch { $desc = $null }

        if (-not $path) {
            $exe = ($p.ProcessName + '.exe').ToLowerInvariant()
            if ($svcByExe.ContainsKey($exe)) { $path = $svcByExe[$exe].PathName }
        }

        $agent = Resolve-Agent -Name $p.ProcessName -Company $company
        $svcNames = @()
        if ($svcByPid.ContainsKey($p.Id)) { $svcNames = $svcByPid[$p.Id] }

        $map[[int]$p.Id] = [pscustomobject]@{
            Path        = $path
            Company     = $company
            Description = $desc
            Services    = @($svcNames)
            Vendor      = if ($agent) { $agent.Vendor } else { $null }
            Category    = if ($agent) { $agent.Category } else { $null }
            AgentSource = if ($agent) { $agent.Source } else { $null }
        }
    }
    return $map
}

function Invoke-SamplingLoop {
    <# Diag ve Monitor modlarinin ortak ornekleme dongusu. #>
    param(
        [int]$Count, [double]$IntervalSec, [int]$Ncpu,
        [scriptblock]$OnSample, [int]$DurationSec = 0
    )

    $samples = @()
    $prev = Get-RawSnapshot
    $i = 0
    $start = Get-Date

    while ($true) {
        Start-Sleep -Milliseconds ([int]($IntervalSec * 1000))
        $cur = Get-RawSnapshot
        $s = ConvertTo-Sample -Cur $cur -Prev $prev -Ncpu $Ncpu
        $prev = $cur
        if ($s) {
            $samples += $s
            $i++
            if ($OnSample) { & $OnSample $s $i }
        }
        if ($Count -gt 0 -and $i -ge $Count) { break }
        if ($DurationSec -gt 0 -and ((Get-Date) - $start).TotalSeconds -ge $DurationSec) { break }
    }
    return @($samples)
}

#endregion
#region ------------------------------------------------------------- Analiz

$script:SlowThreshold = 0.40

# Bilesenlerin kullaniciya gosterilen adlari. "bellek basinci" gibi
# ceviri kokenli, Turkcede karsiligi olmayan terimler kullanilmaz.
$script:ComponentLabels = [ordered]@{
    Memory        = 'RAM yetersizliği'
    DiskLatency   = 'Disk yavaş yanıt veriyor'
    CpuSaturation = 'İşlemci dolu'
    CpuQueue      = 'İşlemci sırası uzun'
    DpcInterrupt  = 'Sürücü yükü'
    DiskQueue     = 'Disk sırası uzun'
}

# Her bilesenin ne anlama geldigi -- raporda aciklama olarak basilir.
$script:ComponentMeaning = [ordered]@{
    Memory        = 'Fiziksel RAM yetmiyor. Windows açık programların verisini diske taşımaya (takas) başlar; disk RAM''den binlerce kat yavaş olduğu için her şey durur.'
    DiskLatency   = 'Diske gönderilen okuma/yazma isteği geç cevaplanıyor. Ya disk donanımı yavaş/dolu, ya da her dosya işlemini inceleyen bir sürücü yığını araya giriyor.'
    CpuSaturation = 'İşlemci neredeyse tamamen dolu. Yeni işler boşta çekirdek bulamıyor.'
    CpuQueue      = 'Çalışmaya hazır ama sıra bekleyen iş sayısı çekirdek sayısını aşmış. Kullanıcı bunu "tıkladım, tepki vermedi" olarak hisseder.'
    DpcInterrupt  = 'İşlemci zamanının önemli bir kısmı sürücü kodunda geçiyor. Bu yük hiçbir programda görünmez; kaynağı çekirdek modunda çalışan sürücülerdir.'
    DiskQueue     = 'Disk, gelen istekleri yetiştiremiyor ve istekler kuyruğa yığılıyor.'
}

$script:ScoreWeights = @{
    CpuSaturation = 0.18
    CpuQueue      = 0.15
    DpcInterrupt  = 0.12
    Memory        = 0.25
    DiskLatency   = 0.22
    DiskQueue     = 0.08
}

# Kisa etiket: tablolarda ve tek satirlik aciklamalarda kullanilir.
# "bellek baskisi / memory pressure" gibi Turkcede karsiligi olmayan
# terimler bilerek kullanilmaz.
$script:ComponentLabel = @{
    CpuSaturation = 'CPU doluluğu'
    CpuQueue      = 'CPU sırası'
    DpcInterrupt  = 'sürücü yükü'
    Memory        = 'RAM yetersizliği'
    DiskLatency   = 'disk yanıt süresi'
    DiskQueue     = 'disk sırası'
}

# Uzun aciklama: "bu neden yavaslatir" sorusunun cevabi.
$script:ComponentWhy = @{
    CpuSaturation = 'İşlemci neredeyse tamamen dolu. Yeni gelen her iş, çalışan işlerin bitmesini beklemek zorunda kalıyor.'
    CpuQueue      = 'Çekirdek başına birden fazla iş sıraya girmiş. İşlemci boş değil, ama asıl sorun işlerin sırada beklemesi: tıkladığınız şey hemen başlamıyor.'
    DpcInterrupt  = 'Bu yük hiçbir programda görünmez, sürücülerden gelir. Windows çekirdeğinin içinde harcanır. En sık kaynağı üst üste binmiş dosya sistemi filtreleridir (antivirüs, DLP, şifreleme) ve ağ sürücüleridir.'
    Memory        = 'Boş RAM tükenmiş. Bu durumda Windows, çalışan programların belleğini diske yazıp yer açar; o programa dönüldüğünde belleği diskten geri okur. Disk, RAM''den binlerce kat yavaş olduğu için her geçiş bekleme süresine dönüşür. Kullanıcı bunu "pencereler arası geçişte donma" olarak hisseder.'
    DiskLatency   = 'Disk, okuma/yazma isteklerine geç yanıt veriyor. Program bir dosyayı açmak istediğinde cevap gelene kadar donar. Diskin kendisi yavaş olabilir; ya da her dosya isteği, kendisini inceleyen filtre sürücülerinin arasından geçtiği için gecikiyordur.'
    DiskQueue     = 'Diske aynı anda çok sayıda istek yığılmış ve kuyruk oluşmuş. İstekler sırayla işlendiği için sondaki uzun süre bekler.'
}


function Format-Delta {
    <#
      Isaretli farki insan dilinde yazar. Ciplak "-27" kimseye bir sey
      anlatmiyor; "yavaşlık anında azaldı" anlatir.
    #>
    param($Value, [string]$Unit = '', [double]$Epsilon = 0.5)
    if ($null -eq $Value) { return 'karşılaştırılamadı (normal dönem yok)' }
    $v = [double]$Value
    if ([math]::Abs($v) -lt $Epsilon) { return "değişmedi" }
    if ($v -gt 0) { return ("+{0}{1} — yavaşlık anında ARTTI" -f (Round2 $v), $Unit) }
    return ("{0}{1} — yavaşlık anında AZALDI" -f (Round2 $v), $Unit)
}

function Get-Component {
    param([double]$Value, [double]$Floor, [double]$Span, [string]$Evidence)
    if ($null -eq $Value -or $Value -le $Floor) {
        return [pscustomobject]@{ Score = 0.0; Evidence = $null }
    }
    $s = ($Value - $Floor) / $Span
    if ($s -gt 1) { $s = 1.0 }
    [pscustomobject]@{ Score = [math]::Round($s, 3); Evidence = $Evidence }
}

function Get-SampleScore {
    param($Sample, [int]$Ncpu, [double]$TotalMemMB)
    $m = $Sample.Metrics
    $c = [ordered]@{}

    $cpu = ConvertTo-Num $m.CpuTotalPct 0
    $c['CpuSaturation'] = Get-Component -Value $cpu -Floor 80 -Span 20 `
        -Evidence ("işlemci %{0} dolu" -f (Round2 $cpu))

    $q = ConvertTo-Num $m.ProcessorQueueLength 0
    $qr = if ($Ncpu -gt 0) { $q / $Ncpu } else { $q }
    $c['CpuQueue'] = Get-Component -Value $qr -Floor 1 -Span 3 `
        -Evidence ("{0} iş işlemci sırasında bekliyor ({1} çekirdek için {2} kat fazla)" -f [int]$q, $Ncpu, (Round2 $qr))

    # DPC + kesme suresi: surucu kaynakli yuk. Dosya sistemi filtresi, ag
    # filtresi veya bozuk surucu burada gorunur; kullanici process'lerinde
    # gorunmez. Bu yuzden ayri bir bilesen.
    $dpc = (ConvertTo-Num $m.CpuDpcPct 0) + (ConvertTo-Num $m.CpuInterruptPct 0)
    $c['DpcInterrupt'] = Get-Component -Value $dpc -Floor 5 -Span 15 `
        -Evidence ("sürücüler işlemcinin %{0}'ini kullanıyor (sağlıklı makinede %1-2 beklenir)" -f (Round2 $dpc))

    $memScore = 0.0; $memEv = @()
    $avail = ConvertTo-Num $m.AvailableMB 0
    if ($TotalMemMB -gt 0) {
        $availPct = $avail / $TotalMemMB * 100
        if ($availPct -lt 12) {
            $s = (12 - $availPct) / 12; if ($s -gt 1) { $s = 1 }
            if ($s -gt $memScore) { $memScore = $s }
            $memEv += ("boş RAM yalnızca {1} MB kaldı (toplamın %{0}'i)" -f (Round2 $availPct), [int]$avail)
        }
    }
    $commit = ConvertTo-Num $m.CommitPct 0
    if ($commit -gt 85) {
        $s = ($commit - 85) / 15; if ($s -gt 1) { $s = 1 }
        if ($s -gt $memScore) { $memScore = $s }
        $memEv += ("Windows'un ayırdığı bellek sınırının %{0}'i dolu" -f (Round2 $commit))
    }
    $hard = ConvertTo-Num $m.HardFaultsPerSec 0
    if ($hard -gt 50) {
        $s = ($hard - 50) / 450; if ($s -gt 1) { $s = 1 }
        if ($s -gt $memScore) { $memScore = $s }
        $memEv += ("saniyede {0} kez RAM'de bulunamayan veri diskten okunuyor (takas)" -f [int]$hard)
    }
    $c['Memory'] = [pscustomobject]@{
        Score = [math]::Round($memScore, 3)
        Evidence = if ($memEv.Count) { $memEv -join '; ' } else { $null }
    }

    $dr = ConvertTo-Num $m.DiskReadMs 0
    $dw = ConvertTo-Num $m.DiskWriteMs 0
    $dmax = [math]::Max($dr, $dw)
    $c['DiskLatency'] = Get-Component -Value $dmax -Floor 15 -Span 60 `
        -Evidence ("disk yanıt süresi: okuma {0} ms, yazma {1} ms (SSD'de 2-5 ms beklenir)" -f (Round2 $dr), (Round2 $dw))

    $dq = ConvertTo-Num $m.DiskQueueLength 0
    $c['DiskQueue'] = Get-Component -Value $dq -Floor 2 -Span 8 `
        -Evidence ("diskte {0} işlem sıraya girmiş, tamamlanmayı bekliyor" -f [int]$dq)

    $total = 0.0
    foreach ($k in $script:ScoreWeights.Keys) { $total += $script:ScoreWeights[$k] * $c[$k].Score }

    [pscustomobject]@{
        Ts = $m.Ts
        Score = [math]::Round($total, 3)
        Components = [pscustomobject]$c
    }
}

function Get-SlowWindows {
    param($Scores, [double]$Threshold = $script:SlowThreshold)
    $windows = @(); $cur = $null
    foreach ($s in @($Scores)) {
        if ($s.Score -ge $Threshold) {
            if (-not $cur) { $cur = [ordered]@{ Start = $s.Ts; End = $s.Ts; Items = @($s) } }
            else { $cur.End = $s.Ts; $cur.Items += $s }
        } elseif ($cur) {
            $windows += [pscustomobject]$cur; $cur = $null
        }
    }
    if ($cur) { $windows += [pscustomobject]$cur }
    foreach ($w in $windows) {
        $w | Add-Member -NotePropertyName Peak       -NotePropertyValue (@($w.Items | ForEach-Object { $_.Score }) | Measure-Object -Maximum).Maximum
        $w | Add-Member -NotePropertyName SampleCount -NotePropertyValue @($w.Items).Count
        $w | Add-Member -NotePropertyName DurationSec -NotePropertyValue ([math]::Round(($w.End - $w.Start).TotalSeconds, 1))
    }
    return @($windows)
}

function Get-SlowReason {
    <#
      Bir ornegin NEDEN yavas sayildigini duz Turkce cumleye cevirir.
      Rapordaki "YAVAS" etiketinin yaninda bu metin cikar; kullanici
      skorun neyi temsil ettigini bilmek zorunda kalmaz.
    #>
    param($ScoreItem)
    if (-not $ScoreItem -or $ScoreItem.Score -lt $script:SlowThreshold) { return '' }

    $parts = @()
    foreach ($k in $script:ScoreWeights.Keys) {
        $comp = $ScoreItem.Components.$k
        if (-not $comp -or $comp.Score -lt 0.15) { continue }
        $parts += [pscustomobject]@{
            Key    = $k
            Weight = $script:ScoreWeights[$k] * $comp.Score
            Text   = $comp.Evidence
        }
    }
    $top = @($parts | Where-Object { $_.Text } | Sort-Object Weight -Descending | Select-Object -First 3)
    if ($top.Count -eq 0) { return 'Birden fazla küçük etkinin toplamı' }
    # Her parca "ETIKET — kanit" biciminde yazilir: okuyan once NE oldugunu
    # gorur, sonra dayanagi. Etiketler $script:ComponentLabel'dan gelir.
    $out = @()
    foreach ($t in $top) {
        $out += ("{0} — {1}" -f $script:ComponentLabel[$t.Key], $t.Text)
    }
    return ($out -join '  |  ')
}

function Get-Attribution {
    <#
      Yavas pencerelerdeki process davranisini normal pencerelerle karsilastirir.

      GRUPLAMA YOK: her satir TEK BIR PROCESS'tir (PID bazinda). Ayni programin
      birden fazla kopyasi (svchost, chrome, MsMpEng alt surecleri) tek satirda
      toplanmaz -- aksi halde "urun grubunun" performansi gorunur, sucluyu
      bulmak imkansizlasir. Hangi kopyanin sorun cikardigini gormek gerekir.

      Siralama mantigi: "en cok tuketen" ile "yavasligin nedeni" ayni sey
      degildir. Surekli %4 CPU yiyen bir ajan, yavaslik anlarinda da %4'tedir --
      nedensel bagi yoktur. Yalnizca yavaslik aninda YUKSELEN process aday olur.
    #>
    param($SampleList, $Scores, $Enrichment, [double]$Threshold = $script:SlowThreshold, [int]$TopN = 15)

    $slowTs = @{}; $normTs = @{}
    foreach ($s in @($Scores)) {
        $key = $s.Ts.Ticks
        if ($s.Score -ge $Threshold) { $slowTs[$key] = $true } else { $normTs[$key] = $true }
    }

    $agg = @{}
    foreach ($smp in @($SampleList)) {
        $key = $smp.Metrics.Ts.Ticks
        $isSlow = $slowTs.ContainsKey($key)
        $isNorm = $normTs.ContainsKey($key)
        if (-not ($isSlow -or $isNorm)) { continue }
        foreach ($p in @($smp.Processes)) {
            # Anahtar PID: gruplama yok.
            $k = "$($p.Pid)"
            if (-not $agg.ContainsKey($k)) {
                $agg[$k] = [ordered]@{
                    Pid = $p.Pid; Name = $p.Name; Instance = $p.Instance
                    SlowCpu = @(); NormCpu = @(); SlowMem = @(); NormMem = @()
                    SlowIo = @(); NormIo = @(); SlowIoKB = @()
                    SlowHandles = @(); SlowThreads = @(); SlowFaults = @()
                }
            }
            $a = $agg[$k]
            $io = (ConvertTo-Num $p.IoReadOpsPerSec 0) + (ConvertTo-Num $p.IoWriteOpsPerSec 0)
            $kb = (ConvertTo-Num $p.IoReadKBPerSec 0) + (ConvertTo-Num $p.IoWriteKBPerSec 0)
            if ($isSlow) {
                $a.SlowCpu     += (ConvertTo-Num $p.CpuPct 0)
                $a.SlowMem     += (ConvertTo-Num $p.PrivateMB 0)
                $a.SlowIo      += $io
                $a.SlowIoKB    += $kb
                $a.SlowHandles += (ConvertTo-Num $p.Handles 0)
                $a.SlowThreads += (ConvertTo-Num $p.Threads 0)
                $a.SlowFaults  += (ConvertTo-Num $p.HardFaultsPerSec 0)
            } else {
                $a.NormCpu += (ConvertTo-Num $p.CpuPct 0)
                $a.NormMem += (ConvertTo-Num $p.PrivateMB 0)
                $a.NormIo  += $io
            }
        }
    }

    $slowCount = $slowTs.Count
    $rows = @()
    foreach ($k in $agg.Keys) {
        $a = $agg[$k]
        $hasSlow = (@($a.SlowCpu).Count -gt 0)
        $srcCpu = if ($hasSlow) { $a.SlowCpu } else { $a.NormCpu }
        if (@($srcCpu).Count -eq 0) { continue }

        $slowCpu = (@($srcCpu) | Measure-Object -Average).Average
        $normCpu = $null
        if (@($a.NormCpu).Count -gt 0) { $normCpu = (@($a.NormCpu) | Measure-Object -Average).Average }
        $srcIo = if ($hasSlow) { $a.SlowIo } else { $a.NormIo }
        $slowIo = (@($srcIo) | Measure-Object -Average).Average
        $normIo = $null
        if (@($a.NormIo).Count -gt 0) { $normIo = (@($a.NormIo) | Measure-Object -Average).Average }
        $srcMem = if (@($a.SlowMem).Count -gt 0) { $a.SlowMem } else { $a.NormMem }
        $mem = 0
        if (@($srcMem).Count -gt 0) { $mem = (@($srcMem) | Measure-Object -Average).Average }

        $presence = 0
        if ($slowCount -gt 0) { $presence = @($a.SlowCpu).Count / $slowCount }

        $delta = $null
        if ($hasSlow -and $null -ne $normCpu) { $delta = $slowCpu - $normCpu }
        $ioDelta = $null
        if ($hasSlow -and $null -ne $normIo) { $ioDelta = $slowIo - $normIo }

        $boost = 1.0
        if ($null -ne $delta -and $delta -gt 0) {
            $bb = $delta; if ($bb -gt 50) { $bb = 50 }
            $boost = 1.0 + ($bb / 25)
        }

        $e = $null
        if ($Enrichment.ContainsKey([int]$a.Pid)) { $e = $Enrichment[[int]$a.Pid] }

        $rows += [pscustomobject]@{
            Pid           = [int]$a.Pid
            Name          = $a.Name
            Instance      = $a.Instance
            SlowCpuPct    = Round2 $slowCpu
            NormCpuPct    = Round2 $normCpu
            CpuDelta      = Round2 $delta
            CpuDeltaText  = (Format-Delta -Value $delta -Unit ' puan CPU' -Epsilon 0.5)
            PrivateMB     = [int]$mem
            SlowIoOps     = [int]$slowIo
            NormIoOps     = if ($null -ne $normIo) { [int]$normIo } else { $null }
            IoDelta       = if ($null -ne $ioDelta) { [int]$ioDelta } else { $null }
            IoDeltaText   = (Format-Delta -Value $ioDelta -Unit ' işlem/sn' -Epsilon 5)
            IoKBPerSec    = if (@($a.SlowIoKB).Count -gt 0) { [int]((@($a.SlowIoKB) | Measure-Object -Average).Average) } else { 0 }
            Handles       = if (@($a.SlowHandles).Count -gt 0) { [int]((@($a.SlowHandles) | Measure-Object -Average).Average) } else { 0 }
            Threads       = if (@($a.SlowThreads).Count -gt 0) { [int]((@($a.SlowThreads) | Measure-Object -Average).Average) } else { 0 }
            SamplesSlow   = @($a.SlowCpu).Count
            SamplesNormal = @($a.NormCpu).Count
            Presence      = [math]::Round($presence, 2)
            Vendor        = if ($e) { $e.Vendor } else { $null }
            Category      = if ($e) { $e.Category } else { $null }
            Services      = if ($e) { @($e.Services) } else { @() }
            Path          = if ($e) { $e.Path } else { $null }
            Score         = [math]::Round($slowCpu * $presence * $boost, 2)
        }
    }

    [pscustomobject]@{
        SlowSampleCount   = $slowCount
        NormalSampleCount = $normTs.Count
        Comparable        = ($normTs.Count -gt 0)
        ByCpu             = @($rows | Sort-Object Score -Descending | Select-Object -First $TopN)
        ByIo              = @($rows | Sort-Object SlowIoOps -Descending | Select-Object -First $TopN)
        ByMemory          = @($rows | Sort-Object PrivateMB -Descending | Select-Object -First $TopN)
        All               = @($rows)
    }
}

function Get-AgentTax {
    <#
      "Guvenlik ajani vergisi": etiketlenmis ajanlarin toplam CPU, disk islemi
      ve bellek payi.

      Identified listesi ATIF TABLOSUNDAN uretilir; boylece her ajan
      process'i kendi performans metrikleriyle birlikte gorunur (PID bazinda,
      gruplanmadan).

      Onemli sinir: bu, ajanlarin DOGRUDAN tukettigidir. Minifilter
      suruculerinin cekirdek modunda urettigi gecikme buraya YANSIMAZ -- o,
      kurbanin (Explorer, derleyici, Office) bekleme suresi ve DPC yuzdesi
      olarak gorunur.
    #>
    param($SampleList, $Enrichment, $Attribution)

    $byCat = @{}
    $totalCpu = 0.0; $agentCpu = 0.0
    $totalIo  = 0.0; $agentIo  = 0.0
    $agentMem = 0.0
    $n = 0

    foreach ($smp in @($SampleList)) {
        $n++
        foreach ($p in @($smp.Processes)) {
            $cpu = ConvertTo-Num $p.CpuPct 0
            $io  = (ConvertTo-Num $p.IoReadOpsPerSec 0) + (ConvertTo-Num $p.IoWriteOpsPerSec 0)
            $totalCpu += $cpu; $totalIo += $io
            $e = $Enrichment[$p.Pid]
            if ($e -and $e.Category) {
                $agentCpu += $cpu; $agentIo += $io
                $agentMem += (ConvertTo-Num $p.PrivateMB 0)
                $cat = $e.Category
                if (-not $byCat.ContainsKey($cat)) {
                    $byCat[$cat] = [ordered]@{ Cpu = 0.0; Io = 0.0; Mem = 0.0; Vendors = @{}; Procs = @{} }
                }
                $byCat[$cat].Cpu += $cpu
                $byCat[$cat].Io  += $io
                $byCat[$cat].Mem += (ConvertTo-Num $p.PrivateMB 0)
                $byCat[$cat].Procs[$p.Pid] = $true
                if ($e.Vendor) { $byCat[$cat].Vendors[$e.Vendor] = $true }
            }
        }
    }
    if ($n -eq 0) { $n = 1 }

    $cats = @()
    foreach ($k in $byCat.Keys) {
        $cats += [pscustomobject]@{
            Category       = $k
            ProcessCount   = $byCat[$k].Procs.Count
            AvgCpuPct      = Round2 ($byCat[$k].Cpu / $n)
            AvgIoOpsPerSec = [int]($byCat[$k].Io / $n)
            AvgPrivateMB   = [int]($byCat[$k].Mem / $n)
            Vendors        = @($byCat[$k].Vendors.Keys | Sort-Object)
        }
    }

    # Her ajan process'i, kendi olculen metrikleriyle birlikte (PID bazinda).
    $identified = @()
    foreach ($r in @($Attribution.All)) {
        if (-not $r.Category) { continue }
        $identified += [pscustomobject]@{
            Pid         = $r.Pid
            Name        = $r.Name
            Vendor      = $r.Vendor
            Category    = $r.Category
            CpuPct      = $r.SlowCpuPct
            CpuDelta    = $r.CpuDelta
            PrivateMB   = $r.PrivateMB
            IoOpsPerSec = $r.SlowIoOps
            IoKBPerSec  = $r.IoKBPerSec
            Handles     = $r.Handles
            Threads     = $r.Threads
            Services    = @($r.Services)
            Path        = $r.Path
        }
    }

    [pscustomobject]@{
        AgentAvgCpuPct   = Round2 ($agentCpu / $n)
        SystemAvgCpuPct  = Round2 ($totalCpu / $n)
        CpuSharePct      = if ($totalCpu -gt 0) { Round2 ($agentCpu / $totalCpu * 100) } else { $null }
        AgentAvgIoOps    = [int]($agentIo / $n)
        SystemAvgIoOps   = [int]($totalIo / $n)
        IoSharePct       = if ($totalIo -gt 0) { Round2 ($agentIo / $totalIo * 100) } else { $null }
        AgentAvgMemMB    = [int]($agentMem / $n)
        ByCategory       = @($cats | Sort-Object AvgCpuPct -Descending)
        Identified       = @($identified | Sort-Object CpuPct -Descending)
        DistinctVendors  = @($identified | ForEach-Object { $_.Vendor } | Sort-Object -Unique)
    }
}

function New-Finding {
    param([string]$Severity, [string]$Title, [string[]]$Evidence, [string]$Note)
    [pscustomobject]@{ Severity = $Severity; Title = $Title; Evidence = @($Evidence); Note = $Note }
}

function Get-Findings {
    param($Caps, $Static, $Scores, $Windows, $Attribution, $AgentTax, $SampleList)

    $f = @()
    $sev = @{ K = 'kritik'; Y = 'yuksek'; O = 'orta'; B = 'bilgi' }

    # --- dinamik ---
    if (@($Scores).Count -gt 0) {
        $avg  = (@($Scores) | ForEach-Object { $_.Score } | Measure-Object -Average).Average
        $peak = (@($Scores) | ForEach-Object { $_.Score } | Measure-Object -Maximum).Maximum

        if (@($Windows).Count -eq 0) {
            $f += New-Finding $sev.B 'Olcum suresince yavas pencere olusmadi' `
                @(("ortalama basinc skoru {0}, tepe {1} (esik {2})" -f (Round2 $avg), (Round2 $peak), $script:SlowThreshold)) `
                'Yavaslik araliksa Monitor modunu is gunu boyunca calistirip olayin yasandigi ani yakalamak gerekir.'
        } else {
            $slowN = (@($Windows) | ForEach-Object { $_.SampleCount } | Measure-Object -Sum).Sum
            $ratio = $slowN / @($Scores).Count
            $ev = @()
            $i = 0
            foreach ($w in @($Windows) | Select-Object -First 6) {
                $i++
                $ev += ("pencere {0}: {1}, {2} sn, tepe skor {3}" -f $i, $w.Start.ToString('HH:mm:ss'), $w.DurationSec, (Round2 $w.Peak))
            }
            $f += New-Finding $(if ($ratio -gt 0.3) { $sev.Y } else { $sev.O }) `
                ("{0} yavas pencere tespit edildi ({1}/{2} ornek)" -f @($Windows).Count, $slowN, @($Scores).Count) `
                $ev ''

            # baskin bilesen (agirlikli katki)
            $tot = @{}
            foreach ($s in @($Scores)) {
                if ($s.Score -lt $script:SlowThreshold) { continue }
                foreach ($k in $script:ScoreWeights.Keys) {
                    if (-not $tot.ContainsKey($k)) { $tot[$k] = 0.0 }
                    $tot[$k] += $script:ScoreWeights[$k] * $s.Components.$k.Score
                }
            }
            $labels = $script:ComponentLabels
            $ranked = @($tot.GetEnumerator() | Sort-Object Value -Descending)
            if ($ranked.Count -gt 0 -and $ranked[0].Value -gt 0) {
                $ev = @()
                foreach ($r in $ranked | Select-Object -First 3) {
                    if ($r.Value -le 0) { continue }
                    $sample = $null
                    foreach ($s in @($Scores)) {
                        if ($s.Score -ge $script:SlowThreshold -and $s.Components.($r.Key).Evidence) {
                            $sample = $s.Components.($r.Key).Evidence; break
                        }
                    }
                    $line = "{0} (agirlikli katki {1})" -f $labels[$r.Key], (Round2 $r.Value)
                    if ($sample) { $line += " -- ornek: $sample" }
                    $ev += $line
                }
                $f += New-Finding $sev.Y ("Yavasligin baskin bileseni: {0}" -f $labels[$ranked[0].Key]) $ev `
                    'Iyilestirme cabasi once bu bilesene yonelmelidir.'
            }
        }

        # DPC/kesme ozel uyarisi -- filtre surucusu parmak izi
        # 0.30 skor ~ %9.5 DPC+kesme demektir. Istemci makinesinde normal deger
        # %1-2'dir; surekli %9-10, surucu yiginini incelemek icin yeterli sinyaldir.
        $dpcVals = @($Scores | ForEach-Object { $_.Components.DpcInterrupt.Score })
        if (($dpcVals | Measure-Object -Maximum).Maximum -ge 0.30) {
            $f += New-Finding $sev.Y 'Cekirdek modu (DPC + kesme) yuku yuksek' `
                @($Scores | Where-Object { $_.Components.DpcInterrupt.Evidence } |
                    Select-Object -First 4 | ForEach-Object { "$($_.Ts.ToString('HH:mm:ss')): $($_.Components.DpcInterrupt.Evidence)" }) `
                ('Bu yuk hicbir kullanici process''inde gorunmez; surucu kaynaklidir. En sik nedenleri: ust uste binmis dosya sistemi filtreleri (AV/DLP/sifreleme), ag filtre suruculeri ve eski depolama suruculeri. Rapordaki filtre yigini bolumuyle birlikte degerlendirin.')
        }

        # disk gecikmesi
        $lat = @($Scores | Where-Object { $_.Components.DiskLatency.Score -gt 0.3 })
        if ($lat.Count -gt 0) {
            $f += New-Finding $sev.Y 'Disk gecikmesi normalin uzerinde' `
                @($lat | Select-Object -First 4 | ForEach-Object { "$($_.Ts.ToString('HH:mm:ss')): $($_.Components.DiskLatency.Evidence)" }) `
                'NVMe SSD''de 1-2 ms, SATA SSD''de 2-5 ms beklenir. 15 ms uzeri surekli degerler, ya donanim sorununu ya da her I/O islemini inceleyen bir filtre yiginini gosterir.'
        }
    }

    # --- suclu adaylari ---
    if (@($Attribution.ByCpu).Count -gt 0 -and $Attribution.SlowSampleCount -gt 0) {
        $ev = @()
        foreach ($r in @($Attribution.ByCpu) | Select-Object -First 5) {
            $line = "{0} (PID {1}): yavaş anlarda ort. işlemci %{2}" -f $r.Name, $r.Pid, $r.SlowCpuPct
            if ($null -ne $r.NormCpuPct) { $line += ", normal anlarda %{0} → fark {1:+0.00;-0.00;0} ({2})" -f $r.NormCpuPct, $r.CpuDelta, $r.CpuTrend }
            $line += "; {0}/{1} yavaş örnekte görüldü" -f $r.SamplesSlow, $Attribution.SlowSampleCount
            if ($r.Vendor) { $line += " [{0} / {1}]" -f $r.Vendor, $r.Category }
            $ev += $line
        }
        $note = ''
        if (-not $Attribution.Comparable) {
            $note = 'UYARI: karsilastirilacak normal pencere yok. Bu siralama "yavaslik aninda en cok tuketenler" demektir; nedensellik KANITLANMAMISTIR.'
        }
        $f += New-Finding $sev.Y 'CPU tarafinda basli adaylar' $ev $note
    }

    # --- ajan vergisi ---
    if ($AgentTax.DistinctVendors.Count -gt 0) {
        $ev = @(("Tespit edilen guvenlik/yonetim saglayicisi: {0}" -f ($AgentTax.DistinctVendors -join ', ')))
        if ($null -ne $AgentTax.CpuSharePct) {
            $ev += ("Ajanlarin CPU payi: olculen toplam CPU'nun %{0}'i (ort. %{1} mutlak)" -f $AgentTax.CpuSharePct, $AgentTax.AgentAvgCpuPct)
        }
        if ($null -ne $AgentTax.IoSharePct) {
            $ev += ("Ajanlarin disk islemi payi: %{0} ({1} islem/sn)" -f $AgentTax.IoSharePct, $AgentTax.AgentAvgIoOps)
        }
        $ev += ("Ajanlarin ozel bellek toplami: {0} MB" -f $AgentTax.AgentAvgMemMB)
        $sevAgent = $sev.B
        if ($AgentTax.CpuSharePct -gt 25 -or $AgentTax.IoSharePct -gt 40) { $sevAgent = $sev.Y }
        elseif ($AgentTax.CpuSharePct -gt 12) { $sevAgent = $sev.O }
        $f += New-Finding $sevAgent ("Guvenlik/yonetim ajani yuku: {0} farkli saglayici" -f $AgentTax.DistinctVendors.Count) $ev `
            'Bu rakam ajanlarin DOGRUDAN tukettigidir. Filtre suruculerinin cekirdek modunda urettigi gecikme buraya yansimaz; o, kurban uygulamalarin I/O bekleme suresi olarak gorunur.'
    }

    # --- filtre yigini ---
    $mf = @($Static.MiniFilters.Registry | Where-Object { $_.Running })
    if ($mf.Count -gt 0) {
        $byGroup = @($mf | Group-Object Group | Sort-Object Count -Descending)
        $ev = @()
        foreach ($g in $byGroup) {
            $ev += "{0}: {1} adet -- {2}" -f $g.Name, $g.Count, (@($g.Group | ForEach-Object { $_.Name }) -join ', ')
        }
        $avCount = @($mf | Where-Object { $_.Group -like '*Anti-Virus*' }).Count
        $sevMf = $sev.B
        if ($avCount -ge 3 -or $mf.Count -ge 12) { $sevMf = $sev.Y }
        elseif ($avCount -ge 2 -or $mf.Count -ge 8) { $sevMf = $sev.O }
        $f += New-Finding $sevMf ("Calisan dosya sistemi filtre surucusu: {0} adet ({1} tanesi Anti-Virus sinifinda)" -f $mf.Count, $avCount) $ev `
            'Her dosya acma/okuma/yazma islemi bu filtrelerin HEPSININ icinden gecer. Ayni sinifta birden fazla filtre varsa ayni dosya birden fazla kez taranir. Bunlar politika geregi kaldirilamaz; hedef, derleme dizinleri, sanal makine imajlari, kod depolari ve veritabani dosyalari icin karsilikli istisna (exclusion) tanimlamaktir.'
    }

    # --- guc plani ve islemcinin GERCEK hizi ---
    #
    # Onceki surumde "PROCTHROTTLEMAX < 100 ise CPU tam hiza cikamaz" deniyordu.
    # Bu cikarim guvenilir DEGILDI:
    #   1. Modern Windows 11 sistemlerinde islemci hizi cogunlukla donanim
    #      tarafindan yonetilir (Intel Speed Shift / AMD CPPC). Bu durumda
    #      PROCTHROTTLEMAX ayari isletim sistemi tarafindan uygulanmayabilir.
    #   2. Win32_Processor.CurrentClockSpeed guvenilmezdir: cogu sistemde
    #      nominal degeri tekrarlar, bazilarinda bosta anlik olcum verir.
    #   3. En onemlisi: BOSTAKI islemcinin dusuk frekansta olmasi NORMALDIR,
    #      hatta istenen davranistir. Yuk yokken 1200 MHz gormek sorun degildir.
    #
    # Bu yuzden artik iki sey AYRI ayri raporlanir:
    #   (a) Ayarin okunan degeri -- iddia degil, kayit.
    #   (b) Yuk YUKSEKKEN olculen gercek islemci performansi -- asil kanit.

    $perfSamples = @()
    foreach ($smp in @($SampleList)) {
        $mm = $smp.Metrics
        if ($null -eq $mm.CpuPerfPct) { continue }
        if ((ConvertTo-Num $mm.CpuTotalPct 0) -lt 60) { continue }   # bostaki olcum anlamsiz
        $perfSamples += $mm
    }

    $throttleProven = $false
    if ($perfSamples.Count -gt 0) {
        $avgPerf = (@($perfSamples | ForEach-Object { $_.CpuPerfPct }) | Measure-Object -Average).Average
        if ($avgPerf -lt 80) {
            $throttleProven = $true
            $ev = @(("{0} örnekte işlemci %60'ın üzerinde yüklüyken, nominal hızının ortalama %{1}'inde çalıştı" -f $perfSamples.Count, (Round2 $avgPerf)))
            foreach ($mm in @($perfSamples | Select-Object -First 4)) {
                $ev += ("{0}: işlemci %{1} yüklü, nominal hızın %{2}'i{3}" -f $mm.Ts.ToString('HH:mm:ss'), $mm.CpuTotalPct, $mm.CpuPerfPct, $(if ($mm.CpuFreqMHz) { " ($($mm.CpuFreqMHz) MHz)" } else { '' }))
            }
            $f += New-Finding $sev.Y 'İşlemci, yük altındayken bile nominal hızına çıkamadı' $ev `
                ('Bu bir ÖLÇÜMDÜR, ayar okumasından çıkarılmış bir tahmin değil: işlemci gerçekten yüklüyken nominal hızın altında kaldı. Olası nedenler: güç planı sınırı, termal kısıtlama (ısınma), üretici firmware ayarı veya pil modunda çalışma. Ayrım için makine prize takılıyken ve soğukken tekrar ölçün.')
        } elseif ($avgPerf -ge 95) {
            $f += New-Finding $sev.B 'İşlemci hızında kısıtlama ölçülmedi' `
                @(("İşlemci %60'ın üzerinde yüklü olduğu {0} örnekte nominal hızının ortalama %{1}'inde çalıştı" -f $perfSamples.Count, (Round2 $avgPerf))) `
                'Yavaşlık nedeni işlemci hızı değildir; başka bileşenlere bakın.'
        }
    } else {
        Add-Gap -Source 'CpuPerformance' -Reason 'İşlemci %60 üzerinde yüklü örnek olmadığı için gerçek hız ölçülemedi'
    }

    # (a) Ayarin okunan degeri -- yorum degil, kayit
    $tm = $Static.Power.ThrottleMax
    if ($tm -and $null -ne $tm.AcMaxPct -and $tm.AcMaxPct -lt 100) {
        $note = 'Bu bir AYAR OKUMASIDIR, ölçüm değil. Windows 11''de işlemci hızı çoğunlukla donanım tarafından yönetilir (Intel Speed Shift / AMD CPPC) ve bu ayar fiilen uygulanmıyor olabilir.'
        $severity = $sev.O
        if ($throttleProven) {
            $note = 'Bu ayar, yukarıdaki ÖLÇÜMLE birlikte değerlendirildiğinde güçlü bir aday: işlemci yük altında gerçekten nominal hızın altında kaldı ve bu ayar da sınırlama gösteriyor. Domain GPO''su ile dayatılmışsa değişiklik BT tarafından yapılmalıdır.'
            $severity = $sev.Y
        } elseif ($perfSamples.Count -gt 0) {
            $note = 'Bu ayar sınırlama gösteriyor ANCAK ölçüm bunu doğrulamadı: işlemci yük altında nominal hızına çıkabildi. Büyük olasılıkla ayar fiilen uygulanmıyor. Yavaşlığın nedeni bu değildir.'
            $severity = $sev.B
        }
        $f += New-Finding $severity 'Güç planında maksimum işlemci durumu %100''ün altında ayarlanmış' `
            @(("Prize takılıyken (AC) maksimum işlemci durumu: %{0}" -f $tm.AcMaxPct),
              ("Pilde (DC) maksimum işlemci durumu: %{0}" -f $tm.DcMaxPct),
              ("Aktif güç planı: {0}" -f $Static.Power.ActiveScheme),
              "Kendiniz doğrulamak için: powercfg /query SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMAX") `
            $note
    }

    # --- disk doluluk ---
    foreach ($v in @($Static.Storage.Volumes)) {
        if ($null -ne $v.FreePct -and $v.FreePct -lt 12) {
            $f += New-Finding $(if ($v.FreePct -lt 6) { $sev.Y } else { $sev.O }) `
                ("Disk doluluk orani kritik: {0}" -f $v.Drive) `
                @(("{0} bos {1} GB / {2} GB (%{3})" -f $v.Drive, $v.FreeGB, $v.SizeGB, $v.FreePct)) `
                'Bos alan azaldiginda sayfa dosyasi genisleyemez ve NTFS parcalanmasi artar; sistem geneli yavaslar.'
        }
    }

    # --- donen disk ---
    $hdd = @($Static.Storage.Physical | Where-Object { $_.MediaType -eq 'HDD' })
    if ($hdd.Count -gt 0) {
        $f += New-Finding $sev.Y 'Sistemde mekanik disk (HDD) var' `
            @($hdd | ForEach-Object { "{0} -- {1} GB, {2}" -f $_.Name, $_.SizeGB, $_.BusType }) `
            'Windows 11 + bir AV ajani + mekanik disk kombinasyonu tek basina ciddi yavaslik uretir. Filtre yigini ile birleştiginde etki carpanlanir. Kalici cozum SSD''dir.'
    }

    # --- VBS / HVCI ---
    $dg = $Static.Posture.DeviceGuard
    if ($dg -and ($dg.EnableVirtualizationBasedSecurity -eq 1 -or $dg.HvciEnabled -eq 1)) {
        $f += New-Finding $sev.B 'Sanallastirma tabanli guvenlik (VBS/HVCI) etkin' `
            @(("VBS: {0}, HVCI: {1}" -f $dg.EnableVirtualizationBasedSecurity, $dg.HvciEnabled)) `
            'HVCI, surucu yogun ve I/O yogun is yuklerinde olculebilir ek yuk getirir. Guvenlik gereksinimi oldugu icin kapatmak genellikle secenek degildir; not olarak kayda gecirilir.'
    }

    # --- acilis olaylari ---
    if ($Static.Events -and @($Static.Events.Boot).Count -gt 0) {
        $degr = @($Static.Events.Boot | Where-Object { $_.Id -in 101, 102, 103, 109 } | Select-Object -First 6)
        if ($degr.Count -gt 0) {
            $f += New-Finding $sev.O 'Acilisi yavaslatan bilesenler olay gunlugunde kayitli' `
                @($degr | ForEach-Object { "{0} [ID {1}] {2}" -f $_.Time, $_.Id, ($_.Message.Substring(0, [math]::Min(220, $_.Message.Length))) }) `
                'Bu olaylar yavaslatan uygulamayi/servisi adiyla ve milisaniye cinsinden sureyle verir; dogrudan eyleme donusturulebilir.'
        }
    }

    # --- kaynak tukenmesi ---
    if ($Static.Events) {
        $ex = @($Static.Events.System | Where-Object { $_.Id -eq 2004 } | Select-Object -First 3)
        if ($ex.Count -gt 0) {
            $f += New-Finding $sev.Y 'Windows kaynak tukenmesi uyarisi vermis (Event ID 2004)' `
                @($ex | ForEach-Object { "{0}: {1}" -f $_.Time, ($_.Message.Substring(0, [math]::Min(220, $_.Message.Length))) }) `
                'Bu, sanal bellegin gercekten tukendiginin kesin kanitidir. Ayar degil, es zamanli is yukunun azaltilmasi veya RAM artirimi gerekir.'
        }
    }

    # --- olculemeyenler ---
    foreach ($w in @($script:Warnings | Group-Object Source)) {
        $null = $w
    }
    if (-not $Caps.Elevated) {
        $f += New-Finding $sev.B 'Standart kullanici yetkisiyle calisildi' `
            @('fltmc (yuklu filtre yigini) okunamadi -- kayit defteri + Win32_SystemDriver ile telafi edildi',
              'Acilis performans olaylari ve bazi olay gunlukleri erisilemeyebilir') `
            'Yonetici hesabiyla tekrar calistirmak filtre yigininin GERCEK yuklenme sirasini ve acilis olaylarini ekler. Mevcut bulgular bundan bagimsiz olarak gecerlidir.'
    }

    return @($f)
}

#endregion
#region -------------------------------------------------------------- Rapor

function ConvertTo-HtmlText {
    param($Value)
    if ($null -eq $Value) { return '-' }
    $s = [string]$Value
    $s = $s -replace '&', '&amp;' -replace '<', '&lt;' -replace '>', '&gt;' -replace '"', '&quot;'
    return $s
}

function New-HtmlTable {
    param([string[]]$Headers, $Rows, [string[]]$Fields)
    $sb = @()
    $sb += '<table><thead><tr>'
    foreach ($h in $Headers) { $sb += "<th>$(ConvertTo-HtmlText $h)</th>" }
    $sb += '</tr></thead><tbody>'
    foreach ($r in @($Rows)) {
        $sb += '<tr>'
        foreach ($fld in $Fields) {
            $v = $r.$fld
            if ($v -is [array]) { $v = ($v -join ', ') }
            $sb += "<td>$(ConvertTo-HtmlText $v)</td>"
        }
        $sb += '</tr>'
    }
    $sb += '</tbody></table>'
    return ($sb -join '')
}

function New-Section {
    # Her bolum, NEDEN incelendigi aciklamasiyla birlikte basilir.
    param([string]$Title, [string]$Why)
    "<h2>$(ConvertTo-HtmlText $Title)</h2><div class='why'><b>Neden bakıyoruz:</b> $Why</div>"
}

$script:HtmlStyle = @'
<style>
:root{--bg:#0f1115;--card:#171a21;--fg:#e6e8ee;--mut:#9aa3b2;--line:#262b36;
--k:#ff5c5c;--y:#ff9f43;--o:#ffd166;--b:#5aa9e6;--ok:#4cc38a}
*{box-sizing:border-box}
body{margin:0;padding:24px;background:var(--bg);color:var(--fg);
font-family:"Segoe UI",system-ui,sans-serif;font-size:14px;line-height:1.55}
h1{font-size:22px;margin:0 0 4px}h2{font-size:17px;margin:28px 0 10px;
padding-bottom:6px;border-bottom:1px solid var(--line)}h3{font-size:15px;margin:18px 0 8px}
.sub{color:var(--mut);margin-bottom:18px}
.card{background:var(--card);border:1px solid var(--line);border-radius:8px;
padding:14px 16px;margin:10px 0}
table{border-collapse:collapse;width:100%;margin:8px 0;font-size:13px}
th,td{border:1px solid var(--line);padding:6px 9px;text-align:left;vertical-align:top}
th{background:#1d212a;color:var(--mut);font-weight:600;white-space:nowrap}
tr:nth-child(even) td{background:#13161c}
code{background:#0b0d11;padding:2px 5px;border-radius:3px;font-size:12px;
color:#c8d3e0;word-break:break-all}
.sev{display:inline-block;padding:2px 8px;border-radius:4px;font-size:11px;
font-weight:700;letter-spacing:.4px;margin-right:8px}
.sev-kritik{background:var(--k);color:#111}.sev-yuksek{background:var(--y);color:#111}
.sev-orta{background:var(--o);color:#111}.sev-bilgi{background:var(--b);color:#111}
ul{margin:6px 0 6px 18px;padding:0}li{margin:3px 0}
.note{color:var(--mut);font-size:13px;margin-top:8px;border-left:2px solid var(--line);padding-left:10px}
.why{background:#141821;border-left:3px solid var(--b);padding:10px 14px;margin:0 0 14px;
border-radius:0 6px 6px 0;color:#bcc6d4;font-size:13px}
.legend{background:#141821;border:1px dashed var(--line);border-radius:6px;padding:10px 14px;
margin:8px 0;font-size:13px;color:#bcc6d4}
.up{color:#ff9f43;font-weight:600}.down{color:#5aa9e6}.flat{color:var(--mut)}
td.reason{font-size:12px;color:#ffd7a8;max-width:460px}
.warn{border-left:3px solid var(--y);padding-left:12px;margin:10px 0;color:#ffd7a8}
.slow{color:var(--k);font-weight:700}
.metric{display:inline-block;margin-right:26px}
.metric b{display:block;font-size:20px}.metric span{color:var(--mut);font-size:12px}
footer{margin-top:34px;color:var(--mut);font-size:12px;border-top:1px solid var(--line);padding-top:12px}
</style>
'@

function New-HtmlReport {
    param($Run)

    $caps  = $Run.Capabilities
    $stat  = $Run.Static
    $scr   = @($Run.Scores)
    $win   = @($Run.SlowWindows)
    $attr  = $Run.Attribution
    $tax   = $Run.AgentTax
    $find  = @($Run.Findings)

    $h = @()
    $h += '<!DOCTYPE html><html lang="tr"><head><meta charset="utf-8">'
    $h += '<title>WinPerfDiag Raporu</title>' + $script:HtmlStyle + '</head><body>'
    $h += "<h1>WinPerfDiag Performans Raporu</h1>"
    $h += "<div class='sub'>$(ConvertTo-HtmlText $caps.ComputerName) &nbsp;|&nbsp; $(ConvertTo-HtmlText $caps.UserName) &nbsp;|&nbsp; $($Run.StartedAt) &nbsp;|&nbsp; $(@($Run.Samples).Count) ölçüm &nbsp;|&nbsp; $(if ($caps.Elevated) { 'yönetici' } else { 'standart kullanıcı' })</div>"

    # ---------------------------------------------------------------- 1. Özet
    $h += (New-Section '1. Yönetici özeti' `
        'Raporun tamamını okumadan karar verebilmek için. Aşağıdaki maddeler, ölçümlerden çıkan ve eyleme dönüştürülebilir bulgulardır; ciddiyet sırasına göre dizilmiştir.')
    $order = @{ kritik = 0; yuksek = 1; orta = 2; bilgi = 3 }
    $ranked = @($find | Sort-Object { $order[$_.Severity] })
    $action = @($ranked | Where-Object { $_.Severity -ne 'bilgi' })
    if ($action.Count -eq 0) {
        $h += "<div class='card'>Eyleme dönük bulgu yok. Ölçülemeyen kaynaklar listesini yine de gözden geçirin.</div>"
    } else {
        $h += "<div class='card'><ul>"
        foreach ($f in $action | Select-Object -First 8) {
            $h += "<li><span class='sev sev-$($f.Severity)'>$($f.Severity.ToUpper())</span>$(ConvertTo-HtmlText $f.Title)</li>"
        }
        $h += '</ul></div>'
    }

    if ($tax -and $tax.DistinctVendors.Count -gt 0) {
        $h += "<div class='card'>"
        $h += "<span class='metric'><b>$($tax.DistinctVendors.Count)</b><span>farklı güvenlik/yönetim sağlayıcısı</span></span>"
        $h += "<span class='metric'><b>%$($tax.CpuSharePct)</b><span>ölçülen CPU'nun ajan payı</span></span>"
        $h += "<span class='metric'><b>%$($tax.IoSharePct)</b><span>disk işlemlerinin ajan payı</span></span>"
        $h += "<span class='metric'><b>$($tax.AgentAvgMemMB) MB</b><span>ajanların kullandığı RAM</span></span>"
        $h += '</div>'
    }

    # ------------------------------------------------------------ 2. Sözlük
    $h += (New-Section '2. Raporda geçen terimler' `
        'Bu raporda teknik terim kullanmak zorunda kaldığımız yerlerde ne kastettiğimizi burada açıklıyoruz. Bir tabloyu okurken takılırsanız buraya dönün.')
    $glossary = @(
        [pscustomobject]@{ T = 'Yavaşlık skoru'; A = '0 ile 1 arasında bir sayı. Her ölçüm anında altı ayrı göstergeye bakılır (aşağıdaki satırlar) ve bunlar tek bir puana çevrilir. ' + $script:SlowThreshold + ' ve üstü "bu anda makine gerçekten yavaştı" demektir.' }
        [pscustomobject]@{ T = 'RAM yetersizliği'; A = $script:ComponentWhy['Memory'] }
        [pscustomobject]@{ T = 'Disk yanıt süresi'; A = $script:ComponentWhy['DiskLatency'] + ' NVMe SSD''de 1-2 ms, SATA SSD''de 2-5 ms normaldir. 15 ms üzeri sorunludur.' }
        [pscustomobject]@{ T = 'Sürücü yükü (DPC + kesme)'; A = $script:ComponentWhy['DpcInterrupt'] + ' Normal değer %1-2''dir.' }
        [pscustomobject]@{ T = 'CPU sırası'; A = $script:ComponentWhy['CpuQueue'] }
        [pscustomobject]@{ T = 'CPU doluluğu'; A = $script:ComponentWhy['CpuSaturation'] }
        [pscustomobject]@{ T = 'Disk sırası'; A = $script:ComponentWhy['DiskQueue'] }
        [pscustomobject]@{ T = 'Dosya sistemi filtresi (minifilter)'; A = 'Diskteki her dosya işlemini araya girerek inceleyen sürücü. Antivirüs, DLP ve şifreleme ürünleri bu yöntemle çalışır. Ne kadar çoksa her dosya işlemi o kadar uzun sürer.' }
        [pscustomobject]@{ T = 'Şüphe skoru'; A = 'Bir process''in yavaşlıktan sorumlu olma ihtimali. Sadece "çok tüketiyor" yetmez; yavaşlık anında normale göre YÜKSELMİŞ olması gerekir. Skor bu artışı ödüllendirir.' }
        [pscustomobject]@{ T = 'Takas (paging)'; A = 'RAM yetmediğinde Windows''un program belleğini diske yazıp yer açması. Geri okunması gerektiğinde bekleme oluşur.' }
    )
    $h += (New-HtmlTable -Headers @('Terim', 'Ne demek') -Rows $glossary -Fields @('T', 'A'))

    # ------------------------------------------------------ 3. Ölçüm kapsamı
    $h += (New-Section '3. Ölçüm kapsamı ve sınırları' `
        'Bir bulgunun yokluğu, sorunun yokluğu anlamına gelmez. Bu bölüm hangi veri kaynağına erişebildiğimizi gösterir; KAPALI görünen bir satır, o konuda hiçbir şey söyleyemediğimiz anlamına gelir. Yetki seviyesi ve kurum politikaları bu listeyi doğrudan etkiler.')
    $probeRows = @()
    $probeLabels = [ordered]@{
        PerfProc    = 'Process başına CPU / RAM / disk işlemi'
        PerfDisk    = 'Disk yanıt süresi ölçümü'
        PerfOS      = 'CPU sırası, bağlam değişimi'
        PerfCpu     = 'Sürücü yükü (DPC / kesme)'
        Services    = 'Servis envanteri'
        SysDriver   = 'Sürücülerin çalışma durumu'
        Registry    = 'Dosya sistemi filtreleri (kayıt defteri)'
        SchedTask   = 'Zamanlanmış görevler'
        EventSystem = 'Sistem olay günlüğü'
        EventBoot   = 'Açılış performansı olayları (yönetici gerekir)'
        EventGpo    = 'Grup İlkesi işleme süreleri (yönetici gerekir)'
        Fltmc       = 'Filtrelerin gerçek yüklenme sırası (yönetici gerekir)'
        Defender    = 'Microsoft Defender durumu'
        PhysDisk    = 'Disk türü (SSD / HDD)'
    }
    foreach ($k in $probeLabels.Keys) {
        $ok = $false
        if ($caps.Probe -and $caps.Probe[$k]) { $ok = [bool]$caps.Probe[$k] }
        $probeRows += [pscustomobject]@{
            Kaynak = $probeLabels[$k]
            Durum  = $(if ($ok) { 'ölçüldü' } else { 'ÖLÇÜLEMEDİ' })
        }
    }
    $h += (New-HtmlTable -Headers @('Ne ölçülüyor', 'Durum') -Rows $probeRows -Fields @('Kaynak', 'Durum'))

    if (@($Run.Gaps).Count -gt 0) {
        $h += "<h3>Ölçülemeyenler ve nedenleri</h3><div class='card'><ul>"
        foreach ($g in @($Run.Gaps | Group-Object Source | Select-Object -First 20)) {
            $h += "<li><code>$(ConvertTo-HtmlText $g.Name)</code> — $(ConvertTo-HtmlText $g.Group[0].Reason)</li>"
        }
        $h += '</ul></div>'
    }

    # ------------------------------------------------------------- 4. Sistem
    $h += (New-Section '4. Sistem künyesi' `
        'Aynı yavaşlık şikâyeti, donanıma göre tamamen farklı anlamlar taşır. 8 GB RAM''li ve mekanik diskli bir makinede "RAM yetersizliği" beklenen bir sonuçken, 32 GB RAM''li bir makinede aynı bulgu bir programın bellek kaçırdığına işaret eder. Sonraki bölümleri bu tabloya bakarak yorumlayın.')
    $sysRows = @(
        [pscustomobject]@{ A = 'Model';        B = $caps.Model },
        [pscustomobject]@{ A = 'İşlemci';      B = $caps.CpuName },
        [pscustomobject]@{ A = 'Çekirdek';     B = "$($caps.LogicalCpu) mantıksal" },
        [pscustomobject]@{ A = 'RAM';          B = "$($caps.TotalMemoryMB) MB" },
        [pscustomobject]@{ A = 'İşletim sistemi'; B = "$($caps.OsCaption) ($($caps.OsVersion) build $($caps.OsBuild))" },
        [pscustomobject]@{ A = 'Son açılış';   B = $caps.LastBootUpTime },
        [pscustomobject]@{ A = 'Domain';       B = $(if ($caps.DomainJoined) { $caps.Domain } else { 'domaine dahil değil' }) },
        [pscustomobject]@{ A = 'Çalıştıran';   B = "$($caps.UserName) — $(if ($caps.Elevated) { 'yönetici' } else { 'standart kullanıcı' })" },
        [pscustomobject]@{ A = 'PowerShell';   B = "$($caps.PsVersion) / dil modu: $($caps.LanguageMode)" },
        [pscustomobject]@{ A = 'Aktif güç planı'; B = $stat.Power.ActiveScheme }
    )
    $h += (New-HtmlTable -Headers @('Alan', 'Değer') -Rows $sysRows -Fields @('A', 'B'))

    # -------------------------------------------------- 5. Zaman serisi
    if ($scr.Count -gt 0) {
        $h += (New-Section '5. Ölçüm boyunca ne oldu' `
            ('Yavaşlık genellikle sürekli değil, anlıktır. Bu tablo her ölçüm anını ayrı satır olarak gösterir; böylece "makine ne zaman yavaşladı" ve daha önemlisi "o anda NEDEN yavaşladı" sorusu cevaplanır. Skor ' + $script:SlowThreshold + ' ve üstündeki satırlar YAVAŞ olarak işaretlenir ve en sağdaki sütunda nedeni yazar.'))
        $tsRows = @()
        foreach ($s in $scr) {
            $c = $s.Components
            $isSlow = ($s.Score -ge $script:SlowThreshold)
            $tsRows += [pscustomobject]@{
                Saat    = $s.Ts.ToString('HH:mm:ss')
                Skor    = $s.Score
                Durum   = $(if ($isSlow) { 'YAVAŞ' } else { 'normal' })
                Neden   = $(if ($isSlow) { Get-SlowReason -ScoreItem $s } else { '' })
            }
        }
        $h += (New-HtmlTable -Headers @('Saat', 'Yavaşlık skoru', 'Durum', 'Neden yavaştı') `
                             -Rows $tsRows -Fields @('Saat', 'Skor', 'Durum', 'Neden'))

        $h += '<h3>Ölçülen ham değerler</h3>'
        $h += "<div class='legend'>Yukarıdaki skorun hesaplandığı ham sayılar. <b>Sürücü yükü</b> sütunu özellikle önemlidir: oradaki yük hiçbir programda görünmez, sürücülerden gelir.</div>"
        $mRows = @()
        foreach ($smp in @($Run.Samples)) {
            $m = $smp.Metrics
            $mRows += [pscustomobject]@{
                Saat = $m.Ts.ToString('HH:mm:ss'); Cpu = $m.CpuTotalPct
                Dpc = $(if ($null -ne $m.CpuDpcPct) { [math]::Round((ConvertTo-Num $m.CpuDpcPct 0) + (ConvertTo-Num $m.CpuInterruptPct 0), 2) } else { $null })
                Hiz = $m.CpuPerfPct
                Kuyruk = $m.ProcessorQueueLength
                Bos = $m.AvailableMB; Commit = $m.CommitPct; Takas = $m.HardFaultsPerSec
                DR = $m.DiskReadMs; DW = $m.DiskWriteMs; DQ = $m.DiskQueueLength
            }
        }
        $h += (New-HtmlTable -Headers @('Saat','CPU doluluğu %','Sürücü yükü %','İşlemci hızı (nominalin %''i)','CPU sırası','Boş RAM (MB)','Ayrılmış bellek %','Takas (sayfa/sn)','Disk okuma (ms)','Disk yazma (ms)','Disk sırası') `
                             -Rows $mRows -Fields @('Saat','Cpu','Dpc','Hiz','Kuyruk','Bos','Commit','Takas','DR','DW','DQ'))
    }

    if ($win.Count -gt 0) {
        $h += '<h3>Yavaş dönemler</h3>'
        $wRows = @()
        $i = 0
        foreach ($w in $win) {
            $i++
            $wRows += [pscustomobject]@{
                No = $i; Bas = $w.Start.ToString('HH:mm:ss'); Sure = $w.DurationSec
                Ornek = $w.SampleCount; Tepe = [math]::Round($w.Peak, 3)
                Neden = (Get-SlowReason -ScoreItem (@($w.Items | Sort-Object Score -Descending)[0]))
            }
        }
        $h += (New-HtmlTable -Headers @('#','Başlangıç','Süre (sn)','Ölçüm sayısı','En kötü skor','En kötü anın nedeni') `
                             -Rows $wRows -Fields @('No','Bas','Sure','Ornek','Tepe','Neden'))
    }

    # ------------------------------------------------- 6. Suçlu adayları
    $h += (New-Section '6. Hangi process sorumlu' `
        'Yavaşlığın kaynağı bir programsa, o programı ismiyle ve PID''iyle bulmak gerekir. Burada her satır TEK BİR PROCESS''tir — aynı programın birden fazla kopyası (svchost, chrome sekmeleri, antivirüs alt süreçleri) ayrı satırlarda listelenir. Gruplanmış olsaydı "ürün ailesinin toplam yükünü" görürdünüz, hangi kopyanın sorun çıkardığını değil.')
    if (-not $attr -or @($attr.ByCpu).Count -eq 0) {
        $h += "<div class='card'>Karşılaştırma yapılamadı.</div>"
    } else {
        if ($attr.SlowSampleCount -eq 0) {
            $h += "<div class='warn'><b>Not:</b> Ölçüm boyunca yavaş dönem oluşmadı. Aşağıdaki tablo, normal koşullarda en çok kaynak tüketen process''leri gösterir — bunlar yavaşlığın <i>nedeni</i> değildir.</div>"
        } elseif (-not $attr.Comparable) {
            $h += "<div class='warn'><b>Uyarı:</b> Tüm ölçümler yavaş dönemde geçti. Karşılaştırılacak normal dönem olmadığı için aşağıdaki sıralama <i>nedensellik</i> değil <i>aynı anda çok tüketme</i> gösterir. Makine sakinken tekrar ölçüm alın.</div>"
        }
        $h += @"
<div class='legend'>
<b>Bu tablo nasıl okunur?</b><br>
<b>Yavaşlık anında CPU</b> = makine yavaşken o process'in kullandığı işlemci yüzdesi (Görev Yöneticisi'ndeki gibi, tüm çekirdeklere göre).<br>
<b>Normalde CPU</b> = makine normal çalışırken aynı process'in kullandığı yüzde.<br>
<b>Değişim</b> = ikisi arasındaki fark, cümle olarak. <span class='up'>ARTTI</span> yazıyorsa bu process yavaşlık anında daha çok çalışmıştır ve güçlü adaydır. <span class='flat'>değişmedi</span> yazıyorsa sürekli aynı yükü üretiyordur; muhtemelen suçlu değildir, çünkü makine normalken de aynı yükü üretiyordu ama o zaman yavaşlık yoktu. <span class='down'>AZALDI</span> yazıyorsa yavaşlık anında bu process daha az iş yapabilmiştir — yani o da yavaşlığın <i>kurbanıdır</i>, sebebi değil.<br>
<b>Şüphe skoru</b> = yük × yavaş anlarda görülme oranı × artış katsayısı. Sadece sıralama içindir, mutlak bir anlamı yoktur.
</div>
"@
        $h += (New-HtmlTable -Headers @('Process','PID','Yavaşlık anında CPU %','Normalde CPU %','Değişim','RAM (MB)','Disk işlemi/sn','Disk MB/sn','Tanıtıcı','İş parçacığı','Yavaş ölçümde görüldü','Sağlayıcı','Şüphe skoru') `
                             -Rows @($attr.ByCpu) `
                             -Fields @('Name','Pid','SlowCpuPct','NormCpuPct','CpuDeltaText','PrivateMB','SlowIoOps','IoKBPerSec','Handles','Threads','SamplesSlow','Vendor','Score'))

        $h += '<h3>Diske en çok iş yaptıranlar</h3>'
        $h += @"
<div class='legend'>
Disk yavaşlığının kaynağını bulmak için. <b>Değişim</b> sütunu yine belirleyicidir: <span class='up'>ARTTI</span> yazan process yavaşlık anında diske yüklenmiştir. <span class='down'>AZALDI</span> yazan process ise yavaşlık anında daha az disk işlemi yapabilmiştir — bu, o process'in diski beklediği anlamına gelir, yani <b>kurban</b> olduğunu gösterir. Örneğin "−27 işlem/sn — yavaşlık anında AZALDI" satırı, o programın normalde saniyede 27 işlem daha fazla yaptığı ama yavaşlık sırasında bunu yapamadığı demektir.
</div>
"@
        $h += (New-HtmlTable -Headers @('Process','PID','Yavaşlık anında disk işlemi/sn','Normalde disk işlemi/sn','Değişim','Disk MB/sn','Sağlayıcı','Kategori') `
                             -Rows @($attr.ByIo) -Fields @('Name','Pid','SlowIoOps','NormIoOps','IoDeltaText','IoKBPerSec','Vendor','Category'))

        $h += '<h3>En çok RAM kullananlar</h3>'
        $h += "<div class='legend'>RAM yetersizliği bulgusu varsa buradaki ilk birkaç satır doğrudan sorumludur. Kapatılabilecek veya sınırlandırılabilecek bir program varsa en hızlı kazanç buradadır.</div>"
        $h += (New-HtmlTable -Headers @('Process','PID','RAM (MB)','Yavaşlık anında CPU %','Tanıtıcı','İş parçacığı','Sağlayıcı') `
                             -Rows @($attr.ByMemory) -Fields @('Name','Pid','PrivateMB','SlowCpuPct','Handles','Threads','Vendor'))
    }

    # ------------------------------------------------------- 7. Ajan yükü
    $h += (New-Section '7. Güvenlik ve yönetim ajanlarının yükü' `
        'Domain ortamında bir makinede aynı anda çalışan antivirüs, EDR, DLP, VPN ve envanter ajanlarının toplam maliyetini görmek için. Buradaki amaç ajanları suçlamak değil, "ne kadarına mal oluyor" sorusunu sayıyla cevaplamak ve gerekiyorsa istisna talebine dayanak üretmektir.')
    if ($tax -and $tax.DistinctVendors.Count -gt 0) {
        $h += '<h3>Kategori özeti</h3>'
        $h += (New-HtmlTable -Headers @('Kategori','Process sayısı','Ort. CPU %','Ort. disk işlemi/sn','Ort. RAM (MB)','Sağlayıcılar') `
                             -Rows @($tax.ByCategory) -Fields @('Category','ProcessCount','AvgCpuPct','AvgIoOpsPerSec','AvgPrivateMB','Vendors'))

        $h += '<h3>Tespit edilen ajan process''leri</h3>'
        $h += "<div class='legend'>Her satır tek bir process'tir, kendi ölçülen metrikleriyle birlikte. <b>Değişim</b> sütununda <span class='flat'>değişmedi</span> yazan bir ajan sürekli aynı yükü üretiyor demektir; yavaşlığın tetikleyicisi değildir ama sabit maliyeti vardır.</div>"
        $h += (New-HtmlTable -Headers @('Process','PID','Sağlayıcı','Kategori','CPU %','Değişim','RAM (MB)','Disk işlemi/sn','Disk MB/sn','Tanıtıcı','İş parçacığı','Servis','Yol') `
                             -Rows @($tax.Identified) `
                             -Fields @('Name','Pid','Vendor','Category','CpuPct','CpuDelta','PrivateMB','IoOpsPerSec','IoKBPerSec','Handles','Threads','Services','Path'))
        $h += "<div class='note'><b>Önemli sınır:</b> Bu tablodaki sayılar ajanların <b>doğrudan</b> tükettiğidir. Antivirüs sürücülerinin çekirdek içinde ürettiği gecikme buraya yansımaz — o yük, dosya açmaya çalışan diğer programların bekleme süresine ve yukarıdaki &quot;sürücü yükü&quot; sütununa dağılır. Bu yüzden 7. ve 8. bölümü birlikte okumak gerekir.</div>"
    } else {
        $h += "<div class='card'>Katalogda tanınan güvenlik/yönetim ajanı tespit edilmedi. Bu, makinede ajan olmadığı anlamına gelmeyebilir; tanınmayan bir ürün kullanılıyor olabilir. 6. bölümdeki process listesini gözden geçirin.</div>"
    }

    # -------------------------------------------------- 8. Filtre yığını
    $h += (New-Section '8. Dosya sistemi filtre yığını' `
        'Diskteki her dosya açma, okuma ve yazma işlemi, çalışan bu sürücülerin HEPSİNİN içinden sırayla geçer. Aynı sınıftan (özellikle Anti-Virus) birden fazla filtre varsa aynı dosya birden fazla kez incelenir ve her işlem uzar. Bu, hiçbir process''in CPU''sunda görünmeyen ama makineyi baştan sona yavaşlatan bir maliyettir; &quot;sürücü yükü&quot; ve &quot;disk yanıt süresi&quot; ölçümleri yükselmişse önce buraya bakılır.')
    $mfAll = @($stat.MiniFilters.Registry)
    $mfRun = @($mfAll | Where-Object { $_.Running })
    $avRun = @($mfRun | Where-Object { $_.Group -like '*Anti-Virus*' })
    $h += "<div class='card'>Kayıtlı: <b>$($mfAll.Count)</b> &nbsp;|&nbsp; Çalışıyor: <b>$($mfRun.Count)</b> &nbsp;|&nbsp; Anti-Virus sınıfında çalışan: <b>$($avRun.Count)</b></div>"
    $h += "<div class='legend'>Sınıf bilgisi (<b>Grup</b> sütunu) kayıt defterindeki değerden doğrudan okunur, altitude numarasından tahmin edilmez. <b>Altitude</b> yığındaki sırayı belirler: yüksek olan I/O yolunda önce çalışır. <b>Çalışıyor</b> sütunu False olan filtreler kurulu ama devre dışıdır ve maliyet üretmez.</div>"
    $h += (New-HtmlTable -Headers @('Sürücü','Görünen ad','Grup (sınıf)','Altitude','Çalışıyor','Durum') `
                         -Rows $mfAll -Fields @('Name','DisplayName','Group','Altitude','Running','State'))
    if ($stat.MiniFilters.Fltmc) {
        $h += '<h3>fltmc filters çıktısı (yönetici ile okundu)</h3>'
        $h += "<div class='card'><code>$(ConvertTo-HtmlText (($stat.MiniFilters.Fltmc) -join "`n"))</code></div>"
    }

    # ----------------------------------------------- 9. Depolama ve güç
    $h += (New-Section '9. Depolama ve işlemci gücü' `
        'İki sessiz yavaşlık kaynağı burada yakalanır. Birincisi disk: mekanik disk (HDD) veya %90 üzeri dolu bir SSD, tek başına sistem geneli yavaşlık üretir. İkincisi işlemci güç ayarı: Windows''a işlemciyi tam hızda çalıştırmaması söylenmiş olabilir. İkinci konuda ayar okumasıyla yetinmiyor, işlemcinin yük altında gerçekte hangi hızda çalıştığını ölçüyoruz.')
    $h += (New-HtmlTable -Headers @('Sürücü','Boyut (GB)','Boş (GB)','Boş %','Dosya sistemi') `
                         -Rows @($stat.Storage.Volumes) -Fields @('Drive','SizeGB','FreeGB','FreePct','FileSystem'))
    if (@($stat.Storage.Physical).Count -gt 0) {
        $h += (New-HtmlTable -Headers @('Fiziksel disk','Ortam (SSD/HDD)','Bağlantı','Boyut (GB)','Sağlık') `
                             -Rows @($stat.Storage.Physical) -Fields @('Name','MediaType','BusType','SizeGB','Health'))
    }
    if (@($stat.Storage.PageFiles).Count -gt 0) {
        $h += "<div class='legend'>Takas dosyası: RAM yetmediğinde kullanılan disk alanı. Tepe kullanımı yüksekse RAM yetersizliği geçmişte de yaşanmış demektir.</div>"
        $h += (New-HtmlTable -Headers @('Takas dosyası','Ayrılan (MB)','Kullanılan (MB)','Tepe kullanım (MB)') `
                             -Rows @($stat.Storage.PageFiles) -Fields @('Path','AllocatedMB','CurrentMB','PeakMB'))
    }
    $tmx = $stat.Power.ThrottleMax
    if ($tmx) {
        $acTxt = $(if ($null -ne $tmx.AcMaxPct) { "%$($tmx.AcMaxPct)" } else { 'okunamadı' })
        $dcTxt = $(if ($null -ne $tmx.DcMaxPct) { "%$($tmx.DcMaxPct)" } else { 'okunamadı' })
        $srcTxt = $(if ($tmx.Source) { $tmx.Source } else { 'kaynak belirlenemedi' })
        $h += "<div class='card'>Maksimum işlemci durumu ayarı — prizde: <b>$acTxt</b>, pilde: <b>$dcTxt</b><br><span class='note'>Kaynak: $(ConvertTo-HtmlText $srcTxt). Bu bir <b>ayar okumasıdır</b>; ayarın fiilen uygulanıp uygulanmadığı 10. bölümdeki ölçüm bulgusuyla birlikte değerlendirilmelidir.</span></div>"
    }

    # ------------------------------------------- 10. Açılış / GPO olayları
    if ($stat.Events) {
        $bootD = @($stat.Events.Boot | Where-Object { $_.Id -in 101,102,103,109 } | Select-Object -First 25)
        $gpoS  = @($stat.Events.Gpo | Select-Object -First 20)
        $sysE  = @($stat.Events.System | Select-Object -First 20)
        if ($bootD.Count -gt 0 -or $gpoS.Count -gt 0 -or $sysE.Count -gt 0) {
            $h += (New-Section '10. Açılış, oturum açma ve sistem olayları' `
                'Anlık ölçüm yalnızca çalıştığı dakikaları görür. Bu bölüm Windows''un kendi tuttuğu geçmiş kayıtlara bakar: açılışı geciktiren bileşenler, Grup İlkesi işleme süreleri ve geçmişte yaşanmış kaynak tükenmesi olayları. &quot;Sabah açılış çok uzun sürüyor&quot; şikâyetinin karşılığı buradadır.')
            if ($bootD.Count -gt 0) {
                $h += '<h3>Açılışı geciktiren bileşenler</h3>'
                $h += "<div class='legend'>Windows bu olaylarda yavaşlatan uygulamayı adıyla ve milisaniye cinsinden süreyle kaydeder. Doğrudan eyleme dönüştürülebilir.</div>"
                $h += (New-HtmlTable -Headers @('Zaman','Olay no','Açıklama') -Rows $bootD -Fields @('Time','Id','Message'))
            }
            if ($gpoS.Count -gt 0) {
                $h += '<h3>Grup İlkesi işleme</h3>'
                $h += "<div class='legend'>Oturum açma sırasında hangi ilke bileşeninin ne kadar sürdüğü. Uzun süreler, oturum açmanın neden beklettiğini açıklar.</div>"
                $h += (New-HtmlTable -Headers @('Zaman','Olay no','Açıklama') -Rows $gpoS -Fields @('Time','Id','Message'))
            }
            if ($sysE.Count -gt 0) {
                $h += '<h3>Sistem olayları</h3>'
                $h += "<div class='legend'>Kaynak tükenmesi (olay 2004), disk hataları (153, 157) ve beklenmedik kapanmalar. Bunlar geçmişte yaşanmış somut arızalardır.</div>"
                $h += (New-HtmlTable -Headers @('Zaman','Olay no','Kaynak','Açıklama') -Rows $sysE -Fields @('Time','Id','Provider','Message'))
            }
        }
    }

    # --------------------------------------------------------- 11. Bulgular
    $h += (New-Section '11. Bulguların tamamı, kanıtlarıyla' `
        'Her bulgunun altında hangi ölçüme dayandığı yazar. Bir bulguya katılmıyorsanız kanıt satırına bakın; oradaki sayı yanlışsa bulgu da yanlıştır. Değerlendirme satırı, sayının ne anlama geldiğini ve hangi alternatif açıklamaların mümkün olduğunu anlatır.')
    foreach ($f in $ranked) {
        $h += "<div class='card'><h3><span class='sev sev-$($f.Severity)'>$($f.Severity.ToUpper())</span>$(ConvertTo-HtmlText $f.Title)</h3>"
        if (@($f.Evidence).Count -gt 0) {
            $h += '<b>Ölçülen</b><ul>'
            foreach ($e in @($f.Evidence)) { $h += "<li><code>$(ConvertTo-HtmlText $e)</code></li>" }
            $h += '</ul>'
        }
        if ($f.Note) { $h += "<div class='note'><b>Ne anlama geliyor:</b> $(ConvertTo-HtmlText $f.Note)</div>" }
        $h += '</div>'
    }

    $h += "<footer>WinPerfDiag — tüm veri yerelde kalır, hiçbir yere gönderilmez. Üretim zamanı: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')</footer>"
    $h += '</body></html>'
    return ($h -join "`n")
}

function Write-ConsoleSummary {
    # Eski konsol kod sayfasinda Turkce karakterler bozulabilir. Denenir,
    # basarisiz olursa sorun degil: tam rapor zaten HTML'dedir.
    try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch { }
    param($Run)
    $tax = $Run.AgentTax
    Write-Info ''
    Write-Info '=============================================================' 'DarkGray'
    Write-Info " OZET - $($Run.Capabilities.ComputerName)" 'White'
    Write-Info '=============================================================' 'DarkGray'
    $order = @{ kritik = 0; yuksek = 1; orta = 2; bilgi = 3 }
    foreach ($f in @($Run.Findings | Sort-Object { $order[$_.Severity] }) | Where-Object { $_.Severity -ne 'bilgi' } | Select-Object -First 8) {
        $col = 'Yellow'
        if ($f.Severity -eq 'kritik') { $col = 'Red' }
        elseif ($f.Severity -eq 'orta') { $col = 'DarkYellow' }
        Write-Info ("  [{0}] {1}" -f $f.Severity.ToUpper(), $f.Title) $col
    }
    if ($tax -and $tax.DistinctVendors.Count -gt 0) {
        Write-Info ''
        Write-Info ("  Guvenlik/yonetim saglayicisi : {0}" -f ($tax.DistinctVendors -join ', ')) 'Cyan'
        Write-Info ("  Ajanlarin CPU payi           : %{0}" -f $tax.CpuSharePct) 'Cyan'
        Write-Info ("  Ajanlarin disk islemi payi   : %{0}" -f $tax.IoSharePct) 'Cyan'
    }
    Write-Info ''
}

#endregion

#region ------------------------------------------------------ Mod yurutucusu

function New-RunObject {
    param($Caps, $Static, $SampleList, $Enrichment)
    $memMB = ConvertTo-Num $Caps.TotalMemoryMB 0
    $scores = @()
    foreach ($s in @($SampleList)) { $scores += Get-SampleScore -Sample $s -Ncpu $Caps.LogicalCpu -TotalMemMB $memMB }
    $windows = Get-SlowWindows -Scores $scores
    $attr = Get-Attribution -SampleList $SampleList -Scores $scores -Enrichment $Enrichment -TopN $TopN
    $tax  = Get-AgentTax -SampleList $SampleList -Enrichment $Enrichment -Attribution $attr
    $find = Get-Findings -Caps $Caps -Static $Static -SampleList $SampleList -Scores $scores -Windows $windows -Attribution $attr -AgentTax $tax

    [pscustomobject]@{
        Tool         = 'WinPerfDiag'
        Version      = '1.0.0'
        StartedAt    = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
        Mode         = $Mode
        Capabilities = $Caps
        Static       = $Static
        Samples      = @($SampleList)
        Scores       = @($scores)
        SlowWindows  = @($windows)
        Attribution  = $attr
        AgentTax     = $tax
        Findings     = @($find)
        Gaps         = @($script:Warnings)
    }
}

function Resolve-DataPath {
    # LOCALAPPDATA tanimsizsa (nadir; kisitli servis hesaplari) calisma dizinine dus.
    $dp = $DataPath
    if ([string]::IsNullOrWhiteSpace($dp) -or $dp.StartsWith('\')) {
        $dp = Join-Path (Get-Location).Path 'WinPerfDiag'
    }
    if (-not (Test-Path $dp)) { $null = New-Item -ItemType Directory -Path $dp -Force }
    return $dp
}

function Save-Run {
    param($Run)
    $DataPath = Resolve-DataPath
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $base = if ($OutFile) { $OutFile -replace '\.(html?|json)$', '' } else { Join-Path $DataPath "winperfdiag-$stamp" }
    $written = @()

    if ($Format -in 'Json', 'Both') {
        $jsonPath = "$base.json"
        $Run | ConvertTo-Json -Depth 8 | Out-File -FilePath $jsonPath -Encoding UTF8
        $written += $jsonPath
    }
    if ($Format -in 'Html', 'Both') {
        $htmlPath = "$base.html"
        New-HtmlReport -Run $Run | Out-File -FilePath $htmlPath -Encoding UTF8
        $written += $htmlPath
    }
    return $written
}

function Invoke-Check {
    $caps = Get-Capabilities
    Write-Info ''
    Write-Info " Bilgisayar   : $($caps.ComputerName)" 'White'
    Write-Info " Kullanici    : $($caps.UserName)"
    Write-Info " Yetki        : $(if ($caps.Elevated) { 'YONETICI' } else { 'standart kullanici' })"
    Write-Info " Domain       : $(if ($caps.DomainJoined) { $caps.Domain } else { 'dahil degil' })"
    Write-Info " Isletim sis. : $($caps.OsCaption) build $($caps.OsBuild)"
    Write-Info " Islemci      : $($caps.CpuName) ($($caps.LogicalCpu) mantiksal cekirdek)"
    Write-Info " RAM          : $($caps.TotalMemoryMB) MB"
    Write-Info " PowerShell   : $($caps.PsVersion), dil modu: $($caps.LanguageMode)"
    Write-Info ''
    Write-Info ' Olcum kaynaklari:' 'White'
    foreach ($k in @($caps.Probe.Keys | Sort-Object)) {
        $ok = [bool]$caps.Probe[$k]
        Write-Info ("   [{0}] {1}" -f $(if ($ok) { 'x' } else { ' ' }), $k) $(if ($ok) { 'Green' } else { 'DarkGray' })
    }
    if ($caps.LanguageMode -ne 'FullLanguage') {
        Write-Info ''
        Write-Info " ! Dil modu $($caps.LanguageMode). Bazi olcumler kisitlanabilir." 'Yellow'
    }
    if (@($script:Warnings).Count -gt 0) {
        Write-Info ''
        Write-Info ' Erisilemeyenler:' 'Yellow'
        foreach ($w in @($script:Warnings | Group-Object Source)) {
            Write-Info ("   - {0}: {1}" -f $w.Name, $w.Group[0].Reason) 'DarkGray'
        }
    }
    Write-Info ''
}

function Invoke-Diag {
    Write-Info 'WinPerfDiag - tek seferlik teshis' 'White'
    Write-Info '[1/4] Yetenek tespiti...'
    $caps = Get-Capabilities
    Write-Info ("      {0} / {1} cekirdek / {2} MB RAM / {3}" -f $caps.ComputerName, $caps.LogicalCpu, $caps.TotalMemoryMB, $(if ($caps.Elevated) { 'yonetici' } else { 'standart kullanici' }))

    Write-Info '[2/4] Statik envanter...'
    $static = Get-StaticInventory -Caps $caps

    Write-Info ("[3/4] {0} ornek aliniyor (aralik {1} sn, tahmini {2} sn)..." -f $SampleCount, $Interval, [int]($SampleCount * $Interval))
    $cb = {
        param($s, $i)
        $m = $s.Metrics
        Write-Info ("      ornek {0}/{1}  CPU %{2}  DPC %{3}  bos {4} MB  disk R/W {5}/{6} ms" -f `
            $i, $SampleCount, $m.CpuTotalPct, $m.CpuDpcPct, $m.AvailableMB, $m.DiskReadMs, $m.DiskWriteMs)
    }
    $samples = Invoke-SamplingLoop -Count $SampleCount -IntervalSec $Interval -Ncpu $caps.LogicalCpu -OnSample $cb

    Write-Info '[4/4] Zenginlestirme, analiz ve rapor...'
    $enrich = Get-ProcessEnrichment -Services $static.Services
    $run = New-RunObject -Caps $caps -Static $static -SampleList $samples -Enrichment $enrich
    $files = Save-Run -Run $run
    Write-ConsoleSummary -Run $run
    foreach ($fp in $files) { Write-Info " Rapor: $fp" 'Green' }
    return $run
}

function Invoke-Monitor {
    Write-Info 'WinPerfDiag - surekli izleme (durdurmak icin Ctrl-C)' 'White'
    $caps = Get-Capabilities
    $static = Get-StaticInventory -Caps $caps
    $dp = Resolve-DataPath
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $jsonl = Join-Path $dp "monitor-$stamp.jsonl"
    Write-Info " Ham ornekler: $jsonl"

    # Monitor modunda -SampleCount / -Samples acikca verilmediyse SINIRSIZ
    # calis: "surekli izleme"nin 12 ornekte durmasi beklenmez.
    $limit = 0
    if ($PSBoundParameters.ContainsKey('SampleCount') -or $PSBoundParameters.ContainsKey('Samples')) {
        $limit = $SampleCount
    }
    if ($limit -eq 0 -and $Duration -eq 0) {
        Write-Info ' Sinirsiz izleme: durdurmak icin Ctrl-C (rapor yine de uretilir).' 'Yellow'
    }

    $samples = @()
    $cb = {
        param($s, $i)
        $m = $s.Metrics
        $line = $s | ConvertTo-Json -Depth 5 -Compress
        Add-Content -Path $jsonl -Value $line -Encoding UTF8
        Write-Info ("{0}  CPU %{1}  DPC %{2}  kuyruk {3}  bos {4} MB  disk {5}/{6} ms" -f `
            $m.Ts.ToString('HH:mm:ss'), $m.CpuTotalPct, $m.CpuDpcPct, $m.ProcessorQueueLength, $m.AvailableMB, $m.DiskReadMs, $m.DiskWriteMs)
    }

    try {
        $samples = Invoke-SamplingLoop -Count $limit -IntervalSec $Interval -Ncpu $caps.LogicalCpu `
                                       -OnSample $cb -DurationSec $Duration
    } finally {
        Write-Info ''
        Write-Info (" {0} ornek kaydedildi. Analiz ediliyor..." -f @($samples).Count)
        if (@($samples).Count -gt 0) {
            $enrich = Get-ProcessEnrichment -Services $static.Services
            $run = New-RunObject -Caps $caps -Static $static -SampleList $samples -Enrichment $enrich
            $files = Save-Run -Run $run
            Write-ConsoleSummary -Run $run
            foreach ($fp in $files) { Write-Info " Rapor: $fp" 'Green' }
        }
    }
}

function Invoke-ReportFromFile {
    if (-not $InputFile -or -not (Test-Path $InputFile)) {
        Write-Info ' -InputFile ile bir .json kosum dosyasi belirtin.' 'Red'
        return
    }
    $run = Get-Content -Path $InputFile -Raw -Encoding UTF8 | ConvertFrom-Json
    $htmlPath = if ($OutFile) { $OutFile } else { ($InputFile -replace '\.json$', '') + '.html' }
    New-HtmlReport -Run $run | Out-File -FilePath $htmlPath -Encoding UTF8
    Write-Info " Rapor: $htmlPath" 'Green'
}

#endregion

switch ($Mode) {
    'Check'   { Invoke-Check }
    'Diag'    { $null = Invoke-Diag }
    'Monitor' { Invoke-Monitor }
    'Report'  { Invoke-ReportFromFile }
}
