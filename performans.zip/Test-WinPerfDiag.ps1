# Sentetik dogrulama. Gercek Windows sayaclari olmadan, sayisal mantigi ve
# atif motorunu bilinen girdilerle sinar.

. "$PSScriptRoot/WinPerfDiag.ps1" -Mode Report 2>$null | Out-Null

$fail = 0
function Check {
    param([string]$Name, [bool]$Ok, [string]$Detail)
    if ($Ok) { Write-Host ("  [GECTI] {0}" -f $Name) -ForegroundColor Green }
    else { Write-Host ("  [KALDI] {0} -- {1}" -f $Name, $Detail) -ForegroundColor Red; $script:fail++ }
}

Write-Host "`n== 1. Sayac matematigi ==" -ForegroundColor Cyan

# PERF_AVERAGE_TIMER: 1000 okuma toplam 8 saniye surmus, frekans 10 MHz
# beklenen ortalama = 8 ms
$ms = Get-AvgTimerMs -N1 80000000 -N0 0 -B1 1000 -B0 0 -Frequency 10000000
Check 'Disk gecikmesi (PERF_AVERAGE_TIMER) = 8 ms' ([math]::Abs($ms - 8) -lt 0.001) "hesaplanan: $ms"

# Bolen sifir -> null (0 degil). Sifir islemde "0 ms gecikme" demek yanlis olur.
$msNull = Get-AvgTimerMs -N1 5 -N0 5 -B1 10 -B0 10 -Frequency 10000000
Check 'Sifir islemde null doner (yanlis 0 degil)' ($null -eq $msNull) "hesaplanan: $msNull"

# PERF_100NSEC_TIMER: 10 sn pencerede 2 sn CPU = %20 (tek cekirdek olcegi)
$pct = Get-Pct100Ns -Current 20000000 -Previous 0 -TsCurrent 100000000 -TsPrevious 0
Check 'CPU yuzdesi (PERF_100NSEC_TIMER) = %20' ([math]::Abs($pct - 20) -lt 0.001) "hesaplanan: $pct"

# Sayac sarmasi (negatif delta) -> 0, negatif hiz uretilmemeli
$rate = Get-Rate -Current 5 -Previous 100 -DeltaSec 5
Check 'Sayac sarmasinda negatif hiz uretilmez' ($rate -eq 0) "hesaplanan: $rate"

Write-Host "`n== 2. Ham anlik goruntuden ornek turetme ==" -ForegroundColor Cyan

function New-FakeRaw {
    param([datetime]$Ts, [double]$Sec, [double]$CpuUtil, [double]$DpcUtil,
          [int]$Ncpu, [double]$HogCpuSec, [double]$AgentCpuSec, [int]$DiskOps, [double]$DiskTotalSec,
          [double]$CpuPerfPct = 100, [int]$FreqMHz = 2800, [int]$ExplorerIo = 40)
    $t100 = [long]($Sec * 1e7)
    [pscustomobject]@{
        Ts = $Ts
        Cpu = [pscustomobject]@{
            Timestamp_Sys100NS   = $t100
            PercentIdleTime      = [long]($Ncpu * $Sec * (1 - $CpuUtil) * 1e7)
            PercentDPCTime       = [long]($Ncpu * $Sec * $DpcUtil * 1e7)
            PercentInterruptTime = 0
            PercentPrivilegedTime= 0
        }
        Sys = [pscustomobject]@{
            ProcessorQueueLength  = 12
            ContextSwitchesPersec = [long]($Sec * 40000)
            SystemCallsPersec     = [long]($Sec * 90000)
        }
        Mem = [pscustomobject]@{
            AvailableMBytes   = 900
            PagesInputPersec  = [long]($Sec * 300)
            PageFaultsPersec  = [long]($Sec * 9000)
            CommittedBytes    = 15GB
            CommitLimit       = 16GB
            PoolNonpagedBytes = 700MB
            PoolPagedBytes    = 500MB
        }
        Perf = [pscustomobject]@{
            PercentProcessorPerformance = $CpuPerfPct
            ProcessorFrequency          = $FreqMHz
        }
        Disk = [pscustomobject]@{
            Frequency_PerfTime         = 10000000
            AvgDisksecPerRead          = [long]($DiskTotalSec * 10000000)
            AvgDisksecPerRead_Base     = $DiskOps
            AvgDisksecPerWrite         = 0
            AvgDisksecPerWrite_Base    = 0
            CurrentDiskQueueLength     = 6
            DiskReadsPersec            = [long]($Sec * 500)
            DiskWritesPersec           = [long]($Sec * 200)
        }
        Proc = @(
            [pscustomobject]@{ IDProcess=1001; Name='hog_app'; Timestamp_Sys100NS=$t100
                PercentProcessorTime=[long]($HogCpuSec*1e7); PrivateBytes=4GB; WorkingSetPrivate=3GB
                HandleCount=900; ThreadCount=40; IOReadOperationsPersec=[long]($Sec*50)
                IOWriteOperationsPersec=[long]($Sec*20); IOReadBytesPersec=[long]($Sec*1MB)
                IOWriteBytesPersec=0; PageFaultsPersec=[long]($Sec*100) }
            [pscustomobject]@{ IDProcess=2002; Name='CSFalconService'; Timestamp_Sys100NS=$t100
                PercentProcessorTime=[long]($AgentCpuSec*1e7); PrivateBytes=300MB; WorkingSetPrivate=250MB
                HandleCount=1200; ThreadCount=60; IOReadOperationsPersec=[long]($Sec*4000)
                IOWriteOperationsPersec=[long]($Sec*500); IOReadBytesPersec=[long]($Sec*8MB)
                IOWriteBytesPersec=0; PageFaultsPersec=[long]($Sec*50) }
            [pscustomobject]@{ IDProcess=5001; Name='svchost'; Timestamp_Sys100NS=$t100
                PercentProcessorTime=[long]($Sec*0.02*1e7); PrivateBytes=60MB; WorkingSetPrivate=50MB
                HandleCount=300; ThreadCount=10; IOReadOperationsPersec=[long]($Sec*5)
                IOWriteOperationsPersec=0; IOReadBytesPersec=0
                IOWriteBytesPersec=0; PageFaultsPersec=0 }
            [pscustomobject]@{ IDProcess=5002; Name='svchost'; Timestamp_Sys100NS=$t100
                PercentProcessorTime=[long]($Sec*0.2*1e7); PrivateBytes=700MB; WorkingSetPrivate=650MB
                HandleCount=1500; ThreadCount=55; IOReadOperationsPersec=[long]($Sec*900)
                IOWriteOperationsPersec=0; IOReadBytesPersec=0
                IOWriteBytesPersec=0; PageFaultsPersec=0 }
            [pscustomobject]@{ IDProcess=3003; Name='explorer'; Timestamp_Sys100NS=$t100
                PercentProcessorTime=[long]($Sec*0.08*1e7); PrivateBytes=200MB; WorkingSetPrivate=180MB
                HandleCount=2000; ThreadCount=80; IOReadOperationsPersec=[long]($Sec*$ExplorerIo)
                IOWriteOperationsPersec=0; IOReadBytesPersec=0
                IOWriteBytesPersec=0; PageFaultsPersec=[long]($Sec*20) }
        )
    }
}

$ncpu = 8
$t0 = Get-Date
# Pencere: 5 sn. CPU %90 dolu, DPC %8. hog 3.2 sn CPU yemis (8 cekirdekte %8).
$prev = New-FakeRaw -Ts $t0 -Sec 0 -CpuUtil 0 -DpcUtil 0 -Ncpu $ncpu -HogCpuSec 0 -AgentCpuSec 0 -DiskOps 0 -DiskTotalSec 0
$cur  = New-FakeRaw -Ts $t0.AddSeconds(5) -Sec 5 -CpuUtil 0.90 -DpcUtil 0.08 -Ncpu $ncpu `
                    -HogCpuSec 3.2 -AgentCpuSec 0.4 -DiskOps 1000 -DiskTotalSec 8
$s = ConvertTo-Sample -Cur $cur -Prev $prev -Ncpu $ncpu

Check 'CpuTotalPct = 90' ([math]::Abs($s.Metrics.CpuTotalPct - 90) -lt 0.01) "hesaplanan: $($s.Metrics.CpuTotalPct)"
Check 'CpuDpcPct = 8'    ([math]::Abs($s.Metrics.CpuDpcPct - 8) -lt 0.01)    "hesaplanan: $($s.Metrics.CpuDpcPct)"
Check 'DiskReadMs = 8'   ([math]::Abs($s.Metrics.DiskReadMs - 8) -lt 0.01)   "hesaplanan: $($s.Metrics.DiskReadMs)"
Check 'HardFaultsPerSec = 300' ($s.Metrics.HardFaultsPerSec -eq 300) "hesaplanan: $($s.Metrics.HardFaultsPerSec)"
Check 'CommitPct ~ 93.75' ([math]::Abs($s.Metrics.CommitPct - 93.75) -lt 0.1) "hesaplanan: $($s.Metrics.CommitPct)"

# hog: 5 sn pencerede 3.2 sn CPU = tek cekirdek olceginde %64; 8 cekirdekte %8
$hog = @($s.Processes | Where-Object { $_.Name -eq 'hog_app' })[0]
Check 'Process CPU cekirdek sayisina bolunmus (hog = %8)' ([math]::Abs($hog.CpuPct - 8) -lt 0.01) "hesaplanan: $($hog.CpuPct)"
Check 'Process ozel bellek MB dogru (4096)' ($hog.PrivateMB -eq 4096) "hesaplanan: $($hog.PrivateMB)"
$agent = @($s.Processes | Where-Object { $_.Name -eq 'CSFalconService' })[0]
Check 'Ajan disk islemi/sn dogru (4000)' ($agent.IoReadOpsPerSec -eq 4000) "hesaplanan: $($agent.IoReadOpsPerSec)"

Write-Host "`n== 3. Ajan katalogu ==" -ForegroundColor Cyan
$r1 = Resolve-Agent -Name 'CSFalconService' -Company $null
Check 'CSFalconService -> CrowdStrike / EDR' ($r1 -and $r1.Vendor -eq 'CrowdStrike Falcon' -and $r1.Category -eq 'EDR') "sonuc: $($r1 | ConvertTo-Json -Compress)"
$r2 = Resolve-Agent -Name 'MsMpEng' -Company $null
Check 'MsMpEng -> Microsoft Defender / AV' ($r2 -and $r2.Category -eq 'AV') "sonuc: $($r2 | ConvertTo-Json -Compress)"
$r3 = Resolve-Agent -Name 'bilinmeyen' -Company 'Netskope Inc.'
Check 'Bilinmeyen process, imzadan cozulur' ($r3 -and $r3.Vendor -eq 'Netskope' -and $r3.Source -eq 'imza') "sonuc: $($r3 | ConvertTo-Json -Compress)"
$r4 = Resolve-Agent -Name 'notepad' -Company 'Microsoft Corporation'
Check 'Sivil process ajan olarak etiketlenmez' ($null -eq $r4) "sonuc: $r4"

Write-Host "`n== 4. Yavas pencere + atif ==" -ForegroundColor Cyan

# 12 ornek. 5-9 arasi yavas. hog SADECE yavas anlarda ziplar.
# CSFalconService her zaman sabit yuk uretir -> suclu olmamali.
$sampleList = @()
for ($i = 0; $i -lt 12; $i++) {
    $slow = ($i -ge 4 -and $i -le 8)
    $p = New-FakeRaw -Ts $t0.AddSeconds($i * 5) -Sec 0 -CpuUtil 0 -DpcUtil 0 -Ncpu $ncpu `
                     -HogCpuSec 0 -AgentCpuSec 0 -DiskOps 0 -DiskTotalSec 0
    $c = New-FakeRaw -Ts $t0.AddSeconds($i * 5 + 5) -Sec 5 `
                     -CpuUtil $(if ($slow) { 0.95 } else { 0.15 }) `
                     -DpcUtil $(if ($slow) { 0.10 } else { 0.005 }) -Ncpu $ncpu `
                     -HogCpuSec $(if ($slow) { 3.6 } else { 0.05 }) `
                     -AgentCpuSec 0.4 `
                     -DiskOps 1000 -DiskTotalSec $(if ($slow) { 35 } else { 1.5 }) `
                     -CpuPerfPct $(if ($slow) { 65 } else { 38 }) `
                     -FreqMHz $(if ($slow) { 1820 } else { 1060 }) `
                     -ExplorerIo $(if ($slow) { 13 } else { 40 })
    $c.Mem.AvailableMBytes = $(if ($slow) { 500 } else { 7000 })
    $c.Sys.ProcessorQueueLength = $(if ($slow) { 28 } else { 1 })
    $c.Disk.CurrentDiskQueueLength = $(if ($slow) { 9 } else { 0 })
    $smp = ConvertTo-Sample -Cur $c -Prev $p -Ncpu $ncpu
    $sampleList += $smp
}

$caps = [pscustomobject]@{
    ComputerName='TESTPC'; UserName='DOM\test'; Elevated=$false; LogicalCpu=$ncpu
    TotalMemoryMB=16384; OsCaption='Windows 11'; OsVersion='10.0.22631'; OsBuild='22631'
    CpuName='Test CPU'; Model='Test'; DomainJoined=$true; Domain='dom.local'
    PsVersion='5.1'; LanguageMode='FullLanguage'; LastBootUpTime=$t0
    Probe=@{ PerfProc=$true; PerfDisk=$true; PerfOS=$true; PerfCpu=$true; Services=$true
             SysDriver=$true; Registry=$true; SchedTask=$true; EventSystem=$true
             EventBoot=$false; EventGpo=$false; Fltmc=$false; Defender=$false; PhysDisk=$true }
}

$static = [pscustomobject]@{
    MiniFilters = [pscustomobject]@{
        Registry = @(
            [pscustomobject]@{ Name='CSAgent'; DisplayName='CrowdStrike'; Group='FSFilter Anti-Virus'; Altitude='321410'; Running=$true; State='Running'; StartType=0; ImagePath='' }
            [pscustomobject]@{ Name='WdFilter'; DisplayName='Defender'; Group='FSFilter Anti-Virus'; Altitude='328010'; Running=$true; State='Running'; StartType=0; ImagePath='' }
            [pscustomobject]@{ Name='SentinelMonitor'; DisplayName='SentinelOne'; Group='FSFilter Anti-Virus'; Altitude='329010'; Running=$true; State='Running'; StartType=0; ImagePath='' }
            [pscustomobject]@{ Name='DgFilter'; DisplayName='Digital Guardian'; Group='FSFilter Activity Monitor'; Altitude='365000'; Running=$true; State='Running'; StartType=0; ImagePath='' }
            [pscustomobject]@{ Name='luafv'; DisplayName='UAC'; Group='FSFilter Virtualization'; Altitude='135000'; Running=$true; State='Running'; StartType=0; ImagePath='' }
            [pscustomobject]@{ Name='EskiFiltre'; DisplayName='Kapali'; Group='FSFilter Anti-Virus'; Altitude='320000'; Running=$false; State='Stopped'; StartType=4; ImagePath='' }
        )
        Fltmc=$null; DriverState=@{}
    }
    Services = @()
    Startup  = [pscustomobject]@{ RunEntries=@(); Tasks=@() }
    Power    = [pscustomobject]@{
        ActiveScheme='Dengeli'
        ThrottleMax=[pscustomobject]@{ AcMaxPct=70; DcMaxPct=50 }
        Clock=[pscustomobject]@{ CurrentMHz=1200; MaxMHz=2800 }
    }
    Storage  = [pscustomobject]@{
        Volumes=@([pscustomobject]@{ Drive='C:'; SizeGB=475.0; FreeGB=22.0; FreePct=4.6; FileSystem='NTFS' })
        Physical=@([pscustomobject]@{ Name='Test HDD'; MediaType='HDD'; BusType='SATA'; SizeGB=500.0; Health='Healthy' })
        PageFiles=@()
    }
    Posture  = [pscustomobject]@{
        DeviceGuard=[pscustomobject]@{ EnableVirtualizationBasedSecurity=1; HvciEnabled=1; RequirePlatformSecurityFeatures=1 }
        Defender=$null; AvProducts=@()
    }
    Events   = [pscustomobject]@{
        Boot=@(); Gpo=@()
        System=@([pscustomobject]@{ Time=$t0; Id=2004; Provider='Resource-Exhaustion-Detector'; Message='Windows sanal bellegi tukendigi icin islem sonlandirildi.' })
    }
}

$enrich = @{
    1001 = [pscustomobject]@{ Path='C:\app\hog.exe'; Company='Test'; Description=''; Services=@(); Vendor=$null; Category=$null; AgentSource=$null }
    2002 = [pscustomobject]@{ Path='C:\Program Files\CrowdStrike\CSFalconService.exe'; Company='CrowdStrike'; Description=''; Services=@('CSFalconService'); Vendor='CrowdStrike Falcon'; Category='EDR'; AgentSource='katalog' }
    3003 = [pscustomobject]@{ Path='C:\Windows\explorer.exe'; Company='Microsoft'; Description=''; Services=@(); Vendor=$null; Category=$null; AgentSource=$null }
}

$TopN = 15
$run = New-RunObject -Caps $caps -Static $static -SampleList $sampleList -Enrichment $enrich

$slowCount = @($run.Scores | Where-Object { $_.Score -ge $script:SlowThreshold }).Count
Check 'Tam 5 yavas ornek tespit edildi' ($slowCount -eq 5) "tespit: $slowCount, skorlar: $(@($run.Scores | ForEach-Object { $_.Score }) -join ',')"
Check 'Tek bir kesintisiz yavas pencere' (@($run.SlowWindows).Count -eq 1) "pencere: $(@($run.SlowWindows).Count)"

$top = @($run.Attribution.ByCpu)
Check 'Gercek suclu (hog_app) birinci sirada' ($top[0].Name -eq 'hog_app') "birinci: $($top[0].Name)"
Check 'Sabit yuklu EDR ajani suclu olarak siralanmadi' ($top[0].Name -ne 'CSFalconService') "birinci: $($top[0].Name)"
$fal = @($top | Where-Object { $_.Name -eq 'CSFalconService' })[0]
Check 'Ajanin CPU farki ~0 olarak raporlandi' ([math]::Abs($fal.CpuDelta) -lt 0.01) "fark: $($fal.CpuDelta)"
Check 'Ajan, disk islemi siralamasinda one cikti' (@($run.Attribution.ByIo)[0].Name -eq 'CSFalconService') "birinci: $(@($run.Attribution.ByIo)[0].Name)"

# --- GRUPLAMA OLMAMALI: ayni calistirilabilirin iki kopyasi ayri satir ---
$svc = @($run.Attribution.All | Where-Object { $_.Name -eq 'svchost' })
Check 'Ayni exe''nin iki kopyasi AYRI satirda (gruplanmiyor)' ($svc.Count -eq 2) "satir sayisi: $($svc.Count)"
$pids = @($svc | ForEach-Object { $_.Pid } | Sort-Object)
Check 'Her satir kendi PID''ini tasiyor' (($pids -join ',') -eq '5001,5002') "PID'ler: $($pids -join ',')"
$busySvc = @($svc | Where-Object { $_.Pid -eq 5002 })[0]
$idleSvc = @($svc | Where-Object { $_.Pid -eq 5001 })[0]
Check 'Yuklu kopya ile bos kopya farkli metrik gosteriyor' ($busySvc.SlowCpuPct -gt $idleSvc.SlowCpuPct + 1) "5002=$($busySvc.SlowCpuPct) 5001=$($idleSvc.SlowCpuPct)"
Check 'Tek satirda birden fazla PID alani YOK' ($null -eq ($top[0].PSObject.Properties['Pids'])) 'Pids alani hala var'

# --- FARK SUTUNU INSAN DILINDE ---
$exp = @($run.Attribution.All | Where-Object { $_.Name -eq 'explorer' })[0]
Check 'Disk islemi azalan process icin "AZALDI" yaziyor' ($exp.IoDeltaText -like '*AZALDI*') "metin: $($exp.IoDeltaText)"
$hogRow = @($run.Attribution.All | Where-Object { $_.Name -eq 'hog_app' })[0]
Check 'CPU artan process icin "ARTTI" yaziyor' ($hogRow.CpuDeltaText -like '*ARTTI*') "metin: $($hogRow.CpuDeltaText)"
Check 'Degismeyen process icin "degismedi" yaziyor' ($fal.CpuDeltaText -like '*değişmedi*') "metin: $($fal.CpuDeltaText)"
Check 'Fark metni ciplak sayi degil, cumle' ($exp.IoDeltaText.Length -gt 10) "metin: $($exp.IoDeltaText)"

Write-Host "`n== 5. Ajan vergisi ==" -ForegroundColor Cyan
$tax = $run.AgentTax
Check 'CrowdStrike saglayici olarak tespit edildi' ($tax.DistinctVendors -contains 'CrowdStrike Falcon') "saglayicilar: $($tax.DistinctVendors -join ',')"
Check 'Ajanin disk islemi payi hesaplandi (>%70)' ($tax.IoSharePct -gt 70) "pay: $($tax.IoSharePct)"
Check 'EDR kategorisi raporlandi' (@($tax.ByCategory | Where-Object { $_.Category -eq 'EDR' }).Count -eq 1) "kategoriler: $(@($tax.ByCategory | ForEach-Object { $_.Category }) -join ',')"
$ident = @($tax.Identified)
Check 'Ajan listesi PID bazli' ($ident.Count -ge 1 -and $ident[0].Pid -gt 0) "adet: $($ident.Count)"
$c0 = $ident[0]
$hasMetrics = ($null -ne $c0.CpuPct) -and ($null -ne $c0.PrivateMB) -and ($null -ne $c0.IoOpsPerSec) -and ($null -ne $c0.Handles) -and ($null -ne $c0.Threads)
Check 'Ajan listesinde performans metrikleri VAR' $hasMetrics "CPU=$($c0.CpuPct) RAM=$($c0.PrivateMB) IO=$($c0.IoOpsPerSec) H=$($c0.Handles) T=$($c0.Threads)"
Check 'Ajan metrikleri gercek degerlerle dolu' ($c0.IoOpsPerSec -gt 100 -and $c0.PrivateMB -gt 0) "IO=$($c0.IoOpsPerSec) RAM=$($c0.PrivateMB)"

Write-Host "`n== 6. Bulgular ==" -ForegroundColor Cyan
$titles = @($run.Findings | ForEach-Object { $_.Title })
Check 'Guc plani ayari KAYIT olarak raporlandi' (@($titles | Where-Object { $_ -like '*maksimum islemci durumu*' -or $_ -like '*Maksimum işlemci durumu*' }).Count -ge 1) "basliklar: $($titles -join ' | ')"
Check 'Yuk altinda olculen hiz dususu bulgusu uretildi' (@($titles | Where-Object { $_ -like '*yük altındayken*' }).Count -ge 1) "basliklar: $($titles -join ' | ')"
$pf = @($run.Findings | Where-Object { $_.Title -like '*yük altındayken*' })[0]
Check 'Hiz bulgusu OLCUME dayandigini soyluyor' ($pf.Note -like '*ÖLÇÜMDÜR*') "not: $($pf.Note)"
Check 'Hiz bulgusu alternatif nedenleri sayiyor (termal/firmware)' ($pf.Note -like '*termal*' -and $pf.Note -like '*firmware*') "not: $($pf.Note)"
Check 'AV sinifi filtre yigini bulgusu uretildi' (@($titles | Where-Object { $_ -like '*filtre surucusu*' }).Count -ge 1) "basliklar: $($titles -join ' | ')"
Check 'Calisan filtre sayilirken durdurulmus olan haric tutuldu' (@($titles | Where-Object { $_ -like '*5 adet*3 tanesi*' }).Count -ge 1) "basliklar: $($titles -join ' | ')"
Check 'Kaynak tukenmesi (2004) bulgusu uretildi' (@($titles | Where-Object { $_ -like '*2004*' }).Count -ge 1) "basliklar: $($titles -join ' | ')"
Check 'HDD bulgusu uretildi' (@($titles | Where-Object { $_ -like '*mekanik disk*' }).Count -ge 1) "basliklar: $($titles -join ' | ')"
Check 'DPC/kesme bulgusu uretildi' (@($titles | Where-Object { $_ -like '*DPC*' }).Count -ge 1) "basliklar: $($titles -join ' | ')"

Write-Host "`n== 7. HTML rapor ==" -ForegroundColor Cyan
$html = New-HtmlReport -Run $run
Check 'HTML uretildi ve anlamli uzunlukta' ($html.Length -gt 6000) "uzunluk: $($html.Length)"
Check 'HTML dogru kapaniyor' ($html.TrimEnd().EndsWith('</html>')) 'kapanis etiketi yok'
Check 'Turkce karakterler korunuyor' ($html -match 'yavaşlık|Yönetici|güvenlik') 'Turkce metin bulunamadi'
Check 'Suclu tablosu HTML icinde' ($html -match 'hog_app') 'hog_app tabloda yok'
Check 'Her bolumde "Neden bakiyoruz" aciklamasi var' ((([regex]::Matches($html,'Neden bakıyoruz')).Count) -ge 8) "adet: $(([regex]::Matches($html,'Neden bakıyoruz')).Count)"
Check 'Bolum sayisi ile aciklama sayisi esit' ((([regex]::Matches($html,'<h2>')).Count) -eq (([regex]::Matches($html,'Neden bakıyoruz')).Count)) "h2: $(([regex]::Matches($html,'<h2>')).Count) / aciklama: $(([regex]::Matches($html,'Neden bakıyoruz')).Count)"
Check 'Terimler sozlugu var' ($html -match 'Raporda geçen terimler') 'sozluk bolumu yok'
Check '"bellek basinci" terimi KULLANILMIYOR' ($html -notmatch 'bellek basıncı|bellek baskısı') 'anlasilmaz terim hala var'
Check 'Yerine "RAM yetersizligi" kullaniliyor' ($html -match 'RAM yetersizliği') 'yeni terim yok'
Check '"Neden yavastı" sutunu var' ($html -match 'Neden yavaştı') 'neden sutunu yok'
Check 'Yavas satirlarin nedeni etiket + kanit iceriyor' ($html -match 'RAM yetersizliği — boş RAM') 'neden hucresi etiketsiz'
Check 'Tek bir Get-SlowReason tanimi var' ((([regex]::Matches((Get-Content "$PSScriptRoot/WinPerfDiag.ps1" -Raw),'function Get-SlowReason')).Count) -eq 1) 'cift tanim var'
Check 'Fark sutunu icin aciklama kutusu var' ($html -match 'Bu tablo nasıl okunur') 'legend yok'
Check 'AZALDI durumu HTML''de aciklanmis' ($html -match 'kurbanıdır') 'azalma aciklamasi yok'
$html | Out-File -FilePath "$PSScriptRoot/ornek-rapor.html" -Encoding UTF8

Write-Host "`n== 8. Bos CPU'da yanlis pozitif olmamali ==" -ForegroundColor Cyan
# CPU bostayken dusuk frekans NORMALDIR. Onceki surum bunu "CPU tam hiza
# cikamiyor" diye raporluyordu; artik raporlamamali.
$idleList = @()
for ($i = 0; $i -lt 6; $i++) {
    $p2 = New-FakeRaw -Ts $t0.AddSeconds($i*5) -Sec 0 -CpuUtil 0 -DpcUtil 0 -Ncpu $ncpu `
                      -HogCpuSec 0 -AgentCpuSec 0 -DiskOps 0 -DiskTotalSec 0
    $c2 = New-FakeRaw -Ts $t0.AddSeconds($i*5+5) -Sec 5 -CpuUtil 0.08 -DpcUtil 0.004 -Ncpu $ncpu `
                      -HogCpuSec 0.02 -AgentCpuSec 0.1 -DiskOps 100 -DiskTotalSec 0.1 `
                      -CpuPerfPct 32 -FreqMHz 900
    $c2.Mem.AvailableMBytes = 9000
    $c2.Sys.ProcessorQueueLength = 0
    $c2.Disk.CurrentDiskQueueLength = 0
    $idleList += (ConvertTo-Sample -Cur $c2 -Prev $p2 -Ncpu $ncpu)
}
$runIdle = New-RunObject -Caps $caps -Static $static -SampleList $idleList -Enrichment $enrich
$idleTitles = @($runIdle.Findings | ForEach-Object { $_.Title })
Check 'Bos CPU + dusuk frekans -> hiz dususu bulgusu YOK' (@($idleTitles | Where-Object { $_ -like '*yük altındayken*' }).Count -eq 0) "basliklar: $($idleTitles -join ' | ')"
$cfg = @($runIdle.Findings | Where-Object { $_.Title -like '*Maksimum işlemci durumu*' })[0]
Check 'Ayar bulgusu hala var ama AYAR OKUMASI oldugunu soyluyor' ($null -ne $cfg -and $cfg.Note -like '*AYAR OKUMASIDIR*') "not: $($cfg.Note)"
Check 'Olculemedigi icin ciddiyet dusuruldu' ($cfg.Severity -ne 'yuksek') "ciddiyet: $($cfg.Severity)"
Check 'Bos makinede yavas pencere yok' (@($runIdle.SlowWindows).Count -eq 0) "pencere: $(@($runIdle.SlowWindows).Count)"

Write-Host ""
if ($fail -eq 0) { Write-Host "TUM TESTLER GECTI" -ForegroundColor Green }
else { Write-Host "$fail TEST KALDI" -ForegroundColor Red; exit 1 }
