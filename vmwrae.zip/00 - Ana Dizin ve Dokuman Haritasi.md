# VMware MSP Denetimi — Ana Dizin ve Doküman Haritası

**Sürüm:** v4 — 14 Eylül 2026  
**Toplam:** 18 bağımsız doküman + bu ana dizin  
**Format:** Her doküman `xlsx/` ve `md/` klasörlerinde aynı adla bulunur.

---

## Doküman Haritası

| No | Doküman | Dosya Adı | Bu Dokümanda Ne Var | Hacim |
|---:|---|---|---|---|
| 1 | **Kapsam ve Metodoloji** | `01 - Kapsam ve Metodoloji` | Denetim perspektifi, kapsam ve kapsam dışı, metodoloji ve kanıta dayalılık ilkesi, kriter hiyerarşisi (bağlayıcı / iyi uygulama / teknik baseline), çalışmanın kullanımı, kanıt ve örnekleme, sonuç değerlendirme ölçeği, v4 geliştirmeleri, sınırlamalar, kısaltmalar, kanıta dayalılık uyarısı. Ayrıca kapsam boşluğu analizi, birleştirme kuralları, veri kalitesi düzeltmeleri ve açık kalemler tabloları. | 63 satır |
| 2 | **Kontrol Grupları Özeti** | `02 - Kontrol Gruplari Ozeti` | 12 kontrol grubunun kodu, adı, odak alanı ve soru sayısı; kaynak ve öncelik dağılımı; mevzuat dayanaklı soru oranı; NIST CSF 2.0 fonksiyon eşlemesi; kullanılan BDDK-BSY maddeleri, BİGR tedbirleri ve CIS ESXi bölümleri; grup bazında konfigürasyon kaynaklı risk odağı. | 12 grup + toplam |
| 3 | **Terimler** | `03 - Terimler` | İki bölüm: (1) VMware ve güvenlik teknik terim sözlüğü — İngilizce terim, Türkçe karşılık, tanım ve ilgili kontrol grubu; (2) referans kolonlarında geçen kaynak kodlarının (CIS-ESX8, VMW-SCG, NIST-ASSESS, IIA-GIAS vb.) açılımı ve doğrulama durumu. | 116 terim + 28 kaynak kodu |
| 4 | **Kısaltmalar** | `04 - Kisaltmalar` | EK soru setinin hücre içi ortak metin kısaltmaları (AS-ADV, SSH-FILES, VIPERM, TAIL-1/2, TEST-1/2, KAYIT-B/B2, SINIR-1…4, RISK-B/C) ve kaynaktan birebir alınmış tam metinleri. | 18 kısaltma |
| 5 | **Eşleme ve İzlenebilirlik** | `05 - Esleme ve Izlenebilirlik` | Tüm kontrollerin tek listesi: Kontrol ID, ait olduğu kontrol grubu, hangi dokümanda yer aldığı ve denetim sorusu. Bir kontrol ID'sinden hızlıca dokümana gitmek için kullanılır. | 150 kontrol |
| 6 | **Kaynaklar** | `06 - Kaynaklar` | Bağlayıcı mevzuat, standartlar ve çerçeveler, üretici ve baseline kaynakları, zafiyet ve tehdit istihbaratı ile kaynak çalışma dosyaları. Her kaynak için bu çalışmada nasıl kullanıldığı ve erişim/künye bilgisi. | 24 kaynak |
| KG01 | **KG01 - Yönetimsel Çerçeve, Sözleşme ve Sorumluluklar** | `Kontrol Gruplari/KG01 - Yönetimsel Çerçeve, Sözleşme ve Sorumluluklar` | 6 kontrolün 24 kolonluk tam çalışma listesi: denetim sorusu, amaç, riskler, beklenen kanıt, kanıta ulaşım yöntemi, kabul ölçütleri, test adımları, örnekleme, kanıtın sınırları, mevzuat ve teknik referanslar. Denetim Sonucu / Kanıt Referansı / Bulgu Notu alanları saha çalışması için boştur. | 6 kontrol (12 KG: 6 · EK: 0 · v3: 0) — 5 yüksek öncelikli |
| KG02 | **KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi** | `Kontrol Gruplari/KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi` | 19 kontrolün 24 kolonluk tam çalışma listesi: denetim sorusu, amaç, riskler, beklenen kanıt, kanıta ulaşım yöntemi, kabul ölçütleri, test adımları, örnekleme, kanıtın sınırları, mevzuat ve teknik referanslar. Denetim Sonucu / Kanıt Referansı / Bulgu Notu alanları saha çalışması için boştur. | 19 kontrol (12 KG: 6 · EK: 13 · v3: 0) — 15 yüksek öncelikli |
| KG03 | **KG03 - ESXi Hypervisor Güvenliği** | `Kontrol Gruplari/KG03 - ESXi Hypervisor Güvenliği` | 32 kontrolün 24 kolonluk tam çalışma listesi: denetim sorusu, amaç, riskler, beklenen kanıt, kanıta ulaşım yöntemi, kabul ölçütleri, test adımları, örnekleme, kanıtın sınırları, mevzuat ve teknik referanslar. Denetim Sonucu / Kanıt Referansı / Bulgu Notu alanları saha çalışması için boştur. | 32 kontrol (12 KG: 6 · EK: 22 · v3: 4) — 19 yüksek öncelikli |
| KG04 | **KG04 - vCenter ve Yönetim Düzeyi** | `Kontrol Gruplari/KG04 - vCenter ve Yönetim Düzeyi` | 13 kontrolün 24 kolonluk tam çalışma listesi: denetim sorusu, amaç, riskler, beklenen kanıt, kanıta ulaşım yöntemi, kabul ölçütleri, test adımları, örnekleme, kanıtın sınırları, mevzuat ve teknik referanslar. Denetim Sonucu / Kanıt Referansı / Bulgu Notu alanları saha çalışması için boştur. | 13 kontrol (12 KG: 6 · EK: 5 · v3: 2) — 11 yüksek öncelikli |
| KG05 | **KG05 - vSAN ve Depolama Dayanıklılığı** | `Kontrol Gruplari/KG05 - vSAN ve Depolama Dayanıklılığı` | 13 kontrolün 24 kolonluk tam çalışma listesi: denetim sorusu, amaç, riskler, beklenen kanıt, kanıta ulaşım yöntemi, kabul ölçütleri, test adımları, örnekleme, kanıtın sınırları, mevzuat ve teknik referanslar. Denetim Sonucu / Kanıt Referansı / Bulgu Notu alanları saha çalışması için boştur. | 13 kontrol (12 KG: 6 · EK: 2 · v3: 5) — 8 yüksek öncelikli |
| KG06 | **KG06 - Distributed Switch ve Ağ Segmentasyonu** | `Kontrol Gruplari/KG06 - Distributed Switch ve Ağ Segmentasyonu` | 16 kontrolün 24 kolonluk tam çalışma listesi: denetim sorusu, amaç, riskler, beklenen kanıt, kanıta ulaşım yöntemi, kabul ölçütleri, test adımları, örnekleme, kanıtın sınırları, mevzuat ve teknik referanslar. Denetim Sonucu / Kanıt Referansı / Bulgu Notu alanları saha çalışması için boştur. | 16 kontrol (12 KG: 6 · EK: 10 · v3: 0) — 9 yüksek öncelikli |
| KG07 | **KG07 - NSX ve Mikrosegmentasyon Güvenliği** | `Kontrol Gruplari/KG07 - NSX ve Mikrosegmentasyon Güvenliği` | 11 kontrolün 24 kolonluk tam çalışma listesi: denetim sorusu, amaç, riskler, beklenen kanıt, kanıta ulaşım yöntemi, kabul ölçütleri, test adımları, örnekleme, kanıtın sınırları, mevzuat ve teknik referanslar. Denetim Sonucu / Kanıt Referansı / Bulgu Notu alanları saha çalışması için boştur. | 11 kontrol (12 KG: 6 · EK: 5 · v3: 0) — 7 yüksek öncelikli |
| KG08 | **KG08 - vMotion, Migration, HA-DRS, Affinity Kuralları** | `Kontrol Gruplari/KG08 - vMotion, Migration, HA-DRS, Affinity Kuralları` | 8 kontrolün 24 kolonluk tam çalışma listesi: denetim sorusu, amaç, riskler, beklenen kanıt, kanıta ulaşım yöntemi, kabul ölçütleri, test adımları, örnekleme, kanıtın sınırları, mevzuat ve teknik referanslar. Denetim Sonucu / Kanıt Referansı / Bulgu Notu alanları saha çalışması için boştur. | 8 kontrol (12 KG: 6 · EK: 2 · v3: 0) — 5 yüksek öncelikli |
| KG09 | **KG09 - vCloud Director ve Tenant Yönetimi** | `Kontrol Gruplari/KG09 - vCloud Director ve Tenant Yönetimi` | 10 kontrolün 24 kolonluk tam çalışma listesi: denetim sorusu, amaç, riskler, beklenen kanıt, kanıta ulaşım yöntemi, kabul ölçütleri, test adımları, örnekleme, kanıtın sınırları, mevzuat ve teknik referanslar. Denetim Sonucu / Kanıt Referansı / Bulgu Notu alanları saha çalışması için boştur. | 10 kontrol (12 KG: 6 · EK: 4 · v3: 0) — 8 yüksek öncelikli |
| KG10 | **KG10 - VM Template, Klonlama, Snapshot ve BM Klonlama Yönetimi** | `Kontrol Gruplari/KG10 - VM Template, Klonlama, Snapshot ve BM Klonlama Yönetimi` | 8 kontrolün 24 kolonluk tam çalışma listesi: denetim sorusu, amaç, riskler, beklenen kanıt, kanıta ulaşım yöntemi, kabul ölçütleri, test adımları, örnekleme, kanıtın sınırları, mevzuat ve teknik referanslar. Denetim Sonucu / Kanıt Referansı / Bulgu Notu alanları saha çalışması için boştur. | 8 kontrol (12 KG: 6 · EK: 2 · v3: 0) — 4 yüksek öncelikli |
| KG11 | **KG11 - Patch, Upgrade ve Konfigürasyon Yönetimi** | `Kontrol Gruplari/KG11 - Patch, Upgrade ve Konfigürasyon Yönetimi` | 8 kontrolün 24 kolonluk tam çalışma listesi: denetim sorusu, amaç, riskler, beklenen kanıt, kanıta ulaşım yöntemi, kabul ölçütleri, test adımları, örnekleme, kanıtın sınırları, mevzuat ve teknik referanslar. Denetim Sonucu / Kanıt Referansı / Bulgu Notu alanları saha çalışması için boştur. | 8 kontrol (12 KG: 6 · EK: 0 · v3: 2) — 6 yüksek öncelikli |
| KG12 | **KG12 - Loglama, İzleme ve Kritik Durum Alarm Yönetimi** | `Kontrol Gruplari/KG12 - Loglama, İzleme ve Kritik Durum Alarm Yönetimi` | 6 kontrolün 24 kolonluk tam çalışma listesi: denetim sorusu, amaç, riskler, beklenen kanıt, kanıta ulaşım yöntemi, kabul ölçütleri, test adımları, örnekleme, kanıtın sınırları, mevzuat ve teknik referanslar. Denetim Sonucu / Kanıt Referansı / Bulgu Notu alanları saha çalışması için boştur. | 6 kontrol (12 KG: 6 · EK: 0 · v3: 0) — 4 yüksek öncelikli |

## Hangi Bilgi Nerede

| Aradığınız Bilgi | Doküman | Nerede |
|---|---|---|
| Denetimin kapsamı ve kapsam dışı bırakılan alanlar | `01 - Kapsam ve Metodoloji` | Kapsam / Kapsam Dışı bölümleri |
| Bir bulguyu hangi kritere dayandırabilirim | `01 - Kapsam ve Metodoloji` | Kriter Hiyerarşisi bölümü |
| Denetim sonucu değerleri ve ne anlama geldikleri | `01 - Kapsam ve Metodoloji` | Sonuç Değerlendirme Ölçeği bölümü |
| Örnekleme nasıl yapılmalı, kanıt neyi kanıtlar | `01 - Kapsam ve Metodoloji` | Kanıt Toplama ve Örnekleme bölümü |
| Bu sürümde ne değişti | `01 - Kapsam ve Metodoloji` | v4 Geliştirmeleri bölümü |
| Kapsam boşlukları ve eklenen kontroller | `01 - Kapsam ve Metodoloji` | Kapsam Boşluğu Analizi tablosu |
| İki kaynak set nasıl birleştirildi | `01 - Kapsam ve Metodoloji` | Birleştirme Kuralları tablosu |
| Kaynak dosyalarda düzeltilen hatalar | `01 - Kapsam ve Metodoloji` | Veri Kalitesi Düzeltmeleri tablosu |
| Sonraki turda yapılacaklar | `01 - Kapsam ve Metodoloji` | Açık Kalemler tablosu |
| Hangi kontrol grubunda kaç soru var | `02 - Kontrol Gruplari Ozeti` | Ana tablo — Soru Sayısı kolonu |
| Bir grubun odak alanı ve neyi denetlediği | `02 - Kontrol Gruplari Ozeti` | Ana tablo — Odak Alanı kolonu |
| Bir grup hangi BDDK maddesini / BİGR tedbirini karşılıyor | `02 - Kontrol Gruplari Ozeti` | Çerçeve eşlemesi tablosu |
| NIST CSF 2.0 fonksiyon eşlemesi | `02 - Kontrol Gruplari Ozeti` | Çerçeve eşlemesi tablosu |
| Bir grubun konfigürasyon kaynaklı risk odağı ve ilgili CVE'ler | `02 - Kontrol Gruplari Ozeti` | Konfigürasyon kaynaklı risk odağı bölümü |
| Denetim soruları, kabul ölçütleri, test adımları | `KG01 … KG12 dokümanları` | İlgili kontrol grubu dokümanı |
| Bir kontrolün mevzuat dayanağı | `KG01 … KG12 dokümanları` | Bağlayıcı Kriter (Mevzuat) kolonu |
| Bir kontrolün CIS/SCG teknik referansı | `KG01 … KG12 dokümanları` | Teknik Referanslar kolonu |
| Kanıt nasıl toplanır (PowerCLI / GUI yolu) | `KG01 … KG12 dokümanları` | Kanıta Ulaşım Yöntemi ve İnceleme ve Test Adımları kolonları |
| Bir kontrolün hangi kaynaktan geldiği | `KG01 … KG12 dokümanları` | Kaynak Soru ID kolonu (12 KG / EK G-xx / v3-GAP-xx) |
| Teknik bir terimin ne anlama geldiği | `03 - Terimler` | Teknik terimler bölümü |
| CIS-ESX8, VMW-SCG, NIST-ASSESS gibi kodların açılımı | `03 - Terimler` | Kaynak ve Referans Kodları bölümü |
| Bir referans koduna bulgu dayandırabilir miyim | `03 - Terimler` | Kaynak ve Referans Kodları — Doğrulama Durumu kolonu |
| TAIL-1, SINIR-2, RISK-B gibi hücre içi kısaltmalar | `04 - Kisaltmalar` | Tüm tablo |
| Bir Kontrol ID hangi dokümanda | `05 - Esleme ve Izlenebilirlik` | Tüm tablo — Kontrol ID ile arayın |
| Tüm kontrollerin tek listesi | `05 - Esleme ve Izlenebilirlik` | Tüm tablo |
| Bir mevzuatın veya standardın künyesi | `06 - Kaynaklar` | Erişim / Referans Bilgisi kolonu |
| Bir kaynağın bu çalışmada nasıl kullanıldığı | `06 - Kaynaklar` | Bu Çalışmada Kullanım Şekli kolonu |
| Zafiyet ve tehdit istihbaratı kaynakları (CVE, VMSA, KEV) | `06 - Kaynaklar` | Zafiyet ve tehdit istihbaratı bölümü |

## Okuma Sırası

| Adım | Rol / Aşama | Doküman | Yapılacak |
|---:|---|---|---|
| 1 | Denetim planlaması | `02 - Kontrol Gruplari Ozeti` | Kontrol gruplarını ve çerçeve kapsamasını gözden geçir. |
| 2 | Denetim planlaması | `01 - Kapsam ve Metodoloji` | Kapsam, kriter hiyerarşisi ve sonuç ölçeğini ekiple hizala. |
| 3 | Hazırlık | `03 - Terimler + 04 - Kisaltmalar` | Terim ve kısaltmaları saha ekibine dağıt. |
| 4 | Saha çalışması | `İlgili KG dokümanı` | Denetim Sonucu / Kanıt Referansı / Bulgu Notu doldur. |
| 5 | Bulgu yazımı | `06 - Kaynaklar + 01 - Kapsam ve Metodoloji` | Dayanağı bağlayıcı kritere bağla, künyeyi doğrula. |
| 6 | Raporlama | `05 - Esleme ve Izlenebilirlik + 02 - Kontrol Gruplari Ozeti` | Kontrol ID üzerinden izlenebilirlik ve kapsama raporu. |

## Kontrol Dizini (150 kontrol)

Tam liste ana dizin excel'inin *Kontrol Dizini* sayfasındadır; kontrol ID → doküman eşlemesi için `05 - Esleme ve Izlenebilirlik` dokümanına da bakılabilir.

