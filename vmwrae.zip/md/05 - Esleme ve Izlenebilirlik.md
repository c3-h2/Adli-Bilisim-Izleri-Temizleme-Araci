# Eşleme ve İzlenebilirlik

**Çalışma:** VMware MSP Denetimi · **Sürüm:** v4 — 14 Eylül 2026  
**Doküman:** Tüm kontrollerin tek listesi ve bulundukları doküman  
**Hazırlayan:** KKB İç Denetim Başkanlığı — BT Denetimi (danışmanlık çıktısıdır, son karar denetçinindir)  
**Ana dizin:** `00 - Ana Dizin ve Dokuman Haritasi.xlsx`

---

Kaynak set ve ilişkili üst kontrol bilgisi, ilgili kontrol grubu dokümanındaki *Kaynak Soru ID* ve *İlişkili Üst Kontrol* alanlarında tutulur.

| Kontrol ID | Sayfa | Doküman | Denetim Sorusu |
|---|---|---|---|
| `KG01-01` | KG01 | KG01 - Yönetimsel Çerçeve, Sözleşme ve Sorumluluklar | MSP ile müşteri arasında rol ve sorumluluklar (RACI), güvenlik, yedekleme, izleme, kriz yönetimi ve değişiklik süreçleri için yazılı ve imzalı olarak tanımlanmış mı? |
| `KG01-02` | KG01 | KG01 - Yönetimsel Çerçeve, Sözleşme ve Sorumluluklar | Her müşterinin onboarding aşaması için teknik ve güvenlik kapsam dokümanı hazırlanıp onay alınıyor mu? |
| `KG01-03` | KG01 | KG01 - Yönetimsel Çerçeve, Sözleşme ve Sorumluluklar | Değişiklik yönetim süreçlerinde acil ve normal değişiklik akışları ayrık mı ve her ikisi için ayrı onay kontrolü bulunuyor mu? |
| `KG01-04` | KG01 | KG01 - Yönetimsel Çerçeve, Sözleşme ve Sorumluluklar | RPO/RTO/MTTR hedefleri yazılı ve teknik hedeflerle ilişkilendirilmiş mi, periyodik ölçüm planı var mı? |
| `KG01-05` | KG01 | KG01 - Yönetimsel Çerçeve, Sözleşme ve Sorumluluklar | DR/olasılık senaryoları için runbook onaylı ve düzenli test edilmiş mi? |
| `KG01-06` | KG01 | KG01 - Yönetimsel Çerçeve, Sözleşme ve Sorumluluklar | Üçüncü taraf erişimleri için due diligence ve periyodik erişim yeniden değerlendirmesi (access recertification) uygulanıyor mu? |
| `KG02-01` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | Ayrıcalıklı hesap envanteri (vCenter/ESXi/NSX/vCloud) güncel ve merkezi olarak izleniyor mu? |
| `KG02-02` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | Ayrıcalıklı hesaplar için MFA zorunlu mu ve atlatma (bypass) durumu izleniyor mu? |
| `KG02-03` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | Least privilege ilkesine göre role dayalı ayırma uygulanıyor mu, gereksiz yüksek yetkili hesaplar minimize edilmiş mi? |
| `KG02-04` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | Servis hesapları için parola/anahtar yönetimi (key management) ve saklama politikası uygulanıyor mu? |
| `KG02-05` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | Ayrıcalıklı işlemlerde ikili onay (dual authorization) veya denetimce onay hattı bulunuyor mu? |
| `KG02-06` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | Ayrıcalıklı hesaplarda oturum başarısızlıkları ve anomali girişimleri SIEM'de filtreleniyor mu? |
| `KG02-07` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | Cloud Director: Organizasyonun yerel hesap (local account) kilitleme (account lockout) politikası tanımlı ve uygulanıyor mu? |
| `KG02-08` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | ESXi: Host Password Complexity kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG02-09` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | ESXi: Account Lockout Threshold ve Account Lockout Duration ayarları kabul ölçütlerini karşılıyor mu? |
| `KG02-10` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | ESXi: Password History kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG02-11` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | ESXi: Password Maximum Age ayarı onaylı parola politikasını karşılıyor mu? |
| `KG02-12` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | ESXi: Servis hesaplarının shell yetkisi kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG02-13` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | ESXi: ESXi 7 AD katılımı ve yönetici grubu (administrator group) kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG02-14` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | ESXi: ESXi 7 kişisel yerel yönetici hesabı kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG02-15` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | ESXi: ESXi 7 SSH authorized_keys kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG02-16` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | ESXi: AD etki alanına host katılımı sırasında yeniden kullanılan yönetici parolaları otomasyonda saklanıyor mu? |
| `KG02-17` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | NSX: NSX sertifikalı otomasyon kimlikleri (principal identity) en az yetki (least privilege) ve gerekli nesne yollarıyla sınırlı mı? |
| `KG02-18` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | vCenter: Yerel SSO başarısız giriş (failed login) sayımı, hesap kilidi (account lockout) ve kilit açılması (account unlock) birlikte doğrulanıyor mu? |
| `KG02-19` | KG02 | KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi | vCenter: VCSA root hesabının parola ömrü (password maximum age) ve acil erişim işleyişi onaylı kimlik politikasına bağlı mı? |
| `KG03-01` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi host yapılandırmaları CIS ESXi Benchmark'a göre merkezileştirilmiş policy ile karşılaştırılıyor mu? |
| `KG03-02` | KG03 | KG03 - ESXi Hypervisor Güvenliği | SSH, ESXi Shell ve DCUI erişimi bakım dışı zamanlarda kapalı tutuluyor mu? |
| `KG03-03` | KG03 | KG03 - ESXi Hypervisor Güvenliği | Lockdown Mode/benzer yönetim kısıtı uygulandı mı ve istisna süreçleri kayıtlı mı? |
| `KG03-04` | KG03 | KG03 - ESXi Hypervisor Güvenliği | Host zaman senkronizasyonu (time synchronization / NTP) güvenilir bir zaman kaynağına bağlı mı? |
| `KG03-05` | KG03 | KG03 - ESXi Hypervisor Güvenliği | Yönetim ve API bağlantılarında TLS/sertifika ayarları güvenli mi? |
| `KG03-06` | KG03 | KG03 - ESXi Hypervisor Güvenliği | Host firmware/BMC fiziksel güvenlik kontrolleri ve bütünlük süreçleri düzenli izleniyor mu? |
| `KG03-07` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: BMC yönetim güvenliği kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-08` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: DCUI Idle Session Timeout kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-09` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: Shell ve SSH Idle Session Timeout kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-10` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: Shell Service Availability Timeout kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-11` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: API ve Host Client oturum sınırları kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-12` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: Lockdown ve bypass hesapları kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-13` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: Host oturum uyarı metinleri (login banner) kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-14` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: CIM ve SNMP koşullu yetki sınırı kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-15` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: SSH daemon yetenek sınırlamaları (capability restrictions) kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-16` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: SSH keepalive süre parametreleri kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-17` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: VM konsol sınırları kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-18` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: Son VM konsol bağlantısı kapandığında misafir oturumu (guest session) kilitleniyor mu? |
| `KG03-19` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: Host ve VM dvFilter erişimi kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-20` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: Standard vSwitch MAC güvenliği kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-21` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: Standard vSwitch VLAN sınırları kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-22` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: Intel SGX kapsamı kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-23` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: Gereksiz host yönetim servisleri kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-24` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: Gereksiz VM donanımı ve 3D kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-25` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: Guest OS'nin aygıt bağlama/değiştirme (device connect/edit) yetkisi kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-26` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: Gereksiz Tools bilgi/işlev modülleri kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-27` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: ESXi 7 gereksiz guest işlevleri kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-28` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: ESXi 7 guest-host masaüstü entegrasyonları kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG03-29` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: İmzasız veya kurulu olmayan ikili dosyaların host üzerinde çalıştırılması engellenmiş mi (VMkernel.Boot.execInstalledOnly)? |
| `KG03-30` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: Host'larda UEFI Secure Boot etkin mi ve etkinleştirilemeyen host'lar için onaylı istisna kaydı tutuluyor mu? |
| `KG03-31` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: Host'larda TPM 2.0 mevcut ve vCenter üzerindeki host attestation durumu başarılı mı? |
| `KG03-32` | KG03 | KG03 - ESXi Hypervisor Güvenliği | ESXi: Sanal makinelerde gereksiz aygıt ve host-guest iletişim kanalları (VMCI, USB/xHCI denetleyici, seri/paralel port, CD-ROM/floppy, paylaşılan klasör) kaldırılmış veya devre dışı bırakılmış mı? |
| `KG04-01` | KG04 | KG04 - vCenter ve Yönetim Düzeyi | vCenter SSO, kimlik doğrulama ve merkezi doğrulama (identity source) (ID source) ayarları en güvenli düzeyde mi? |
| `KG04-02` | KG04 | KG04 - vCenter ve Yönetim Düzeyi | API, CLI ve admin yetkileri için kısıtlı erişim modeli uygulanmış mı? |
| `KG04-03` | KG04 | KG04 - vCenter ve Yönetim Düzeyi | vCenter yedeklemesi düzenli mi, yedekler geri dönüş testi (restore test)nden geçmiş mi? |
| `KG04-04` | KG04 | KG04 - vCenter ve Yönetim Düzeyi | Rol ve izinler düzenli access review ile doğrulanıyor mu? |
| `KG04-05` | KG04 | KG04 - vCenter ve Yönetim Düzeyi | vCenter ve bileşenleri vendor destek döngüsünde kalacak şekilde güncel mi? |
| `KG04-06` | KG04 | KG04 - vCenter ve Yönetim Düzeyi | Yönetim trafiği için ayrı bir yönetim ağı (management network) ve erişim sınırı tasarımı mevcut mu? |
| `KG04-07` | KG04 | KG04 - vCenter ve Yönetim Düzeyi | vCenter: vSphere Client boşta kalan (idle) yönetici oturumunu belirlenen sürede sonlandırıyor mu? |
| `KG04-08` | KG04 | KG04 - vCenter ve Yönetim Düzeyi | vCenter: vSphere Client ve VCSA SSH giriş uyarıları (login banner) kurumsal olarak onaylı mı ve doğru yüzeyde gösteriliyor mu? |
| `KG04-09` | KG04 | KG04 - vCenter ve Yönetim Düzeyi | vCenter: vCenter kurumsal kimlik entegrasyonu ve yerel hesap (local account) istisnaları kontrol ediliyor mu? |
| `KG04-10` | KG04 | KG04 - vCenter ve Yönetim Düzeyi | vCenter: vCenter global permission ve propagate seçenekleri müşteri kapsamını aşıyor mu? |
| `KG04-11` | KG04 | KG04 - vCenter ve Yönetim Düzeyi | vCenter: VCSA SSH erişimi rutin kullanım dışında kapalı mı? |
| `KG04-12` | KG04 | KG04 - vCenter ve Yönetim Düzeyi | vCenter, ESXi ve NSX yönetim arayüzlerinin internetten ve genel kurumsal ağdan fiilen erişilebilir olmadığı periyodik olarak taramayla doğrulanıyor mu? |
| `KG04-13` | KG04 | KG04 - vCenter ve Yönetim Düzeyi | Yönetim düzlemine erişim jump host / bastion üzerinden zorunlu kılınmış mı ve doğrudan erişim istisnaları kayıt altına alınıyor mu? |
| `KG05-01` | KG05 | KG05 - vSAN ve Depolama Dayanıklılığı | vSAN sağlık durumu, component health ve kapasite sapmaları düzenli izleniyor mu? |
| `KG05-02` | KG05 | KG05 - vSAN ve Depolama Dayanıklılığı | vSAN verileri şifrelenmiş mi ve anahtar yönetimi (key management) kontrollü mü? |
| `KG05-03` | KG05 | KG05 - vSAN ve Depolama Dayanıklılığı | Storage policy setleri (FTT, stripe, compression vb.) doğru iş yüklerine atanmış mı? |
| `KG05-04` | KG05 | KG05 - vSAN ve Depolama Dayanıklılığı | Depolama kapasite eşiği (capacity threshold) alarmları ve önleyici eylem planı uygulanıyor mu? |
| `KG05-05` | KG05 | KG05 - vSAN ve Depolama Dayanıklılığı | vSAN network ayrımı ve güvenli trafiği sağlayacak vmkernel port tasarımı net mi? |
| `KG05-06` | KG05 | KG05 - vSAN ve Depolama Dayanıklılığı | Failover ve recovery davranışları için en az yıllık periyotlu uygulama testi var mı? |
| `KG05-07` | KG05 | KG05 - vSAN ve Depolama Dayanıklılığı | vSAN: Datastore ve VM disk işlemleri müşteri yetki sınırını koruyor mu? |
| `KG05-08` | KG05 | KG05 - vSAN ve Depolama Dayanıklılığı | vSAN: vSAN File Services NFS paylaşımları yalnız yetkili istemci ağlarına açık mı? |
| `KG05-09` | KG05 | KG05 - vSAN ve Depolama Dayanıklılığı | Sanallaştırma ortamının yedekleri, üretim depolamasından ve üretim kimlik alanından ayrık bir hata alanında mı tutuluyor? |
| `KG05-10` | KG05 | KG05 - vSAN ve Depolama Dayanıklılığı | Yedekler değiştirilemez (immutable / WORM) saklama ile korunuyor ve değişmezlik süresi kurtarma hedefleriyle uyumlu mu? |
| `KG05-11` | KG05 | KG05 - vSAN ve Depolama Dayanıklılığı | Yedekleme sistemine yönetici erişimi ayrıcalıklı erişim yönetimi (PAM) ile kısıtlanmış mı ve yedek silme / saklama süresi (retention period) değiştirme işlemleri ikili onaya (dual authorization) bağlı mı? |
| `KG05-12` | KG05 | KG05 - vSAN ve Depolama Dayanıklılığı | Yedeklerden geri yükleme testi tanımlı periyotta yapılıyor, sonucu kayıt altına alınıyor ve RPO/RTO hedefleriyle karşılaştırılıyor mu? |
| `KG05-13` | KG05 | KG05 - vSAN ve Depolama Dayanıklılığı | Yedekler şifreleniyor ve yedek şifreleme anahtarları üretim anahtar yönetimi (key management)nden ayrık mı saklanıyor? |
| `KG06-01` | KG06 | KG06 - Distributed Switch ve Ağ Segmentasyonu | vDS portgroup güvenlik politikası (promiscuous/mac spoof/flooding) iş gereğine uygun uygulanmış mı? |
| `KG06-02` | KG06 | KG06 - Distributed Switch ve Ağ Segmentasyonu | Yönetim, vMotion, vSAN ve iş ağı trafikleri ayrı segmentlere ayrılmış mı? |
| `KG06-03` | KG06 | KG06 - Distributed Switch ve Ağ Segmentasyonu | NIC teaming ve failover politikası iş yükü/HA ihtiyacıyla uyumlu mu? |
| `KG06-04` | KG06 | KG06 - Distributed Switch ve Ağ Segmentasyonu | Ağ görünürlüğü için flow/port mirroring ve IDS-NDR entegrasyonu işletimde mi? |
| `KG06-05` | KG06 | KG06 - Distributed Switch ve Ağ Segmentasyonu | Ağ değişikliklerinde önceden onay ve sürüm kaydı zorunluluğu var mı? |
| `KG06-06` | KG06 | KG06 - Distributed Switch ve Ağ Segmentasyonu | Donanım ve switch ekosistemi ile vDS uyumluluk testleri düzenli mi? |
| `KG06-07` | KG06 | KG06 - Distributed Switch ve Ağ Segmentasyonu | Distributed Switch: Distributed Port Group yapılandırmasında promiscuous mode gereksizse Reject mi? |
| `KG06-08` | KG06 | KG06 - Distributed Switch ve Ağ Segmentasyonu | Distributed Switch: Distributed Port Group yapılandırmasında forged transmits gereksizse Reject mi? |
| `KG06-09` | KG06 | KG06 - Distributed Switch ve Ağ Segmentasyonu | Distributed Switch: Distributed Port Group yapılandırmasında MAC address changes gereksizse Reject mi? |
| `KG06-10` | KG06 | KG06 - Distributed Switch ve Ağ Segmentasyonu | Distributed Switch: VLAN/trunk aralıkları her tenant için gerekli ağlarla sınırlandırılmış mı? |
| `KG06-11` | KG06 | KG06 - Distributed Switch ve Ağ Segmentasyonu | Distributed Switch: Port mirroring ve trafik yakalama (traffic capture) yetkileri kontrollü mü? |
| `KG06-12` | KG06 | KG06 - Distributed Switch ve Ağ Segmentasyonu | Distributed Switch: Distributed Port Group yapılandırmasında MAC Learning yalnız belgeli işlev ihtiyacı için etkin mi? |
| `KG06-13` | KG06 | KG06 - Distributed Switch ve Ağ Segmentasyonu | Distributed Switch: VM porttan ayrıldığında port yapılandırması sıfırlanıyor mu? |
| `KG06-14` | KG06 | KG06 - Distributed Switch ve Ağ Segmentasyonu | Distributed Switch: Port düzeyi override ile port grubu (port group) güvenlik politikası aşılabiliyor mu? |
| `KG06-15` | KG06 | KG06 - Distributed Switch ve Ağ Segmentasyonu | Distributed Switch: VDS NetFlow hedefi kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG06-16` | KG06 | KG06 - Distributed Switch ve Ağ Segmentasyonu | Distributed Switch: VDS health check kullanımı kontrolü, kabul ölçütlerini karşılıyor mu? |
| `KG07-01` | KG07 | KG07 - NSX ve Mikrosegmentasyon Güvenliği | NSX Manager ve Edge güvenlik tasarımı için sertifika, erişim ve yönetim hardening kuralları uygulanmış mı? |
| `KG07-02` | KG07 | KG07 - NSX ve Mikrosegmentasyon Güvenliği | Dağıtık firewall policy default deny mantığına uyuyor mu? |
| `KG07-03` | KG07 | KG07 - NSX ve Mikrosegmentasyon Güvenliği | Mikrosegmentasyon için VM/Workload tag ve grup yönetimi operasyonel olarak güncelliğini koruyor mu? |
| `KG07-04` | KG07 | KG07 - NSX ve Mikrosegmentasyon Güvenliği | Edge gateway NAT/DFW/WAF/IPS kuralları denetime açık ve dokümante mi? |
| `KG07-05` | KG07 | KG07 - NSX ve Mikrosegmentasyon Güvenliği | NSX servis zincirleri (service insertion) gerçek trafikte test edilip doğrulanmış mı? |
| `KG07-06` | KG07 | KG07 - NSX ve Mikrosegmentasyon Güvenliği | Olay kanıtlarının manipülasyona karşı korunması. |
| `KG07-07` | KG07 | KG07 - NSX ve Mikrosegmentasyon Güvenliği | NSX: DFW politikaları izinli akış (allowed flow) dışındaki müşteri geçişlerini engelliyor mu? |
| `KG07-08` | KG07 | KG07 - NSX ve Mikrosegmentasyon Güvenliği | NSX: NSX dinamik grupları (dynamic group) ve etiket atama (tag assignment) yetkileri doğru VM'leri kapsıyor mu? |
| `KG07-09` | KG07 | KG07 - NSX ve Mikrosegmentasyon Güvenliği | NSX: DFW exclusion list sadece onaylı sistemleri içeriyor mu? |
| `KG07-10` | KG07 | KG07 - NSX ve Mikrosegmentasyon Güvenliği | NSX: Tier-0/Tier-1 ve gateway kuralları tenant rotalarının izinsiz birleşmesini engelliyor mu? |
| `KG07-11` | KG07 | KG07 - NSX ve Mikrosegmentasyon Güvenliği | NSX: NSX SpoofGuard profili doğru segment/port ve IP bağlarıyla uygulanıyor mu? |
| `KG08-01` | KG08 | KG08 - vMotion, Migration, HA-DRS, Affinity Kuralları | vMotion ve Storage vMotion yetkileri sadece gerekli kullanıcı/rollere ve yetkili ağlara kısıtlı mı? |
| `KG08-02` | KG08 | KG08 - vMotion, Migration, HA-DRS, Affinity Kuralları | HA/DRS affinity ve anti-affinity kuralları kritik servislere göre uygulanmış mı? |
| `KG08-03` | KG08 | KG08 - vMotion, Migration, HA-DRS, Affinity Kuralları | HA admission control ve failover parametreleri iş taleplerine uygun mu? |
| `KG08-04` | KG08 | KG08 - vMotion, Migration, HA-DRS, Affinity Kuralları | Bakım pencerelerinde vMotion/DRS aksiyonları önceden onaylanmış runbook'a göre mi yürütülüyor? |
| `KG08-05` | KG08 | KG08 - vMotion, Migration, HA-DRS, Affinity Kuralları | vMotion kapasite ve performans alarm eşikleri belirlenmiş mi? |
| `KG08-06` | KG08 | KG08 - vMotion, Migration, HA-DRS, Affinity Kuralları | Pinned, anti-affinity ve sınıflandırma kurallarına uygun migration istisnaları yönetiliyor mu? |
| `KG08-07` | KG08 | KG08 - vMotion, Migration, HA-DRS, Affinity Kuralları | vMotion: Taşıma işlemi VM'yi izin verilmeyen müşteri veya lokasyon havuzuna götürebiliyor mu? |
| `KG08-08` | KG08 | KG08 - vMotion, Migration, HA-DRS, Affinity Kuralları | vMotion: vMotion sonrasında güvenlik politikası ve müşteri ağı aynı şekilde korunuyor mu? |
| `KG09-01` | KG09 | KG09 - vCloud Director ve Tenant Yönetimi | Tenant onboarding workflow'u güvenlik kontrolleriyle bütünleşik mi? |
| `KG09-02` | KG09 | KG09 - vCloud Director ve Tenant Yönetimi | Tenantlar arasında ağ, hesap ve compute izolasyonu teknik olarak uygulanmış mı? |
| `KG09-03` | KG09 | KG09 - vCloud Director ve Tenant Yönetimi | Tenant yöneticilerinin rol ve erişimleri sadece kendi tenant kapsamını kapsıyor mu? |
| `KG09-04` | KG09 | KG09 - vCloud Director ve Tenant Yönetimi | Tenant quota, resource limit ve izleme politikaları uygulanıyor mu? |
| `KG09-05` | KG09 | KG09 - vCloud Director ve Tenant Yönetimi | Tenant offboarding işlemlerinde hesap, VM ve depolama kalıntıları (residual data) tamamen temizleniyor mu? |
| `KG09-06` | KG09 | KG09 - vCloud Director ve Tenant Yönetimi | Tenant şablon (template)ları merkezi yönetiliyor ve güvenli imaj onayı var mı? |
| `KG09-07` | KG09 | KG09 - vCloud Director ve Tenant Yönetimi | Cloud Director: Rights bundle ve global role yayınları sadece hedef organizasyonları kapsıyor mu? |
| `KG09-08` | KG09 | KG09 - vCloud Director ve Tenant Yönetimi | Cloud Director: Tenant hesabı başka organizasyonun VM, ağ, katalog ve görevlerini görebiliyor mu? |
| `KG09-09` | KG09 | KG09 - vCloud Director ve Tenant Yönetimi | Cloud Director: Paylaşılan katalog ve şablon (template)larda sırlar veya müşteri kalıntıları (residual data) temizleniyor mu? |
| `KG09-10` | KG09 | KG09 - vCloud Director ve Tenant Yönetimi | Cloud Director: Catalog, vApp template ve content library paylaşımı yalnız hedef organizationlarla sınırlandırılmış mı? |
| `KG10-01` | KG10 | KG10 - VM Template, Klonlama, Snapshot ve BM Klonlama Yönetimi | Golden image/sabit şablon (template) süreçlerinde hardening sonrası onay süreci uygulanıyor mu? |
| `KG10-02` | KG10 | KG10 - VM Template, Klonlama, Snapshot ve BM Klonlama Yönetimi | VM clone ve dağıtım onayı kritik sistemlerde zorunlu mu? |
| `KG10-03` | KG10 | KG10 - VM Template, Klonlama, Snapshot ve BM Klonlama Yönetimi | Snapshot kullanım politikası, maksimum süre ve otomasyonla temizlik prosedürü var mı? |
| `KG10-04` | KG10 | KG10 - VM Template, Klonlama, Snapshot ve BM Klonlama Yönetimi | Snapshot rollback/delete öncesi onay ve geri dönüş etkisi analiz edilmiş mi? |
| `KG10-05` | KG10 | KG10 - VM Template, Klonlama, Snapshot ve BM Klonlama Yönetimi | BM (bare-metal) veya platformlar arası klonlama (clone) için lisans, sürüm ve uyumluluk kontrolü var mı? |
| `KG10-06` | KG10 | KG10 - VM Template, Klonlama, Snapshot ve BM Klonlama Yönetimi | VM yaşam döngüsünü (create, template, clone, patch, snapshot, retire) otomatik raporlama karşılıyor mu? |
| `KG10-07` | KG10 | KG10 - VM Template, Klonlama, Snapshot ve BM Klonlama Yönetimi | ESXi: VM dağıtımı onaylı ve güvenli şablon (template) sürecinden geçiyor mu? |
| `KG10-08` | KG10 | KG10 - VM Template, Klonlama, Snapshot ve BM Klonlama Yönetimi | ESXi: Kurulumu tamamlanmış VM alternatif ağ veya çıkarılabilir ortam (removable media)dan izinsiz başlatılabiliyor mu? |
| `KG11-01` | KG11 | KG11 - Patch, Upgrade ve Konfigürasyon Yönetimi | Tüm temel katmanlar (ESXi, vCenter, NSX, vCloud) için risk tabanlı yama planı ve önceliklendirme var mı? |
| `KG11-02` | KG11 | KG11 - Patch, Upgrade ve Konfigürasyon Yönetimi | Upgrade öncesi staging test ve geri dönüş planı bulunuyor mu? |
| `KG11-03` | KG11 | KG11 - Patch, Upgrade ve Konfigürasyon Yönetimi | Upgrade sonrasında config drift kontrolü otomatik mi yapılmış? |
| `KG11-04` | KG11 | KG11 - Patch, Upgrade ve Konfigürasyon Yönetimi | Uyum ve destek belgelerine göre sürüm uyumluluk (interoperability) kontrolü yapılıyor mu? |
| `KG11-05` | KG11 | KG11 - Patch, Upgrade ve Konfigürasyon Yönetimi | Yama ve upgrade faaliyetlerinde güvenli otomasyon araçları kullanılmakta mı? |
| `KG11-06` | KG11 | KG11 - Patch, Upgrade ve Konfigürasyon Yönetimi | Acil yama taleplerinde hız-ağırlaştırılmış kontrol yerine acil prosedür uygulanıyor mu? |
| `KG11-07` | KG11 | KG11 - Patch, Upgrade ve Konfigürasyon Yönetimi | Sanallaştırma katmanı (ESXi, vCenter, NSX, Cloud Director) kimliği doğrulanmış (authenticated) zafiyet taramasına dahil mi ve bulgu kapatma SLA'i tanımlı mı? |
| `KG11-08` | KG11 | KG11 - Patch, Upgrade ve Konfigürasyon Yönetimi | Broadcom/VMware VMSA güvenlik duyuruları izleniyor, ortama etkisi değerlendiriliyor ve gerektiğinde acil yama süreci tetikleniyor mu? |
| `KG12-01` | KG12 | KG12 - Loglama, İzleme ve Kritik Durum Alarm Yönetimi | vCenter, ESXi, NSX, vCloud logları tek kanalda bütünlüklü ve imzalı toplanıyor mu? |
| `KG12-02` | KG12 | KG12 - Loglama, İzleme ve Kritik Durum Alarm Yönetimi | Kritik event sınıfları için alarm eşiği tanımlı ve test edilmiş mi? |
| `KG12-03` | KG12 | KG12 - Loglama, İzleme ve Kritik Durum Alarm Yönetimi | Kritik alarm sonrası olay yanıt (incident response) playbook'u ve SLA hedefi uygulanıyor mu? |
| `KG12-04` | KG12 | KG12 - Loglama, İzleme ve Kritik Durum Alarm Yönetimi | Kritik güvenlik eventleri (snapshot anomalisi, auth anomaly, migration kritik event) için korelasyon kuralları (correlation rules) var mı? |
| `KG12-05` | KG12 | KG12 - Loglama, İzleme ve Kritik Durum Alarm Yönetimi | Log saklama süresi (retention period) ve arşivleme süreci düzenlemelere uygun mu? |
| `KG12-06` | KG12 | KG12 - Loglama, İzleme ve Kritik Durum Alarm Yönetimi | Varlık üzerindeki alarm yükü için vardiya ve alarm gürültüsü (alert noise) filtreleme politikası çalışıyor mu? |

