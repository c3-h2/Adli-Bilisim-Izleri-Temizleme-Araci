# KG06 - Distributed Switch ve Ağ Segmentasyonu

**Çalışma:** VMware MSP Denetimi · **Sürüm:** v4 — 14 Eylül 2026  
**Doküman:** Kontrol grubu çalışma listesi — 16 kontrol  
**Hazırlayan:** KKB İç Denetim Başkanlığı — BT Denetimi (danışmanlık çıktısıdır, son karar denetçinindir)  
**Ana dizin:** `00 - Ana Dizin ve Dokuman Haritasi.xlsx`

---

> Uyumsuzluk hükmü yalnızca **Bağlayıcı Kriter (Mevzuat)** alanındaki maddeye atıfla verilebilir. **İyi Uygulama** alanı tek başına uyumsuzluk dayanağı değildir. Terim ve kısaltmalar için `03 - Terimler` ve `04 - Kisaltmalar` dokümanlarına, metodoloji için `01 - Kapsam ve Metodoloji` dokümanına bakınız.

| Kontrol ID | Denetim Sorusu | Öncelik | Test Yöntemi | Kaynak |
|---|---|---|---|---|
| `KG06-01` | vDS portgroup güvenlik politikası (promiscuous/mac spoof/flooding) iş gereğine uygun uygulanmış mı? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG06-02` | Yönetim, vMotion, vSAN ve iş ağı trafikleri ayrı segmentlere ayrılmış mı? | Yüksek | Güvenlik Denetimi + Doküman İncelemesi | 12 KG |
| `KG06-03` | NIC teaming ve failover politikası iş yükü/HA ihtiyacıyla uyumlu mu? | Orta | Güvenlik Denetimi | 12 KG |
| `KG06-04` | Ağ görünürlüğü için flow/port mirroring ve IDS-NDR entegrasyonu işletimde mi? | Orta | Güvenlik Denetimi | 12 KG |
| `KG06-05` | Ağ değişikliklerinde önceden onay ve sürüm kaydı zorunluluğu var mı? | Yüksek | Doküman İncelemesi + Güvenlik Denetimi | 12 KG |
| `KG06-06` | Donanım ve switch ekosistemi ile vDS uyumluluk testleri düzenli mi? | Düşük | Doküman İncelemesi | 12 KG |
| `KG06-07` | Distributed Switch: Distributed Port Group yapılandırmasında promiscuous mode gereksizse Reject mi? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-05 |
| `KG06-08` | Distributed Switch: Distributed Port Group yapılandırmasında forged transmits gereksizse Reject mi? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-06 |
| `KG06-09` | Distributed Switch: Distributed Port Group yapılandırmasında MAC address changes gereksizse Reject mi? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-07 |
| `KG06-10` | Distributed Switch: VLAN/trunk aralıkları her tenant için gerekli ağlarla sınırlandırılmış mı? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-08 |
| `KG06-11` | Distributed Switch: Port mirroring ve trafik yakalama (traffic capture) yetkileri kontrollü mü? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-09 |
| `KG06-12` | Distributed Switch: Distributed Port Group yapılandırmasında MAC Learning yalnız belgeli işlev ihtiyacı için etkin mi? | Orta | Yapılandırma İncelemesi (Configuration Review) | EK G2-10 |
| `KG06-13` | Distributed Switch: VM porttan ayrıldığında port yapılandırması sıfırlanıyor mu? | Orta | Yapılandırma İncelemesi (Configuration Review) | EK G2-11 |
| `KG06-14` | Distributed Switch: Port düzeyi override ile port grubu (port group) güvenlik politikası aşılabiliyor mu? | Yüksek | Yapılandırma İncelemesi (Configuration Review) | EK G2-12 |
| `KG06-15` | Distributed Switch: VDS NetFlow hedefi kontrolü, kabul ölçütlerini karşılıyor mu? | Orta | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-13 |
| `KG06-16` | Distributed Switch: VDS health check kullanımı kontrolü, kabul ölçütlerini karşılıyor mu? | Orta | Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı | EK G3-01 |

## KG06-01 — vDS portgroup güvenlik politikası (promiscuous/mac spoof/flooding) iş gereğine uygun uygulanmış mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Layer-2 düzeyindeki lateral movement riskini azaltmak.
- **Olası Riskler:** VM spoofing saldırıları, yanlış trafik yayılımı.
- **Beklenen Kanıt:** DVSwitch policy exportları, port group listeleme
- **Kanıta Ulaşım Yöntemi:** Ortamdaki port group konfigürasyonları alınır, riskli portlar listelenir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (SC-7), CIS networking security
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.11 (sanal makineler arası trafik güvenlik kontrollerinden geçirilmeli), BDDK-BSY Md. 14/2 (güvenlik duvarı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG06-02 — Yönetim, vMotion, vSAN ve iş ağı trafikleri ayrı segmentlere ayrılmış mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi + Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Trafik türlerini izolasyon altında tutarak performans ve güvenliği artırmak.
- **Olası Riskler:** Bir segmentteki arıza diğerini etkileyebilir.
- **Beklenen Kanıt:** Segment şeması, vmkernel port bağlama raporları
- **Kanıta Ulaşım Yöntemi:** Fiziksel+sanal ağ diyagramlarıyla host port map'leri karşılaştırılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS vSphere Network Guide, NIST SP 800-53 (SC-7)
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.6.6 (ağlar katmanlara ayrılmalı, yönetimsel işlemler için ayrı yönetim ağları kullanılmalı, sunucu ağında istemci yer almamalı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG06-03 — NIC teaming ve failover politikası iş yükü/HA ihtiyacıyla uyumlu mu?

**Öncelik:** Orta · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Ağ hatası durumunda sürdürülebilirliği garantilemek.
- **Olası Riskler:** Kötü failover konfigürasyonu ile tek noktada trafik kesimi.
- **Beklenen Kanıt:** Teaming policy çıktıları, link health logları
- **Kanıta Ulaşım Yöntemi:** vDS ayarları ile gerçek kesinti senaryoları karşılaştırılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (SC-5), CIS network resilience
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 27/2 (yedek veri işleme sistemi, süreklilik), CBDDO 3.1.9.2 (kapasite ve süreklilik)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG06-04 — Ağ görünürlüğü için flow/port mirroring ve IDS-NDR entegrasyonu işletimde mi?

**Öncelik:** Orta · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Şüpheli davranışı sadece host loglarıyla değil akış verisiyle de yakalayabilmek.
- **Olası Riskler:** Saldırı izi zaman içinde kaybolur.
- **Beklenen Kanıt:** Monitoring feed listeleri, SIEM entegrasyonları
- **Kanıta Ulaşım Yöntemi:** Flow kaynağı ve alarmların yönetim platformunda kaydedildiği kanıtlanır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (SI-4), CIS monitoring
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 13/3 (iz kayıtları düzenli izlenmeli, şüpheli işlemler derhal incelenmeli), CBDDO 3.1.8.x (iz kayıtlarının izlenmesi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG06-05 — Ağ değişikliklerinde önceden onay ve sürüm kaydı zorunluluğu var mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Yanlış VLAN veya ACL değişikliklerinin önünü kesmek.
- **Olası Riskler:** Yetkisiz erişim ve anlık network outage.
- **Beklenen Kanıt:** Change ticketları, network config değişiklik diff kayıtları
- **Kanıta Ulaşım Yöntemi:** Son 6 ay değişiklikleri çekilir, yetkisiz/tek kişilik değişiklikler işaretlenir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (CM-3), CIS network config controls
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 24/1 (değişiklik yönetimi prosedürü, yetkili onayı), BDDK-BSY Md. 24/3 (acil değişikliklerin sonradan onayı ve iz kaydı)
- **İyi Uygulama (Standart/Baseline):** ISO/IEC 27001:2022 Ek A A.8.32 (değişiklik yönetimi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG06-06 — Donanım ve switch ekosistemi ile vDS uyumluluk testleri düzenli mi?

**Öncelik:** Düşük · **Test Yöntemi:** Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Fiziksel ve sanal ağ politikası uyuşmazlıklarını önlemek.
- **Olası Riskler:** Uyum hatasıyla kritik bağlantı kopuşları.
- **Beklenen Kanıt:** Uyum test raporları, patch öncesi/sonrası konfig farkları
- **Kanıta Ulaşım Yöntemi:** Değişiklik öncesi-sonrası karşılaştırma dosyaları talep edilir ve kritik servis etkisi sorgulanır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (SI-4), CIS vSphere network best practices
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.1 (kararlı sürümler, uyumluluk takibi), BDDK-BSY Md. 24/1 (değişiklik yönetimi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG06-07 — Distributed Switch: Distributed Port Group yapılandırmasında promiscuous mode gereksizse Reject mi?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-05 · **İlişkili üst kontrol:** `KG06-01`

- **Denetim Amacı:** Promiscuous mode'un gereksiz yerlerde kapalı olmasını doğrulamak.
- **Olası Riskler:** VM kendisine ait olmayan trafiği dinleyebilir. + RISK-C + RISK-B
- **Beklenen Kanıt:** VDS/dvPortgroup security policy ve override exportu.
- **Kanıta Ulaşım Yöntemi:** vSphere Networking envanterinde VDS ve dvPortgroup security/VLAN nesnelerini okuyun. Inherited/override ayrımını ve port düzeyindeki istisnaları gösterin; MAC değişimi, forged transmits ve promiscuous değerlerini ayrı alın.
- **Kabul Ölçütleri:** SCG baseline değerine göre Reject; zorunlu appliance istisnası dar kapsamlı ve onaylı olmalı.
- **İnceleme ve Test Adımları:** Üst politika ile port override'larını birlikte kontrol et. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** VDS/dvPortgroup security policy ve override exportu. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-4

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VMW-SCG: vcenter-8.network-reject-promiscuous-mode-dvportgroup; NIST-53: AC-4; SC-7; BIGR: 3.1.9.7 | 3.1.9.7 — basılı s.61 / PDF 65
- **Teknik Referanslar:** VMW-SCG: vcenter-8.network-reject-promiscuous-mode-dvportgroup; NIST-53: AC-4; SC-7; BIGR: 3.1.9.7 | 3.1.9.7 — basılı s.61 / PDF 65; VMW-SCG kaynak varyantları: vcenter-8.network-reject-promiscuous-mode-dvportgroup. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** VMW-SCG; NIST-ASSESS
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG06-08 — Distributed Switch: Distributed Port Group yapılandırmasında forged transmits gereksizse Reject mi?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-06 · **İlişkili üst kontrol:** `KG06-01`

- **Denetim Amacı:** Forged transmits'in gereksiz yerlerde kapalı olmasını doğrulamak.
- **Olası Riskler:** Sahte kaynak MAC ile kimlik taklidi veya trafik yönlendirme yapılabilir. + RISK-C + RISK-B
- **Beklenen Kanıt:** Forged transmits politika/override ayarları.
- **Kanıta Ulaşım Yöntemi:** vSphere Networking envanterinde VDS ve dvPortgroup security/VLAN nesnelerini okuyun. Inherited/override ayrımını ve port düzeyindeki istisnaları gösterin; MAC değişimi, forged transmits ve promiscuous değerlerini ayrı alın.
- **Kabul Ölçütleri:** SCG baseline değerine göre Reject; ihtiyaç varsa sınırlı istisna bulunmalı.
- **İnceleme ve Test Adımları:** Her tenant port grubu (port group)nda etkin değeri kontrol et; appliance istisnasını mimariyle eşleştir. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** Forged transmits politika/override ayarları. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-4

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VMW-SCG: vcenter-8.network-reject-forged-transmit-dvportgroup; NIST-53: AC-4; SC-7; BIGR: 3.1.9.7 | 3.1.9.7 — basılı s.61 / PDF 65
- **Teknik Referanslar:** VMW-SCG: vcenter-8.network-reject-forged-transmit-dvportgroup; NIST-53: AC-4; SC-7; BIGR: 3.1.9.7 | 3.1.9.7 — basılı s.61 / PDF 65; VMW-SCG kaynak varyantları: vcenter-8.network-reject-forged-transmit-dvportgroup. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** VMW-SCG; NIST-ASSESS
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG06-09 — Distributed Switch: Distributed Port Group yapılandırmasında MAC address changes gereksizse Reject mi?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-07 · **İlişkili üst kontrol:** `KG06-01`

- **Denetim Amacı:** MAC address changes'in gereksiz yerlerde kapalı olmasını doğrulamak.
- **Olası Riskler:** Guest MAC değişikliği ağ kimliğini ve kontrolleri atlatabilir. + RISK-C + RISK-B
- **Beklenen Kanıt:** MAC changes etkin ayarı, override ve değişiklik onayı.
- **Kanıta Ulaşım Yöntemi:** vSphere Networking envanterinde VDS ve dvPortgroup security/VLAN nesnelerini okuyun. Inherited/override ayrımını ve port düzeyindeki istisnaları gösterin; MAC değişimi, forged transmits ve promiscuous değerlerini ayrı alın.
- **Kabul Ölçütleri:** SCG baseline değerine göre Reject; meşru HA ihtiyacı varsa istisna kontrollü olmalı.
- **İnceleme ve Test Adımları:** Port grubu ve port düzeyindeki kalıtımı karşılaştır. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** MAC changes etkin ayarı, override ve değişiklik onayı. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-4

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VMW-SCG: vcenter-8.network-reject-mac-changes-dvportgroup; NIST-53: AC-4; SC-7; BIGR: 3.1.9.7 | 3.1.9.7 — basılı s.61 / PDF 65
- **Teknik Referanslar:** VMW-SCG: vcenter-8.network-reject-mac-changes-dvportgroup; NIST-53: AC-4; SC-7; BIGR: 3.1.9.7 | 3.1.9.7 — basılı s.61 / PDF 65; VMW-SCG kaynak varyantları: vcenter-8.network-reject-mac-changes-dvportgroup. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** VMW-SCG; NIST-ASSESS
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG06-10 — Distributed Switch: VLAN/trunk aralıkları her tenant için gerekli ağlarla sınırlandırılmış mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-08 · **İlişkili üst kontrol:** `KG06-02`

- **Denetim Amacı:** VLAN/trunk sınırının yetkili ağ matrisiyle uyumunu doğrulamak.
- **Olası Riskler:** Geniş trunk bir müşteriye başka müşterinin VLAN'ını açabilir. + RISK-C + RISK-B
- **Beklenen Kanıt:** VLAN/trunk listesi, uplink fiziksel switch ayarları.
- **Kanıta Ulaşım Yöntemi:** vSphere Networking envanterinde VDS ve dvPortgroup security/VLAN nesnelerini okuyun. Inherited/override ayrımını ve port düzeyindeki istisnaları gösterin; MAC değişimi, forged transmits ve promiscuous değerlerini ayrı alın.
- **Kabul Ölçütleri:** Port grubu VLAN/trunk ve uplink tasarımı yetkili ağ matrisiyle sınırlı olmalı.
- **İnceleme ve Test Adımları:** Mantıksal ve fiziksel uçları karşılaştır; yanlış VLAN erişimini güvenli test et. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** VLAN/trunk listesi, uplink fiziksel switch ayarları. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-4

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST-53: SC-7; NIST-53: AC-4; SC-7; BIGR: 4.3.1.4 | 4.3.1.4 — basılı s.164 / PDF 168
- **Teknik Referanslar:** NIST-53: SC-7; NIST-53: AC-4; SC-7; BIGR: 4.3.1.4 | 4.3.1.4 — basılı s.164 / PDF 168; VMW-SCG kaynak varyantları: vcenter-8.network-vgt. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** VMW-SCG; NIST-ASSESS
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG06-11 — Distributed Switch: Port mirroring ve trafik yakalama (traffic capture) yetkileri kontrollü mü?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-09 · **İlişkili üst kontrol:** `KG06-04`

- **Denetim Amacı:** Trafik yakalama yetkilerinin kontrollü olmasını doğrulamak.
- **Olası Riskler:** Müşteri trafiği başka bir dinleme noktasına gizlice kopyalanabilir. + RISK-C + RISK-B
- **Beklenen Kanıt:** Mirror oturumları, hedef portlar, onay ve saklama kaydı.
- **Kanıta Ulaşım Yöntemi:** İlgili VDS üzerinde Port Mirroring, Health Check veya NetFlow yapılandırma nesnesini salt okunur (read-only) görüntüleyin. Oturum/collector kimliğini izinli hedef ve geçerli işletim gerekçesiyle eşleştirin.
- **Kabul Ölçütleri:** Yalnız onaylı hedef/süre; yakalama verisi erişimi sınırlı olmalı.
- **İnceleme ve Test Adımları:** Etkin oturumları yetki ve iş emriyle eşleştir. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** Mirror oturumları, hedef portlar, onay ve saklama kaydı. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-4

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST-53: AC-6, SC-7; NIST-53: AC-6; AU-9; BIGR: 3.1.9.7 | 3.1.9.7 — basılı s.61 / PDF 65
- **Teknik Referanslar:** NIST-53: AC-6, SC-7; NIST-53: AC-6; AU-9; BIGR: 3.1.9.7 | 3.1.9.7 — basılı s.61 / PDF 65; VMW-SCG kaynak varyantları: vcenter-8.network-restrict-port-mirroring. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** VMW-SCG; NIST-ASSESS
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG06-12 — Distributed Switch: Distributed Port Group yapılandırmasında MAC Learning yalnız belgeli işlev ihtiyacı için etkin mi?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) · **Kaynak:** G2-10 · **İlişkili üst kontrol:** `KG06-01`

- **Denetim Amacı:** MAC Learning'in belgeli ihtiyaç dışında kapalı olmasını doğrulamak.
- **Olası Riskler:** Gereksiz MAC öğrenimi tenant portunun beklenmeyen adreslerle iletişim kurmasına yol açabilir; nested sanallaştırma ihtiyacı ile sıradan VM portu ayrılmalıdır.
- **Beklenen Kanıt:** Hedef nesne/sürüm bilgisi ve Distributed Switch Port Group Settings etkin ayar çıktısı; onaylı baseline ve istisnalar.
- **Kanıta Ulaşım Yöntemi:** SCG-RO(Distributed Switch Port Group Settings)
- **Kabul Ölçütleri:** SCG vSphere 8 U3 profili seçilmişse: network-mac-learning = Disabled. Başka sürüm veya kaynak profiline otomatik uygulanmaz.
- **İnceleme ve Test Adımları:** TEST-1
- **İncelenecek Kayıtlar ve Örnekleme:** Hedef nesne/sürüm bilgisi ve Distributed Switch Port Group Settings etkin ayar çıktısı; onaylı baseline ve istisnalar. + KAYIT-B2
- **Kanıtın Sınırları:** SINIR-2

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VMW-SCG: vcenter-8.network-mac-learning
- **Teknik Referanslar:** VMW-SCG: vcenter-8.network-mac-learning; VMW-SCG kaynak varyantları: vcenter-8.network-mac-learning. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** VMW-SCG: vcenter-8.network-mac-learning
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG06-13 — Distributed Switch: VM porttan ayrıldığında port yapılandırması sıfırlanıyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) · **Kaynak:** G2-11 · **İlişkili üst kontrol:** `KG06-01`

- **Denetim Amacı:** Port yapılandırmasının sıfırlanmasını doğrulamak.
- **Olası Riskler:** Başka müşterinin VM'si yeniden kullanılan porta bağlandığında önceki port istisnasını devralabilir.
- **Beklenen Kanıt:** Hedef nesne/sürüm bilgisi ve Distributed Switch Settings etkin ayar çıktısı; onaylı baseline ve istisnalar.
- **Kanıta Ulaşım Yöntemi:** SCG-RO(Distributed Switch Settings)
- **Kabul Ölçütleri:** SCG vSphere 8 U3 profili seçilmişse: network-reset-port = Enabled. Başka sürüm veya kaynak profiline otomatik uygulanmaz.
- **İnceleme ve Test Adımları:** TEST-1
- **İncelenecek Kayıtlar ve Örnekleme:** Hedef nesne/sürüm bilgisi ve Distributed Switch Settings etkin ayar çıktısı; onaylı baseline ve istisnalar. + KAYIT-B2
- **Kanıtın Sınırları:** SINIR-2

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VMW-SCG: vcenter-8.network-reset-port
- **Teknik Referanslar:** VMW-SCG: vcenter-8.network-reset-port; VMW-SCG kaynak varyantları: vcenter-8.network-reset-port. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** VMW-SCG: vcenter-8.network-reset-port
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG06-14 — Distributed Switch: Port düzeyi override ile port grubu (port group) güvenlik politikası aşılabiliyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) · **Kaynak:** G2-12 · **İlişkili üst kontrol:** `KG06-01`

- **Denetim Amacı:** Port düzeyi override'ların kısıtlanmasını doğrulamak.
- **Olası Riskler:** Port grubunda görülen güvenli baseline tek bir dvPort üzerindeki istisnayla geçersiz hale gelebilir; yalnız grup çıktısı izolasyonu kanıtlamaz.
- **Beklenen Kanıt:** Hedef nesne/sürüm bilgisi ve Distributed Switch Port Group Settings etkin ayar çıktısı; onaylı baseline ve istisnalar.
- **Kanıta Ulaşım Yöntemi:** SCG-RO(Distributed Switch Port Group Settings)
- **Kabul Ölçütleri:** SCG baseline değeri Block Ports Override=true, diğer override seçenekleri=false. Grup ve tekil port etkin ayarı birlikte kontrol edilmeli; istisna açıkça onaylı olmalı.
- **İnceleme ve Test Adımları:** TEST-1
- **İncelenecek Kayıtlar ve Örnekleme:** Hedef nesne/sürüm bilgisi ve Distributed Switch Port Group Settings etkin ayar çıktısı; onaylı baseline ve istisnalar. + KAYIT-B2
- **Kanıtın Sınırları:** SINIR-2

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VMW-SCG: vcenter-8.network-restrict-port-level-overrides
- **Teknik Referanslar:** VMW-SCG: vcenter-8.network-restrict-port-level-overrides; VMW-SCG kaynak varyantları: vcenter-8.network-restrict-port-level-overrides. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** VMW-SCG: vcenter-8.network-restrict-port-level-overrides
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG06-15 — Distributed Switch: VDS NetFlow hedefi kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-13 · **İlişkili üst kontrol:** `KG06-04`

- **Denetim Amacı:** NetFlow hedeflerinin onaylı toplayıcıyla sınırlı olmasını doğrulamak.
- **Olası Riskler:** Müşteri ağ metadata'sı yetkisiz toplayıcıya aktarılabilir. + RISK-C + RISK-B
- **Beklenen Kanıt:** VDS NetFlow exporter/hedef ayarı ve toplayıcı yetki/kayıt örneği.
- **Kanıta Ulaşım Yöntemi:** İlgili VDS üzerinde Port Mirroring, Health Check veya NetFlow yapılandırma nesnesini salt okunur (read-only) görüntüleyin. Oturum/collector kimliğini izinli hedef ve geçerli işletim gerekçesiyle eşleştirin.
- **Kabul Ölçütleri:** NetFlow kullanılıyorsa akış kayıtları yalnız onaylı toplayıcıya gönderilmeli.
- **İnceleme ve Test Adımları:** Hedef IP ve collector kimliğini onaylı izleme mimarisiyle eşleştir. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** VDS NetFlow exporter/hedef ayarı ve toplayıcı yetki/kayıt örneği. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-4

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX7:7.7
- **Teknik Referanslar:** CIS-ESX7:7.7 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.; VMW-SCG kaynak varyantları: vcenter-8.network-restrict-netflow-usage. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** VMW-SCG; NIST-ASSESS
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG06-16 — Distributed Switch: VDS health check kullanımı kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı · **Kaynak:** G3-01 · **İlişkili üst kontrol:** `KG06-06`

- **Denetim Amacı:** VDS health check'in varsayılan kapalı olmasını doğrulamak.
- **Olası Riskler:** — (kaynak metin kırpıldı)
- **Beklenen Kanıt:** — (kaynak metin kırpıldı)
- **Kanıta Ulaşım Yöntemi:** — (kaynak metin kırpıldı)
- **Kabul Ölçütleri:** CIS ESXi 7 baseline değerine göre VDS health check kapalı olmalı; onaylı sorun giderme kullanımı süreli sapma olarak kaydedilir.
- **İnceleme ve Test Adımları:** — (kaynak metin kırpıldı)
- **İncelenecek Kayıtlar ve Örnekleme:** — (kaynak metin kırpıldı)
- **Kanıtın Sınırları:** — (kaynak metin kırpıldı)

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** — (kaynak metin kırpıldı)
- **Teknik Referanslar:** — (kaynak metin kırpıldı)
- **Erişim Referansları:** — (kaynak metin kırpıldı)
- **Denetim Yöntemi Referansları:** — (kaynak metin kırpıldı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

