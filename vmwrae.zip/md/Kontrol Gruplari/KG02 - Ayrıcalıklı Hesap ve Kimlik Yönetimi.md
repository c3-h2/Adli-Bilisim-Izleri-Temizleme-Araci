# KG02 - Ayrıcalıklı Hesap ve Kimlik Yönetimi

**Çalışma:** VMware MSP Denetimi · **Sürüm:** v4 — 14 Eylül 2026  
**Doküman:** Kontrol grubu çalışma listesi — 19 kontrol  
**Hazırlayan:** KKB İç Denetim Başkanlığı — BT Denetimi (danışmanlık çıktısıdır, son karar denetçinindir)  
**Ana dizin:** `00 - Ana Dizin ve Dokuman Haritasi.xlsx`

---

> Uyumsuzluk hükmü yalnızca **Bağlayıcı Kriter (Mevzuat)** alanındaki maddeye atıfla verilebilir. **İyi Uygulama** alanı tek başına uyumsuzluk dayanağı değildir. Terim ve kısaltmalar için `03 - Terimler` ve `04 - Kisaltmalar` dokümanlarına, metodoloji için `01 - Kapsam ve Metodoloji` dokümanına bakınız.

| Kontrol ID | Denetim Sorusu | Öncelik | Test Yöntemi | Kaynak |
|---|---|---|---|---|
| `KG02-01` | Ayrıcalıklı hesap envanteri (vCenter/ESXi/NSX/vCloud) güncel ve merkezi olarak izleniyor mu? | Yüksek | Güvenlik Denetimi + Doküman İncelemesi | 12 KG |
| `KG02-02` | Ayrıcalıklı hesaplar için MFA zorunlu mu ve atlatma (bypass) durumu izleniyor mu? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG02-03` | Least privilege ilkesine göre role dayalı ayırma uygulanıyor mu, gereksiz yüksek yetkili hesaplar minimize edilmiş mi? | Yüksek | Güvenlik Denetimi + Doküman İncelemesi | 12 KG |
| `KG02-04` | Servis hesapları için parola/anahtar yönetimi (key management) ve saklama politikası uygulanıyor mu? | Yüksek | Güvenlik Denetimi + Doküman İncelemesi | 12 KG |
| `KG02-05` | Ayrıcalıklı işlemlerde ikili onay (dual authorization) veya denetimce onay hattı bulunuyor mu? | Orta | Doküman İncelemesi + Güvenlik Denetimi | 12 KG |
| `KG02-06` | Ayrıcalıklı hesaplarda oturum başarısızlıkları ve anomali girişimleri SIEM'de filtreleniyor mu? | Orta | Güvenlik Denetimi | 12 KG |
| `KG02-07` | Cloud Director: Organizasyonun yerel hesap (local account) kilitleme (account lockout) politikası tanımlı ve uygulanıyor mu? | Yüksek | Yapılandırma İncelemesi (Configuration Review) | EK G1-01 |
| `KG02-08` | ESXi: Host Password Complexity kontrolü, kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-06 |
| `KG02-09` | ESXi: Account Lockout Threshold ve Account Lockout Duration ayarları kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-07 |
| `KG02-10` | ESXi: Password History kontrolü, kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-08 |
| `KG02-11` | ESXi: Password Maximum Age ayarı onaylı parola politikasını karşılıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-09 |
| `KG02-12` | ESXi: Servis hesaplarının shell yetkisi kontrolü, kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-12 |
| `KG02-13` | ESXi: ESXi 7 AD katılımı ve yönetici grubu (administrator group) kontrolü, kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-18 |
| `KG02-14` | ESXi: ESXi 7 kişisel yerel yönetici hesabı kontrolü, kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-19 |
| `KG02-15` | ESXi: ESXi 7 SSH authorized_keys kontrolü, kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-20 |
| `KG02-16` | ESXi: AD etki alanına host katılımı sırasında yeniden kullanılan yönetici parolaları otomasyonda saklanıyor mu? | Orta | Yapılandırma İncelemesi (Configuration Review) | EK G1-21 |
| `KG02-17` | NSX: NSX sertifikalı otomasyon kimlikleri (principal identity) en az yetki (least privilege) ve gerekli nesne yollarıyla sınırlı mı? | Yüksek | Yapılandırma İncelemesi (Configuration Review) | EK G1-23 |
| `KG02-18` | vCenter: Yerel SSO başarısız giriş (failed login) sayımı, hesap kilidi (account lockout) ve kilit açılması (account unlock) birlikte doğrulanıyor mu? | Yüksek | Yapılandırma İncelemesi (Configuration Review) | EK G1-25 |
| `KG02-19` | vCenter: VCSA root hesabının parola ömrü (password maximum age) ve acil erişim işleyişi onaylı kimlik politikasına bağlı mı? | Orta | Yapılandırma İncelemesi (Configuration Review) | EK G1-27 |

## KG02-01 — Ayrıcalıklı hesap envanteri (vCenter/ESXi/NSX/vCloud) güncel ve merkezi olarak izleniyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi + Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Yönetim hesabı kontrolsüz artışını önleyip görünürlüğü artırmak.
- **Olası Riskler:** Kalan hesaplarla yetki sızması, eski hesapların kötüye kullanımı, izinsiz erişim.
- **Beklenen Kanıt:** Envanter listesi, kimlik yaşam döngüsü kayıtları, deaktif hesap raporları
- **Kanıta Ulaşım Yöntemi:** IAM platformu ile vCenter kimlik veritabanı karşılaştırılır, eski/aktif hesabın ayrımı gösterilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (IA-2), CIS Hypervisor Security, CIS vCenter Best Practice
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 11/6 (kullanıcılar yılda en az bir kez bilgi varlığı sahibi tarafından gözden geçirilir, en az yetki)
- **İyi Uygulama (Standart/Baseline):** NIST SP 800-53 Rev.5 AC-2(11) (hesap kullanım koşulları, hesap izleme uyarıları), ISO/IEC 27002:2022 5.18 (erişim haklarının merkezi kaydı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG02-02 — Ayrıcalıklı hesaplar için MFA zorunlu mu ve atlatma (bypass) durumu izleniyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Kimlik bilgisi sızıntısı sonrası yönetim katmanını korumak.
- **Olası Riskler:** Tek faktörlü oturumla yönetim panel ele geçirilmesi.
- **Beklenen Kanıt:** MFA yapılandırma ekran görüntüleri, policy tanımı, hata ve bypass logları
- **Kanıta Ulaşım Yöntemi:** Kimlik sağlayıcı logları ve vCenter SSO ayarları karşılaştırılır, 2FA politikası dışındaki oturumlar test edilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-63B, NIST SP 800-53 (IA-2(2), IA-5), CIS identity hardening
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 14/7 (uzaktan erişimde çok bileşenli kimlik doğrulama zorunluluğu)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG02-03 — Least privilege ilkesine göre role dayalı ayırma uygulanıyor mu, gereksiz yüksek yetkili hesaplar minimize edilmiş mi?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi + Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Yönetim yetkilerinin iş rolü dışına taşmamasını sağlamak.
- **Olası Riskler:** Normal kullanıcı hesaplarının yönetim haklarıyla genişleme riski.
- **Beklenen Kanıt:** RBAC rol listeleri, role-change logları, periyodik access review çıktıları
- **Kanıta Ulaşım Yöntemi:** RBAC map dosyası alınır, yetkiler iş tanımlarıyla karşılaştırılır, gereksiz admin/root düzeyi hesaplar işaretlenir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (AC-6), CIS vCenter Hardening
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 11/6 (sadece görevleri yerine getirmeye yetecek ve sadece bilmesi gereken verilere erişim)
- **İyi Uygulama (Standart/Baseline):** NIST SP 800-53 Rev.5 AC-2(11) (en az yetki ilkesi), ISO/IEC 27002:2022 5.18 (görevler ayrılığı, ayrıcalıklı erişim yetkilendirmeleri)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG02-04 — Servis hesapları için parola/anahtar yönetimi (key management) ve saklama politikası uygulanıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi + Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Gizli kimlik bilgileri üzerinden kalıcı ele geçirme riskini azaltmak.
- **Olası Riskler:** Ortak/uzun süreli anahtarlar, eski token'ların geçerliliğini sürdürmesi.
- **Beklenen Kanıt:** Secret manager/vault logları, yetki ve rotasyon kayıtları
- **Kanıta Ulaşım Yöntemi:** Servis hesapları envanteri çıkarılır, parola/anahtar son güncelleme tarihleri ve erişim kısıtları doğrulanır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-57, NIST SP 800-53 (IA-5), CIS credential protection
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 9/2 (şifreleme anahtarlarının yaşam döngüsü boyunca güvenliği, geçerlilik süresi dolan anahtarların derhal engellenmesi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG02-05 — Ayrıcalıklı işlemlerde ikili onay (dual authorization) veya denetimce onay hattı bulunuyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Tek kişilik yüksek etkili işlem riskini azaltmak.
- **Olası Riskler:** Yetkisiz snapshot silme, politika by-pass, yanlış firewall değişikliği.
- **Beklenen Kanıt:** Kritik işlem akış şeması, onay kayıtları, işlem sonrası doğrulama logları
- **Kanıta Ulaşım Yöntemi:** Kritik event listesi örneklenir, her işlem için oluşturma onayı ve kapatma onayı eşlenir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (AC-3, AU-12), CIS privileged access guidance
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 24/1 (değişikliklerin yetkili tarafından onaylanması)
- **İyi Uygulama (Standart/Baseline):** NIST SP 800-53B Tablo 3-5 (CM-5(4) DUAL AUTHORIZATION - yalnızca HIGH taban, MOD'da yok)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG02-06 — Ayrıcalıklı hesaplarda oturum başarısızlıkları ve anomali girişimleri SIEM'de filtreleniyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Erken uyarı alarak kötüye kullanımın hızını düşürmek.
- **Olası Riskler:** Hesap ele geçirme girişimleri geç fark edilip yetki kötüye kullanılabilir.
- **Beklenen Kanıt:** Login failure logları, SIEM kuralları, anomali bildirimleri
- **Kanıta Ulaşım Yöntemi:** Son 90 günlük loglarda yönetici hesapları için başarısız giriş (failed login)imler, imzasız IP, zamansız saat dilimi anormalliği raporlanır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (AU-6, AU-12), CIS Logging
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 13/3 (iz kayıtları düzenli izlenmeli, şüpheli işlemler derhal incelenmeli, olaylar bilgi güvenliği sorumlusuna bildirilmeli)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG02-07 — Cloud Director: Organizasyonun yerel hesap (local account) kilitleme (account lockout) politikası tanımlı ve uygulanıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) · **Kaynak:** G1-01 · **İlişkili üst kontrol:** `KG02-06`

- **Denetim Amacı:** Yerel hesap kilitleme (account lockout) politikasının tanımlı ve uygulanıyor olmasını doğrulamak.
- **Olası Riskler:** Tek tenantın zayıf yerel hesabı katalog/veri işlemlerine erişim sağlayabilir; ortak kimlik sağlayıcı (identity provider / IdP)sı varlığı yerel hesabı otomatik korumaz.
- **Beklenen Kanıt:** Organizasyon password policy çıktısı ve mevcut giriş olayları.
- **Kanıta Ulaşım Yöntemi:** Cloud Director API GET /admin/org/{id}/settings/passwordPolicy; API temel adresi ve yetkili organizasyon bağlamıyla okuyun.
- **Kabul Ölçütleri:** AccountLockoutEnabled, InvalidLoginsBeforeLockout ve AccountLockoutIntervalMinutes onaylı politika ile karşılaştırılmalı, federasyon politikası ayrıca değerlendirilir.
- **İnceleme ve Test Adımları:** TEST-1
- **İncelenecek Kayıtlar ve Örnekleme:** Organizasyon password policy çıktısı ve mevcut giriş olayları. + KAYIT-B2
- **Kanıtın Sınırları:** SINIR-2

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VCD-LOCK: OrgPasswordPolicySettingsType; NIST-53: AC-7
- **Teknik Referanslar:** VCD-LOCK: OrgPasswordPolicySettingsType; NIST-53: AC-7
- **Erişim Referansları:** VCD-LOCK: OrgPasswordPolicySettingsType; NIST-53: AC-7
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG02-08 — ESXi: Host Password Complexity kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-06 · **İlişkili üst kontrol:** `KG02-04`

- **Denetim Amacı:** Yerel parola karmaşıklığı (password complexity)nın sürüm bazlı eşikleri karşıladığını doğrulamak.
- **Olası Riskler:** Zayıf yerel parola merkezi kimlik denetiminden bağımsız host ele geçirmeye izin verebilir. + RISK-B
- **Beklenen Kanıt:** PasswordQualityControl etkin değeri, yerel hesap (local account) kapsamı, kurumsal parola politikası.
- **Kanıta Ulaşım Yöntemi:** AS-ADV
- **Kabul Ölçütleri:** Security.PasswordQualityControl: ESXi 7 CIS 4.2 için N0–N3 disabled ve N4≥14, ESXi 8 CIS 3.11 için N0–N3 disabled ve N4≥15. retry ve min alanlarını ayır. Parola metni kanıt olarak toplanmaz.
- **İnceleme ve Test Adımları:** Etkin PasswordQualityControl ifadesini kurulu sürümün ayrı min dizisiyle karşılaştır; sadece uzunluğu değil disabled alanlarını da doğrula. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** PasswordQualityControl etkin değeri, yerel hesap (local account) kapsamı, kurumsal parola politikası. + KAYIT-B
- **Kanıtın Sınırları:** Bazı entegrasyonlar karmaşıklık değişikliğinden etkilenebilir. + SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:3.11; CIS-ESX7:4.2
- **Teknik Referanslar:** CIS-ESX8:3.11; CIS-ESX7:4.2 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.; VMW-SCG kaynak varyantları: esxi-8.account-password-policies. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG02-09 — ESXi: Account Lockout Threshold ve Account Lockout Duration ayarları kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-07 · **İlişkili üst kontrol:** `KG02-06`

- **Denetim Amacı:** Başarısız giriş denemelerinde hesap kilitleme (account lockout)nin etkin olmasını doğrulamak.
- **Olası Riskler:** Sınırsız denemeler parola saldırısını kolaylaştırır; aşırı kilitleme ise yönetim erişimini kesebilir. + RISK-B
- **Beklenen Kanıt:** İki ayarın etkin değerleri, başarısız giriş (failed login)/kilit olayları.
- **Kanıta Ulaşım Yöntemi:** AS-ADV
- **Kabul Ölçütleri:** Security.AccountLockFailures=5 ve Security.AccountUnlockTime=900 saniye olmalı, istisna varsa CIS sapması olarak ayrıca yazılmalı.
- **İnceleme ve Test Adımları:** Değerlerin birimini kontrol et; test hesabında onaylı senaryo ile kilit ve açılma davranışını doğrula. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** İki ayarın etkin değerleri, başarısız giriş (failed login)/kilit olayları. + KAYIT-B
- **Kanıtın Sınırları:** Canlı ayrıcalıklı hesap (privileged account)ta deneme yapma; kilitlenme hizmet müdahalesini etkileyebilir. + SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:3.12; CIS-ESX8:3.13; CIS-ESX7:4.3; CIS-ESX7:4.4
- **Teknik Referanslar:** CIS-ESX8:3.12; CIS-ESX8:3.13; CIS-ESX7:4.3; CIS-ESX7:4.4 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.; VMW-SCG kaynak varyantları: esxi-8.account-auto-unlock-time, esxi-8.account-lockout. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG02-10 — ESXi: Password History kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-08 · **İlişkili üst kontrol:** `KG02-04`

- **Denetim Amacı:** Parola yeniden kullanımının sınırlandığını doğrulamak.
- **Olası Riskler:** Aynı yerel parolaya dönülmesi eski bir sır sızıntısının tekrar kullanılmasına imkan verir. + RISK-B
- **Beklenen Kanıt:** PasswordHistory ayarı ve hesap politikası.
- **Kanıta Ulaşım Yöntemi:** AS-ADV
- **Kabul Ölçütleri:** Security.PasswordHistory=5 olmalı, kabul edilen kurumsal sapma CIS uygunluğu yerine geçmez.
- **İnceleme ve Test Adımları:** Tüm farklı host baseline değerlerinde etkin değeri sorgula; parola değerlerini talep etme. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** PasswordHistory ayarı ve hesap politikası. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:3.14; CIS-ESX7:4.5
- **Teknik Referanslar:** CIS-ESX8:3.14; CIS-ESX7:4.5 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.; VMW-SCG kaynak varyantları: esxi-8.account-password-history. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG02-11 — ESXi: Password Maximum Age ayarı onaylı parola politikasını karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-09 · **İlişkili üst kontrol:** `KG02-04`

- **Denetim Amacı:** Parola yaşam döngüsünün onaylı politikaya bağlı olmasını doğrulamak.
- **Olası Riskler:** Tanımsız yaşam döngüsü, çalınmış veya süresi dolmuş sırların kontrolsüz kullanımını sürdürür. + RISK-B
- **Beklenen Kanıt:** Onaylı parola politikası ve PasswordMaxDays etkin değeri.
- **Kanıta Ulaşım Yöntemi:** AS-ADV
- **Kabul Ölçütleri:** Security.PasswordMaxDays kurumun onaylı politikasıyla uyumlu olmalı, periyodik değişim gerekmeyen politikada kaynak 99999 seçeneğini belirtir.
- **İnceleme ve Test Adımları:** Politika gereksinimi olmadan sayısal değer seçme; sızıntıda değişim sürecini ortak sır kontrolüne bağla. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** Onaylı parola politikası ve PasswordMaxDays etkin değeri. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:3.15
- **Teknik Referanslar:** CIS-ESX8:3.15 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.; VMW-SCG kaynak varyantları: esxi-8.account-password-max-days. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG02-12 — ESXi: Servis hesaplarının shell yetkisi kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-12 · **İlişkili üst kontrol:** `KG02-03`

- **Denetim Amacı:** Servis hesaplarının interaktif yetki kazanmasını engellemek.
- **Olası Riskler:** Servis kimliğinin interaktif yönetici hesabına dönüşmesi görev sınırını genişletir. + RISK-B
- **Beklenen Kanıt:** dcui/vpxuser etkin shell ve yetki ayarları.
- **Kanıta Ulaşım Yöntemi:** SVC-SEC
- **Kabul Ölçütleri:** dcui hesabında interaktif shell kapalı, vpxuser için L2 kapsamına göre shell kapalı olmalı.
- **İnceleme ve Test Adımları:** Kaynak profilini ve gerçek hesap ayarını karşılaştır; vCenter servisinin çalıştığını gözlem kanıtıyla teyit et. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** dcui/vpxuser etkin shell ve yetki ayarları. + KAYIT-B
- **Kanıtın Sınırları:** Üçüncü taraf yönetim iş akışları etkilenebilir. + SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:3.22; CIS-ESX8:3.23
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 11/6 (en az yetki; sadece görevleri yerine getirmeye yetecek yetki)
- **Teknik Referanslar:** CIS-ESX8:3.22; CIS-ESX8:3.23 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.; VMW-SCG kaynak varyantları: esxi-8.account-dcui, esxi-8.account-vpxuser. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG02-13 — ESXi: ESXi 7 AD katılımı ve yönetici grubu (administrator group) kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-18 · **İlişkili üst kontrol:** `KG02-03`

- **Denetim Amacı:** Merkezi kimlik modelinde yönetici grubu (administrator group)nun sınırlı olmasını doğrulamak.
- **Olası Riskler:** Geniş AD grup üyeliği beklenmeyen host yönetici yetkisi sağlayabilir. + RISK-B
- **Beklenen Kanıt:** AD join yöntemi, proxy kaydı, esxAdminsGroup yapılandırması ve gerçek AD üyeleri.
- **Kanıta Ulaşım Yöntemi:** AD-PERM
- **Kabul Ölçütleri:** Merkezi AD kimlik modeli uygulanıyorsa Authentication Proxy ile katılım ve esxAdminsGroup üyeliği yetkili hesaplarla sınırlı olmalı.
- **İnceleme ve Test Adımları:** Host ayarı ile AD grubu üyelerini birlikte incele; merkezi kimlik kullanım kararını mevcut mimariyle eşleştir. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** AD join yöntemi, proxy kaydı, esxAdminsGroup yapılandırması ve gerçek AD üyeleri. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX7:2.8; CIS-ESX7:4.6; CIS-ESX7:4.7
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 11/6 (yetkilendirme; yıllık gözden geçirme)
- **Teknik Referanslar:** CIS-ESX7:2.8; CIS-ESX7:4.6; CIS-ESX7:4.7 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG02-14 — ESXi: ESXi 7 kişisel yerel yönetici hesabı kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-19 · **İlişkili üst kontrol:** `KG02-01`

- **Denetim Amacı:** Ayrıcalıklı işlemlerde tekil kullanıcı sorumluluğunu doğrulamak.
- **Olası Riskler:** Ortak root işlemleri kişiye atanamaz; hesap sızıntısı bütün host yönetimini etkiler. + RISK-B
- **Beklenen Kanıt:** Host account/role listesi ve yönetim oturum kayıtları.
- **Kanıta Ulaşım Yöntemi:** AD-PERM
- **Kabul Ölçütleri:** Root dışında kişiye atanmış yetkili yerel yönetici erişim yolu bulunmalı, root günlük ortak hesap olarak kullanılmamalı.
- **İnceleme ve Test Adımları:** Hesap sahipliğini ve gerçek oturum kullanımını karşılaştır. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** Host account/role listesi ve yönetim oturum kayıtları. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX7:4.1
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 13/1-ç (iz kayıtları tekil kullanıcıyı göstermeli)
- **Teknik Referanslar:** CIS-ESX7:4.1 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG02-15 — ESXi: ESXi 7 SSH authorized_keys kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-20 · **İlişkili üst kontrol:** `KG02-04`

- **Denetim Amacı:** Merkezi erişim yönetimini atlayan anahtar girişlerini tespit etmek.
- **Olası Riskler:** Doğrudan anahtar ile giriş merkezi erişim ve parola yönetim yolunu atlayabilir. + RISK-B
- **Beklenen Kanıt:** authorized_keys içeriğinin sır içermeyen parmak izi/boşluk kanıtı; erişim istisnaları.
- **Kanıta Ulaşım Yöntemi:** SSH-FILES
- **Kabul Ölçütleri:** CIS ölçütü: authorized_keys boş olmalı. Onaylı anahtar bulunması kurumsal istisna olabilir ancak bu CIS maddesini geçmez.
- **İnceleme ve Test Adımları:** Dosyanın boşluğunu kontrol et; anahtarların sadece sahipli olmasını CIS uygunluğu sayma. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** authorized_keys içeriğinin sır içermeyen parmak izi/boşluk kanıtı. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX7:5.7
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.9 (sanallaştırma yönetim ortamına erişim kontrolü)
- **Teknik Referanslar:** CIS-ESX7:5.7 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG02-16 — ESXi: AD etki alanına host katılımı sırasında yeniden kullanılan yönetici parolaları otomasyonda saklanıyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) · **Kaynak:** G1-21 · **İlişkili üst kontrol:** `KG02-04`

- **Denetim Amacı:** Katılım otomasyonunda sır sızıntısı riskini doğrulamak.
- **Olası Riskler:** Dağıtım betiğinde tutulan etki alanı sırrı hostlar üzerinden dizin yetkisine erişim sağlayabilir; risk katılım hesabının gerçek yetkisiyle belirlenir.
- **Beklenen Kanıt:** Hedef nesne/sürüm bilgisi ve ESXi Authentication Settings etkin ayar çıktısı; onaylı baseline ve istisnalar.
- **Kanıta Ulaşım Yöntemi:** SCG-RO(ESXi Authentication Settings)
- **Kabul Ölçütleri:** Authentication Proxy kullanılan katılım akışında AD sırrı host/dağıtım betiğinde saklanmamalı, proxy yetkisi ve katılım kaydı onaylı kapsamla sınırlı olmalı. Özellik kullanılmıyorsa alternatif katılım yönteminin sır yönetimi ayrıca değerlendirilir.
- **İnceleme ve Test Adımları:** TEST-1
- **İncelenecek Kayıtlar ve Örnekleme:** Hedef nesne/sürüm bilgisi ve ESXi Authentication Settings etkin ayar çıktısı; onaylı baseline ve istisnalar. + KAYIT-B2
- **Kanıtın Sınırları:** SINIR-2

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VMW-SCG: esxi-8.ad-auth-proxy
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 9/2 (şifreleme anahtarlarının/sırların güvenli saklanması)
- **Teknik Referanslar:** VMW-SCG: esxi-8.ad-auth-proxy; VMW-SCG kaynak varyantları: esxi-8.ad-auth-proxy. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** VMW-SCG: esxi-8.ad-auth-proxy
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG02-17 — NSX: NSX sertifikalı otomasyon kimlikleri (principal identity) en az yetki (least privilege) ve gerekli nesne yollarıyla sınırlı mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) · **Kaynak:** G1-23 · **İlişkili üst kontrol:** `KG02-03`

- **Denetim Amacı:** Otomasyon kimliklerinin en az yetki (least privilege)yle sınırlandırılmasını doğrulamak.
- **Olası Riskler:** Bir entegrasyon sertifikasının sızması kök yol yetkisiyle tüm tenant ağlarına politika yazma imkânı sağlayabilir.
- **Beklenen Kanıt:** Principal identity listesi, sertifika metadata, rol/path yetkileri ve entegrasyon sahibi.
- **Kanıta Ulaşım Yöntemi:** GET /api/v1/trust-management/principal-identities; certificate_id ile güven deposu kaydını eşleştirin.
- **Kabul Ölçütleri:** Principal identity sahibi, certificate_id, role ve roles_for_paths onaylı otomasyon kapsamıyla uyumlu olmalı, kullanılmayan entegrasyon kimliği açıklanmalı.
- **İnceleme ve Test Adımları:** TEST-1
- **İncelenecek Kayıtlar ve Örnekleme:** Principal identity listesi, sertifika metadata, rol/path yetkileri ve entegrasyon sahibi. + KAYIT-B2
- **Kanıtın Sınırları:** SINIR-2

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NSX-PI: PrincipalIdentityList; NIST-53: AC-6, IA-5
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 11/6 (en az yetki); CBDDO 4.3.1.4 (sertifikaların geçerlilik süreleri takip edilmeli)
- **Teknik Referanslar:** NSX-PI: PrincipalIdentityList; NIST-53: AC-6, IA-5
- **Erişim Referansları:** NSX-PI: PrincipalIdentityList; NIST-53: AC-6, IA-5
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG02-18 — vCenter: Yerel SSO başarısız giriş (failed login) sayımı, hesap kilidi (account lockout) ve kilit açılması (account unlock) birlikte doğrulanıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) · **Kaynak:** G1-25 · **İlişkili üst kontrol:** `KG02-06`

- **Denetim Amacı:** SSO hesap kilitleme (account lockout) politikasının etkinliğini doğrulamak.
- **Olası Riskler:** Kaba kuvvet veya hatalı kilit açma ayarı ortak yönetim hesabını ele geçirme ya da erişilemez kılma riskini büyütür.
- **Beklenen Kanıt:** Hedef nesne/sürüm bilgisi ve vCenter Server SSO Configuration etkin ayar çıktısı; onaylı baseline ve istisnalar.
- **Kanıta Ulaşım Yöntemi:** SCG-RO(vCenter Server SSO Configuration)
- **Kabul Ölçütleri:** SCG 8 U3: failed-login interval 900 saniye, maximum failed attempts 5, unlock time 0. Otomatik açılmama davranışı ve yetkili kilit açma süreci birlikte doğrulanır, haricî IdP politikası ayrı incelenir.
- **İnceleme ve Test Adımları:** TEST-1
- **İncelenecek Kayıtlar ve Örnekleme:** Hedef nesne/sürüm bilgisi ve vCenter Server SSO Configuration etkin ayar çıktısı; onaylı baseline ve istisnalar. + KAYIT-B2
- **Kanıtın Sınırları:** SINIR-2

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VMW-SCG: vcenter-8.administration-failed-login-interval, vcenter-8.administration-sso-lockout-policy-max-attempts, vcenter-8.administration-sso-lockout-policy-unlock-time
- **Teknik Referanslar:** VMW-SCG: vcenter-8.administration-failed-login-interval, vcenter-8.administration-sso-lockout-policy-max-attempts, vcenter-8.administration-sso-lockout-policy-unlock-time; VMW-SCG kaynak varyantları: aynı. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** VMW-SCG: vcenter-8.administration-failed-login-interval, vcenter-8.administration-sso-lockout-policy-max-attempts, vcenter-8.administration-sso-lockout-policy-unlock-time
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG02-19 — vCenter: VCSA root hesabının parola ömrü (password maximum age) ve acil erişim işleyişi onaylı kimlik politikasına bağlı mı?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) · **Kaynak:** G1-27 · **İlişkili üst kontrol:** `KG02-04`

- **Denetim Amacı:** Root parola yaşam döngüsünün onaylı politikaya bağlanmasını doğrulamak.
- **Olası Riskler:** Beklenmeyen parola sonlanması kurtarma erişimini engelleyebilir; süresiz fakat korunmayan parola da kalıcı ayrıcalıklı erişim oluşturabilir.
- **Beklenen Kanıt:** Hedef nesne/sürüm bilgisi ve vCenter Server Virtual Appliance Management Interface etkin ayar çıktısı; onaylı baseline ve istisnalar.
- **Kanıta Ulaşım Yöntemi:** SCG-RO(vCenter Server Virtual Appliance Management Interface)
- **Kabul Ölçütleri:** VAMI root parola ömrü (password maximum age) kurum politikasıyla gerekçeli olarak seçilmeli. SCG 8 U3 Password Expires=No önerisini başka standarttaki süre şartıyla eşdeğer saymayın, çelişki varsa uygulanacak profil onaylanmadan uygunluk sonucu vermeyin.
- **İnceleme ve Test Adımları:** TEST-1
- **İncelenecek Kayıtlar ve Örnekleme:** Hedef nesne/sürüm bilgisi ve vCenter Server Virtual Appliance Management Interface etkin ayar çıktısı; onaylı baseline ve istisnalar. + KAYIT-B2
- **Kanıtın Sınırları:** SINIR-2

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VMW-SCG: vcenter-8.vami-administration-password-expiration
- **Teknik Referanslar:** VMW-SCG: vcenter-8.vami-administration-password-expiration; VMW-SCG kaynak varyantları: aynı. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** VMW-SCG: vcenter-8.vami-administration-password-expiration
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

