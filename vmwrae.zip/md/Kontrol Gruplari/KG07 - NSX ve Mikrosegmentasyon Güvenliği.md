# KG07 - NSX ve Mikrosegmentasyon Güvenliği

**Çalışma:** VMware MSP Denetimi · **Sürüm:** v4 — 14 Eylül 2026  
**Doküman:** Kontrol grubu çalışma listesi — 11 kontrol  
**Hazırlayan:** KKB İç Denetim Başkanlığı — BT Denetimi (danışmanlık çıktısıdır, son karar denetçinindir)  
**Ana dizin:** `00 - Ana Dizin ve Dokuman Haritasi.xlsx`

---

> Uyumsuzluk hükmü yalnızca **Bağlayıcı Kriter (Mevzuat)** alanındaki maddeye atıfla verilebilir. **İyi Uygulama** alanı tek başına uyumsuzluk dayanağı değildir. Terim ve kısaltmalar için `03 - Terimler` ve `04 - Kisaltmalar` dokümanlarına, metodoloji için `01 - Kapsam ve Metodoloji` dokümanına bakınız.

| Kontrol ID | Denetim Sorusu | Öncelik | Test Yöntemi | Kaynak |
|---|---|---|---|---|
| `KG07-01` | NSX Manager ve Edge güvenlik tasarımı için sertifika, erişim ve yönetim hardening kuralları uygulanmış mı? | Yüksek | Güvenlik Denetimi + Doküman İncelemesi | 12 KG |
| `KG07-02` | Dağıtık firewall policy default deny mantığına uyuyor mu? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG07-03` | Mikrosegmentasyon için VM/Workload tag ve grup yönetimi operasyonel olarak güncelliğini koruyor mu? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG07-04` | Edge gateway NAT/DFW/WAF/IPS kuralları denetime açık ve dokümante mi? | Orta | Güvenlik Denetimi + Doküman İncelemesi | 12 KG |
| `KG07-05` | NSX servis zincirleri (service insertion) gerçek trafikte test edilip doğrulanmış mı? | Düşük | Güvenlik Denetimi | 12 KG |
| `KG07-06` | Olay kanıtlarının manipülasyona karşı korunması. | — | Orta | 12 KG |
| `KG07-07` | NSX: DFW politikaları izinli akış (allowed flow) dışındaki müşteri geçişlerini engelliyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-17 |
| `KG07-08` | NSX: NSX dinamik grupları (dynamic group) ve etiket atama (tag assignment) yetkileri doğru VM'leri kapsıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-18 |
| `KG07-09` | NSX: DFW exclusion list sadece onaylı sistemleri içeriyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-19 |
| `KG07-10` | NSX: Tier-0/Tier-1 ve gateway kuralları tenant rotalarının izinsiz birleşmesini engelliyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-20 |
| `KG07-11` | NSX: NSX SpoofGuard profili doğru segment/port ve IP bağlarıyla uygulanıyor mu? | Orta | Yapılandırma İncelemesi (Configuration Review) | EK G2-21 |

## KG07-01 — NSX Manager ve Edge güvenlik tasarımı için sertifika, erişim ve yönetim hardening kuralları uygulanmış mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi + Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Kontrol düzlemi kaynaklı bütün sistem riskini azaltmak.
- **Olası Riskler:** NSX'e saldırı ile çoklu güvenlik fonksiyonunun etkilenmesi.
- **Beklenen Kanıt:** NSX manager ayarları, sertifika envanteri, erişim politikası
- **Kanıta Ulaşım Yöntemi:** NSX admin konsolundan policy'ler alınır, erişim listesi ile üretim değişiklikleri eşlenir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS NSX Benchmark, NIST SP 800-53 (SC-7)
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.9 (sanallaştırma yönetim ortamına erişim kontrolü), CBDDO 4.3.1.2-7 (kripto algoritmaları ve sertifika yönetimi), BDDK-BSY Md. 11/6 (yetkilendirme)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG07-02 — Dağıtık firewall policy default deny mantığına uyuyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** 'Varsayılan açık' yaklaşımını engellemek.
- **Olası Riskler:** Geniş izin seti ile lateral movement.
- **Beklenen Kanıt:** DFW policy setleri, izin listeleri, deny-by-default testi
- **Kanıta Ulaşım Yöntemi:** Kurallara göre allow/deny oranları ve default action incelenir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (AC-4), CIS NSX policy controls
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.6.5 (izin verilmeyen trafiğin engellenmesi), BDDK-BSY Md. 14/2 (güvenlik duvarı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG07-03 — Mikrosegmentasyon için VM/Workload tag ve grup yönetimi operasyonel olarak güncelliğini koruyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Dinamik workload değişimlerinde yanlış segmentte kalan VM riskini azaltmak.
- **Olası Riskler:** Kural atlama ve yanlış policy eşleşmesi.
- **Beklenen Kanıt:** Tag envanteri, policy deployment geçmişi
- **Kanıta Ulaşım Yöntemi:** Etiket/segment ilişkisi export edilir, yeni onboard edilen VM'lerin doğru segmentte olup olmadığı doğrulanır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS NSX Security, NIST SP 800-53 (AC-3)
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.11 (sanal makineler arası trafik güvenlik kontrollerinden geçirilmeli, zararlı trafiğin yayılmasının önlenmesi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG07-04 — Edge gateway NAT/DFW/WAF/IPS kuralları denetime açık ve dokümante mi?

**Öncelik:** Orta · **Test Yöntemi:** Güvenlik Denetimi + Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Perimetre güvenliği ve trafik denetimini güçlü tutmak.
- **Olası Riskler:** Yanlış yönlendirme veya açık port kalıntıları (residual data).
- **Beklenen Kanıt:** Edge config export, NAT ve route tabloları, değişiklik geçmişi
- **Kanıta Ulaşım Yöntemi:** Kritik servislerde aktif rule'lar ve son güncelleme kayıtları doğrulanır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (SC-7, SC-12), CIS edge güvenlik önerileri
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 14/2 (güvenlik duvarı), CBDDO 3.1.6.x (ağ güvenliği tedbirleri)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG07-05 — NSX servis zincirleri (service insertion) gerçek trafikte test edilip doğrulanmış mı?

**Öncelik:** Düşük · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Güvenlik kontrol fonksiyonlarının kağıt üstünde kalmamasını sağlamak.
- **Olası Riskler:** Etkisiz NAT/firewall konfigürasyonu nedeniyle görünmeyen trafik açığı.
- **Beklenen Kanıt:** Test senaryoları, canary flow sonuçları, service chain status
- **Kanıta Ulaşım Yöntemi:** Test logları incelenir, policy uygulanmayan chain varsa risk yazılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (SI-4), CIS service chain operational docs
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 24/1 (değişikliklerin test edilmesi), CBDDO 3.1.9.11 (VM'ler arası trafik kontrolü)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG07-06 — Olay kanıtlarının manipülasyona karşı korunması.

**Öncelik:** — · **Test Yöntemi:** Orta · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Yanlış sıralı alarm ve delil ihlali.
- **Olası Riskler:** Log forward ayarları, imzalama/verify ayarları
- **Beklenen Kanıt:** Log taşıyıcı konfigürasyonu incelenir, log kaynağında hash/enforced integrity aktifse kontrol edilir.
- **Kanıta Ulaşım Yöntemi:** NIST SP 800-53 (AU-8, AU-9), CIS logging

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** BDDK-BSY Md. 13/1 (iz kayıtları asgari içerik: sistem, tarih/saat/zaman dilimi, değişiklik, tekil kullanıcı), CBDDO 5.1.1.11 (zaman senkronizasyonu)
- **İyi Uygulama (Standart/Baseline):** Güvenlik Denetimi

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG07-07 — NSX: DFW politikaları izinli akış (allowed flow) dışındaki müşteri geçişlerini engelliyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-17 · **İlişkili üst kontrol:** `KG07-02`

- **Denetim Amacı:** DFW politikalarının akış matrisiyle uyumunu doğrulamak.
- **Olası Riskler:** Doğu-batı trafiği üzerinden yatay hareket diğer müşterileri etkiler. + RISK-C + RISK-B
- **Beklenen Kanıt:** DFW rule exportu, Applied To kapsamı, akış matrisi.
- **Kanıta Ulaşım Yöntemi:** NSX Manager Security/Distributed Firewall politika nesneleri, Groups üyeliği ve Exclusion List görünümünü okuyun. Rule ID, sıra, Applied To ve gerçek üye VM kimliğini birlikte dışa aktarın. Kurulu NSX sürümünün ekran yerleşimi ayrıca teyit edilir.
- **Kabul Ölçütleri:** Kaynak/hedef/servis kapsamı onaylı akış matrisiyle aynı olmalı.
- **İnceleme ve Test Adımları:** İki tenant arasında izinli ve yasaklı akışları iki yönlü güvenli test et. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** DFW rule exportu, Applied To kapsamı, akış matrisi. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-4

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST-53: SC-7; BIGR: 4.3.1.4; NIST-53: AC-4; SC-7; BIGR: 3.1.9.11 | 3.1.9.11 — basılı s.62 / PDF 66
- **Teknik Referanslar:** NIST-53: SC-7; BIGR: 4.3.1.4; NIST-53: AC-4; SC-7; BIGR: 3.1.9.11 | 3.1.9.11 — basılı s.62 / PDF 66
- **Erişim Referansları:** VMW-NSX; NIST-ASSESS
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG07-08 — NSX: NSX dinamik grupları (dynamic group) ve etiket atama (tag assignment) yetkileri doğru VM'leri kapsıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-18 · **İlişkili üst kontrol:** `KG07-03`

- **Denetim Amacı:** Dinamik grup üyeliğinin envanterle mutabakatını doğrulamak.
- **Olası Riskler:** Yanlış etiket veya grup ifadesi koruma dışında VM bırakır. + RISK-C + RISK-B
- **Beklenen Kanıt:** Grup ifadeleri/üyeleri, VM etiketleri, rol listesi.
- **Kanıta Ulaşım Yöntemi:** NSX Manager Security/Distributed Firewall politika nesneleri, Groups üyeliği ve Exclusion List görünümünü okuyun. Rule ID, sıra, Applied To ve gerçek üye VM kimliğini birlikte dışa aktarın. Kurulu NSX sürümünün ekran yerleşimi ayrıca teyit edilir.
- **Kabul Ölçütleri:** Grup üyeliği tenant envanteriyle mutabık; etiket değiştiren yetkiler sınırlı olmalı.
- **İnceleme ve Test Adımları:** Yeni oluşturulmuş VM örneğinde etkin grup ve kural üyeliğini doğrula. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** Grup ifadeleri/üyeleri, VM etiketleri, rol listesi. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-4

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST-53: CM-6; NIST-53: AC-3; CM-6; BIGR: 3.1.9.7 | 3.1.9.7 — basılı s.61 / PDF 65
- **Teknik Referanslar:** NIST-53: CM-6; NIST-53: AC-3; CM-6; BIGR: 3.1.9.7 | 3.1.9.7 — basılı s.61 / PDF 65
- **Erişim Referansları:** VMW-NSX; NIST-ASSESS
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG07-09 — NSX: DFW exclusion list sadece onaylı sistemleri içeriyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-19 · **İlişkili üst kontrol:** `KG07-02`

- **Denetim Amacı:** Exclusion list istisnalarının onaylı olmasını doğrulamak.
- **Olası Riskler:** İstisna listesindeki VM'ler güvenlik politikasını atlatır. + RISK-C + RISK-B
- **Beklenen Kanıt:** Exclusion list UI/API exportu ve istisna onayları.
- **Kanıta Ulaşım Yöntemi:** NSX Manager Security/Distributed Firewall politika nesneleri, Groups üyeliği ve Exclusion List görünümünü okuyun. Rule ID, sıra, Applied To ve gerçek üye VM kimliğini birlikte dışa aktarın. Kurulu NSX sürümünün ekran yerleşimi ayrıca teyit edilir.
- **Kabul Ölçütleri:** İstisnalar gerekçeli, sahipli ve telafi kontrolüyle izlenmeli; API ve UI listesi tutarlı olmalı.
- **İnceleme ve Test Adımları:** GET /policy/api/v1/infra/settings/firewall/security/exclude-list sonucunu UI ile karşılaştır. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** Exclusion list UI/API exportu ve istisna onayları. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-4

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VMW-NSX: KB378422, exclusion list doğrulaması; NIST-53: CM-6; SC-7; BIGR: 3.1.9.11 | 3.1.9.11 — basılı s.62 / PDF 66
- **Teknik Referanslar:** VMW-NSX: KB378422, exclusion list doğrulaması; NIST-53: CM-6; SC-7; BIGR: 3.1.9.11 | 3.1.9.11 — basılı s.62 / PDF 66
- **Erişim Referansları:** VMW-NSX; NIST-ASSESS
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG07-10 — NSX: Tier-0/Tier-1 ve gateway kuralları tenant rotalarının izinsiz birleşmesini engelliyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-20 · **İlişkili üst kontrol:** `KG07-04`

- **Denetim Amacı:** Tenant rota izolasyonunun etkinliğini doğrulamak.
- **Olası Riskler:** Rota sızıntısı sanal ağ izolasyonunu bozar. + RISK-C + RISK-B
- **Beklenen Kanıt:** Gateway/routing exportu, north-south akış diyagramı.
- **Kanıta Ulaşım Yöntemi:** NSX Manager gateway ve routing nesnelerinden Tier/VRF, segment, route ve komşuluk bilgisini alın; müşteri akış matrisiyle aynı kaynak-hedef yönünde karşılaştırın.
- **Kabul Ölçütleri:** Müşteri route advertisement ve gateway erişimleri onaylı tasarımla sınırlı olmalı.
- **İnceleme ve Test Adımları:** İki tenant rota tablosunu karşılaştır; yetkisiz prefix erişimini test et. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** Gateway/routing exportu, north-south akış diyagramı. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-4

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST-53: SC-7; NIST-53: AC-4; SC-7; BIGR: 4.3.1.4 | 4.3.1.4 — basılı s.164 / PDF 168
- **Teknik Referanslar:** NIST-53: SC-7; NIST-53: AC-4; SC-7; BIGR: 4.3.1.4 | 4.3.1.4 — basılı s.164 / PDF 168
- **Erişim Referansları:** VMW-NSX; NIST-ASSESS
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG07-11 — NSX: NSX SpoofGuard profili doğru segment/port ve IP bağlarıyla uygulanıyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) · **Kaynak:** G2-21 · **İlişkili üst kontrol:** `KG07-02`

- **Denetim Amacı:** IP adres taklidinin engellenmesini doğrulamak.
- **Olası Riskler:** VM'nin başka müşteriye ait IP ile trafik üretmesi adres tabanlı yetki sınırını aşabilir. Yanlış allowlist meşru trafiği de kesebilir.
- **Beklenen Kanıt:** SpoofGuard profili, segment/port binding ve izinli IP listesi; onaylı spoof testi.
- **Kanıta Ulaşım Yöntemi:** GET /policy/api/v1/infra/spoofguard-profiles/{spoofguard-profile-id}; ilgili segment/port profil bağını mevcut nesne çıktısıyla eşleştirin.
- **Kabul Ölçütleri:** Gereken kapsamda address_binding_allowlist etkin, izinli adresler onaylı ve profil bağlantısı doğru olmalı; yalnız profilin varlığı yeterli sayılmaz.
- **İnceleme ve Test Adımları:** TEST-1
- **İncelenecek Kayıtlar ve Örnekleme:** SpoofGuard profili, segment/port binding ve izinli IP listesi; onaylı spoof testi. + KAYIT-B2
- **Kanıtın Sınırları:** SINIR-2

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NSX-SPOOF: address_binding_allowlist; NIST-53: SC-7
- **Teknik Referanslar:** NSX-SPOOF: address_binding_allowlist; NIST-53: SC-7
- **Erişim Referansları:** NSX-SPOOF: address_binding_allowlist; NIST-53: SC-7
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

