# KG05 - vSAN ve Depolama Dayanıklılığı

**Çalışma:** VMware MSP Denetimi · **Sürüm:** v4 — 14 Eylül 2026  
**Doküman:** Kontrol grubu çalışma listesi — 13 kontrol  
**Hazırlayan:** KKB İç Denetim Başkanlığı — BT Denetimi (danışmanlık çıktısıdır, son karar denetçinindir)  
**Ana dizin:** `00 - Ana Dizin ve Dokuman Haritasi.xlsx`

---

> Uyumsuzluk hükmü yalnızca **Bağlayıcı Kriter (Mevzuat)** alanındaki maddeye atıfla verilebilir. **İyi Uygulama** alanı tek başına uyumsuzluk dayanağı değildir. Terim ve kısaltmalar için `03 - Terimler` ve `04 - Kisaltmalar` dokümanlarına, metodoloji için `01 - Kapsam ve Metodoloji` dokümanına bakınız.

| Kontrol ID | Denetim Sorusu | Öncelik | Test Yöntemi | Kaynak |
|---|---|---|---|---|
| `KG05-01` | vSAN sağlık durumu, component health ve kapasite sapmaları düzenli izleniyor mu? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG05-02` | vSAN verileri şifrelenmiş mi ve anahtar yönetimi (key management) kontrollü mü? | Yüksek | Güvenlik Denetimi + Doküman İncelemesi | 12 KG |
| `KG05-03` | Storage policy setleri (FTT, stripe, compression vb.) doğru iş yüklerine atanmış mı? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG05-04` | Depolama kapasite eşiği (capacity threshold) alarmları ve önleyici eylem planı uygulanıyor mu? | Orta | Güvenlik Denetimi | 12 KG |
| `KG05-05` | vSAN network ayrımı ve güvenli trafiği sağlayacak vmkernel port tasarımı net mi? | Orta | Güvenlik Denetimi | 12 KG |
| `KG05-06` | Failover ve recovery davranışları için en az yıllık periyotlu uygulama testi var mı? | Orta | Doküman İncelemesi + Güvenlik Denetimi | 12 KG |
| `KG05-07` | vSAN: Datastore ve VM disk işlemleri müşteri yetki sınırını koruyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-25 |
| `KG05-08` | vSAN: vSAN File Services NFS paylaşımları yalnız yetkili istemci ağlarına açık mı? | Orta | Yapılandırma İncelemesi (Configuration Review) | EK G2-26 |
| `KG05-09` | Sanallaştırma ortamının yedekleri, üretim depolamasından ve üretim kimlik alanından ayrık bir hata alanında mı tutuluyor? | Yüksek | Doküman İncelemesi + Güvenlik Denetimi | v3-GAP v3-GAP-07 |
| `KG05-10` | Yedekler değiştirilemez (immutable / WORM) saklama ile korunuyor ve değişmezlik süresi kurtarma hedefleriyle uyumlu mu? | Yüksek | Yapılandırma İncelemesi + Doküman İncelemesi | v3-GAP v3-GAP-08 |
| `KG05-11` | Yedekleme sistemine yönetici erişimi ayrıcalıklı erişim yönetimi (PAM) ile kısıtlanmış mı ve yedek silme / saklama süresi (retention period) değiştirme işlemleri ikili onaya (dual authorization) bağlı mı? | Yüksek | Doküman İncelemesi + Güvenlik Denetimi | v3-GAP v3-GAP-09 |
| `KG05-12` | Yedeklerden geri yükleme testi tanımlı periyotta yapılıyor, sonucu kayıt altına alınıyor ve RPO/RTO hedefleriyle karşılaştırılıyor mu? | Yüksek | Doküman İncelemesi + Mülakat | v3-GAP v3-GAP-10 |
| `KG05-13` | Yedekler şifreleniyor ve yedek şifreleme anahtarları üretim anahtar yönetimi (key management)nden ayrık mı saklanıyor? | Orta | Yapılandırma İncelemesi + Doküman İncelemesi | v3-GAP v3-GAP-11 |

## KG05-01 — vSAN sağlık durumu, component health ve kapasite sapmaları düzenli izleniyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Depolama kaynaklı servis kesintisinin zamanında önceden fark edilmesi.
- **Olası Riskler:** Disk veya disk grubu arızasında yedekli veri kaybı.
- **Beklenen Kanıt:** vSAN Health check raporları, alarm kayıtları, kapasite trendi
- **Kanıta Ulaşım Yöntemi:** Son 30 günlük sağlık ve alarm logları çıkarılıp kritik seviyeler analiz edilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS VMware vSAN, NIST SP 800-53 (SI-4, CP-10)
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.2 (sanallaştırma ortamının kapasitesi izlenmeli, kapasite planlaması yapılmalı), BDDK-BSY Md. 13/3 (iz kayıtlarının düzenli izlenmesi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG05-02 — vSAN verileri şifrelenmiş mi ve anahtar yönetimi (key management) kontrollü mü?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi + Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Diskten geçen ve duran verinin gizliliğini korumak.
- **Olası Riskler:** Kötü niyetli bir erişimde veri sızması veya manipülasyon.
- **Beklenen Kanıt:** Şifreleme durumu, KMS bağlantı logları, anahtar rotasyon raporu
- **Kanıta Ulaşım Yöntemi:** vSAN ve KMS envanterleri eşleştirilir, anahtar erişim rolleri incelenir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-57, CIS vSAN encryption controls
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 9/2 (şifreleme anahtarlarının yaşam döngüsü güvenliği, geçerlilik süresi dolan anahtarların derhal engellenmesi), CBDDO 4.3.1.2-7 (kripto algoritmaları, anahtar uzunlukları, sertifika yönetimi), CBDDO 3.1.9.12 (depolama güvenliği)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG05-03 — Storage policy setleri (FTT, stripe, compression vb.) doğru iş yüklerine atanmış mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Dayanıklılık ve performans hedeflerinin VM seviyesinde uygulanmasını sağlamak.
- **Olası Riskler:** Kritik uygulamanın yetersiz çoğaltma ile risk altına girmesi.
- **Beklenen Kanıt:** Policy catalog, VM-policy eşleştirme, exception listesi
- **Kanıta Ulaşım Yöntemi:** VM envanterinden VM-policy mapping çıkarılır, kritik sınıflandırma ile çapraz kontrol yapılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS vSAN storage policy, NIST SP 800-53 (CP-10)
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.12 (depolama güvenliği tedbirleri), BDDK-BSY Md. 27/4 (yedeklerin kayıt altına alınması)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG05-04 — Depolama kapasite eşiği (capacity threshold) alarmları ve önleyici eylem planı uygulanıyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Depolama doluluğunun hizmet kalitesini düşürmesini engellemek.
- **Olası Riskler:** Ani dolulukla snapshot büyümesi ve I/O darboğazı.
- **Beklenen Kanıt:** Alarm kuralı ekranları, kapasite alarm geçmişi, aksiyon kayıtları
- **Kanıta Ulaşım Yöntemi:** Son 2 ayın alarm geçmişi analizi yapılır, kapatma/erişim kısıtlama aksiyonları kontrol edilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (SI-4), CIS storage management
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.2 (kapasite izlenmeli ve planlanmalı), BDDK-BSY Md. 13/3 (iz kayıtları düzenli izlenmeli)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG05-05 — vSAN network ayrımı ve güvenli trafiği sağlayacak vmkernel port tasarımı net mi?

**Öncelik:** Orta · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Depolama trafiğindeki müdahale ve performans çakışmalarını azaltmak.
- **Olası Riskler:** Yanlış VLAN veya jumbo frame ayarıyla veri transfer bozulması.
- **Beklenen Kanıt:** vSAN vmkernel port listesi, fiziksel switch eşlemesi
- **Kanıta Ulaşım Yöntemi:** Port gruplarıyla fiziksel ağ haritası karşılaştırılır, hata alarmı varsa risk notlandırılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS vSAN Networking Guidance, NIST SP 800-53 (SC-7)
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.6.6 (ağlar katmanlara ayrılmalı, VLAN'lar arasında erişim denetimi yapılmalı), CBDDO 3.1.9.11 (sanal makineler arası trafik güvenlik kontrollerinden geçirilmeli)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG05-06 — Failover ve recovery davranışları için en az yıllık periyotlu uygulama testi var mı?

**Öncelik:** Orta · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Teorik yedeklemenin pratikte çalışır durumda olduğunu doğrulamak.
- **Olası Riskler:** Planlar dokümanda kalıp gerçek senaryoda çalışmaması.
- **Beklenen Kanıt:** DR test planı, sonuç ve aksiyon kayıtları
- **Kanıta Ulaşım Yöntemi:** Test tarihleri ve başarı kriterleri denetlenir, başarısız testlerin kapatma notları incelenir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (CP-4), CIS resiliency best practice
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 28/3 (süreklilik planının yılda en az bir kez test edilmesi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG05-07 — vSAN: Datastore ve VM disk işlemleri müşteri yetki sınırını koruyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-25 · **İlişkili üst kontrol:** `KG09-02`

- **Denetim Amacı:** Datastore/disk yetkilerinin müşteri sınırını korumasını doğrulamak.
- **Olası Riskler:** Datastore ve sanal disk yetkileri müşteri sınırını aşarsa bir müşteri veya operatör diğer müşterinin diskini okuyabilir, başka VM'ye bağlayabilir, değiştirebilir veya silebilir. + RISK-C + RISK-B
- **Beklenen Kanıt:** SPBM/storage policy, datastore ve permission exportu
- **Kanıta Ulaşım Yöntemi:** VIPERM
- **Kabul Ölçütleri:** Yetkisiz tenant browse/attach/clone işlemleri reddedilmeli. Storage Policy tek başına erişim yetkilendirmesi sağlamaz; nesne/rol yetkileri ayrıca test edilir.
- **İnceleme ve Test Adımları:** TEST-2 + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** SPBM/storage policy, datastore ve permission exportu. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-4

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST-53: AC-3; SC-4
- **Teknik Referanslar:** NIST-53: AC-3; SC-4
- **Erişim Referansları:** VMW-VSAN; RO-VMW-PERM
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG05-08 — vSAN: vSAN File Services NFS paylaşımları yalnız yetkili istemci ağlarına açık mı?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) · **Kaynak:** G2-26 · **İlişkili üst kontrol:** `KG05-05`

- **Denetim Amacı:** NFS paylaşım erişiminin yetkili istemcilerle sınırlı olmasını doğrulamak.
- **Olası Riskler:** Geniş NFS ağ izni, vCenter rolü olmayan bir istemcinin müşteri dosyalarına erişmesine neden olabilir.
- **Beklenen Kanıt:** Hedef nesne/sürüm bilgisi ve vSAN File Share Configuration etkin ayar çıktısı; onaylı baseline ve istisnalar.
- **Kanıta Ulaşım Yöntemi:** SCG-RO(vSAN File Share Configuration)
- **Kabul Ölçütleri:** NFS share Customize Net Access kuralları onaylı istemci ve tenant kapsamıyla sınırlı olmalı; varsayılan geniş erişim iş gerekçesi yerine geçmez.
- **İnceleme ve Test Adımları:** TEST-1
- **İncelenecek Kayıtlar ve Örnekleme:** Hedef nesne/sürüm bilgisi ve vSAN File Share Configuration etkin ayar çıktısı; onaylı baseline ve istisnalar. + KAYIT-B2
- **Kanıtın Sınırları:** SINIR-2

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VMW-SCG: vsan-8.file-services-access-control-nfs
- **Teknik Referanslar:** VMW-SCG: vsan-8.file-services-access-control-nfs; VMW-SCG kaynak varyantları: vsan-8.file-services-access-control-nfs. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** VMW-SCG: vsan-8.file-services-access-control-nfs
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG05-09 — Sanallaştırma ortamının yedekleri, üretim depolamasından ve üretim kimlik alanından ayrık bir hata alanında mı tutuluyor?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** v3-GAP-07 · **İlişkili üst kontrol:** `KG05-01`

- **Denetim Amacı:** Üretim ortamını ele geçiren bir saldırganın aynı kimlik ve depolama üzerinden yedeklere de ulaşmasını engelleyerek kurtarma kabiliyetini korumak.
- **Olası Riskler:** Yedeklerin üretim vSAN/datastore üzerinde veya üretim Active Directory kimlikleriyle erişilebilir bir depoda tutulması, fidye yazılımı olaylarında yedeklerin de şifrelenmesine veya silinmesine yol açar; kurtarma kabiliyeti tamamen ortadan kalkar.
- **Beklenen Kanıt:** Yedekleme mimarisi dokümanı ve depolama yerleşim şeması; yedek deposunun üretim datastore'larından ayrı olduğunu gösteren envanter çıktısı; yedekleme sisteminin kimlik kaynağı yapılandırması; son bir yıla ait yedek silme/erişim olay kayıtları.
- **Kanıta Ulaşım Yöntemi:** Yedekleme ürününün yönetim arayüzünden repository/depolama hedefi listesi (salt okunur (read-only)); vSphere Client > Storage > Datastores ile karşılaştırma; yedekleme sisteminin kimlik entegrasyonu yapılandırma ekranı. Yedekleme ürününün kendi iç kontrolleri bu çalışmanın kapsamı dışındadır, yalnız ayrıklık doğrulanır.
- **Kabul Ölçütleri:** Yedekler, üretim iş yüklerinin bulunduğu datastore/vSAN kümesinden farklı bir depolama sisteminde tutulmalıdır. Yedekleme sistemine erişim, üretim yönetici kimlikleriyle sağlanmamalıdır (ayrı kimlik alanı veya yerel ayrıcalıklı hesap (privileged account)). En az bir kopya çevrimdışı veya mantıksal olarak ayrık (air-gap / farklı bulut hesabı) olmalıdır.
- **İnceleme ve Test Adımları:** Repository listesini üretim datastore listesiyle karşılaştır; aynı depolama dizisi veya aynı vSAN kümesi üzerinde duran hedefleri işaretle. Yedekleme sisteminin kimlik kaynağını kontrol et; üretim domain yöneticisinin yedek silebiliyor olması bulgu adayıdır. Üretimde yedek silme veya taşıma işlemi yapma.
- **İncelenecek Kayıtlar ve Örnekleme:** Tüm yedekleme repository'leri ve koruma işleri (job) tam liste olarak incelenir. Örnekleme yapılacaksa farklı müşteri (tenant) ve kritiklik sınıfı temsil edilmelidir.
- **Kanıtın Sınırları:** Mimari dokümanı ve yapılandırma, ölçüm anındaki durumu gösterir; dönem boyunca ayrıklığın korunduğunu kanıtlamaz. Ayrıklık, yedeğin bozulmadığını değil yalnız erişim yolunun ayrıldığını gösterir — geri yükleme testi (KG05-12) tamamlayıcıdır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** v3 kapsam boşluğu analizi — fidye yazılımı kurtarma kabiliyeti
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 27/2 (yedek veri işleme sistemi, süreklilik); CBDDO BİGR 3.1.9.13 (sanallaştırma ortamının yedeklenmesi)
- **İyi Uygulama (Standart/Baseline):** NIST SP 800-53 Rev.5 CP-6 (alternatif saklama alanı), CP-9 (sistem yedekleme)
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG05-10 — Yedekler değiştirilemez (immutable / WORM) saklama ile korunuyor ve değişmezlik süresi kurtarma hedefleriyle uyumlu mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Doküman İncelemesi · **Kaynak:** v3-GAP-08 · **İlişkili üst kontrol:** `KG05-01`

- **Denetim Amacı:** Yönetici yetkisi ele geçirilse dahi yedeğin belirli bir süre boyunca silinememesini veya değiştirilememesini sağlamak.
- **Olası Riskler:** Değişmezlik yoksa saldırgan yedekleme konsolundan koruma işlerini durdurup mevcut yedekleri silebilir; şifreleme öncesi hazırlık adımı olarak sıkça gözlenen davranıştır.
- **Beklenen Kanıt:** Repository bazında immutability/WORM ayar çıktısı ve değişmezlik süresi; saklama politikası dokümanı; değişmezlik süresinin RPO/RTO hedefleriyle uyumunu gösteren analiz; değişmezlik ayarının değiştirilmesine ilişkin olay kayıtları.
- **Kanıta Ulaşım Yöntemi:** Yedekleme ürününün repository ayarlarında immutability/WORM alanının salt okunur (read-only) görüntüsü; nesne depolama kullanılıyorsa object lock yapılandırması; saklama politikası dokümanı süreç sahibinden alınır.
- **Kabul Ölçütleri:** Kritik iş yüklerinin yedekleri için değişmezlik etkin olmalı ve değişmezlik süresi en az kurumun tanımladığı tespit-tepki süresini kapsamalıdır. Değişmezlik süresi ile saklama süresi (retention period) ayrı ayrı tanımlı olmalıdır. Değişmezlik ayarının değiştirilmesi izlenmeli ve alarm üretmelidir.
- **İnceleme ve Test Adımları:** Repository bazında immutability durumunu ve süresini oku; kritik iş yükü kapsamının bu repository'lere düştüğünü koruma işleri üzerinden doğrula. Değişmezlik süresini kurumun RPO/RTO ve olay tespit süresi hedefleriyle karşılaştır — kaynakta tanımlı olmayan bir eşik uydurma, kurumun onaylı hedefini esas al.
- **İncelenecek Kayıtlar ve Örnekleme:** Tüm repository'ler ve kritik iş yükü koruma işleri. Örnekleme yapılacaksa müşteri ve kritiklik sınıfı bazında tabakalandırılır.
- **Kanıtın Sınırları:** Ayar kanıtı ölçüm anını gösterir. Değişmezlik, yedeğin geri yüklenebilir olduğunu kanıtlamaz; bütünlük ve geri yükleme testi ayrıca gereklidir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** v3 kapsam boşluğu analizi — fidye yazılımı kurtarma kabiliyeti
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 27/2 (yedek veri işleme sistemi); BDDK-BSY Md. 27/4 (yedekleme kayıtları); CBDDO BİGR 3.1.9.13 (sanallaştırma ortamının yedeklenmesi)
- **İyi Uygulama (Standart/Baseline):** NIST SP 800-53 Rev.5 CP-9(5) (yedekleme bütünlüğünün korunması), SI-7 (bütünlük)
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG05-11 — Yedekleme sistemine yönetici erişimi ayrıcalıklı erişim yönetimi (PAM) ile kısıtlanmış mı ve yedek silme / saklama süresi (retention period) değiştirme işlemleri ikili onaya (dual authorization) bağlı mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** v3-GAP-09 · **İlişkili üst kontrol:** `KG02-03`

- **Denetim Amacı:** Kurtarma kabiliyetini ortadan kaldırabilecek işlemlerin tek kişi tarafından yapılamamasını sağlamak.
- **Olası Riskler:** Tek bir ele geçirilmiş yedekleme yöneticisi hesabı, tüm kurtarma noktalarını silebilir. Bu, fidye yazılımı olaylarında şifrelemeden önce atılan tipik adımdır.
- **Beklenen Kanıt:** Yedekleme sistemi rol ve hesap listesi; PAM entegrasyonu yapılandırması; yedek silme ve saklama süresi (retention period) değişikliği için onay akışı tanımı; son dönem silme işlemlerinin onay kayıtlarıyla eşleştirilmiş listesi.
- **Kanıta Ulaşım Yöntemi:** Yedekleme ürününün kullanıcı/rol yönetimi ekranının salt okunur (read-only) görüntüsü; PAM platformundan yedekleme hedefine ait erişim politikası; onay akışı ITSM kayıtlarından alınır.
- **Kabul Ölçütleri:** Yedekleme sistemine ayrıcalıklı erişim yalnız PAM üzerinden ve çok bileşenli kimlik doğrulama ile sağlanmalıdır. Yedek silme ve saklama/değişmezlik süresi değişikliği ikili onay (dual authorization)a bağlı olmalı; her işlem için onay kaydı ve iz kaydı bulunmalıdır.
- **İnceleme ve Test Adımları:** Rol matrisini gerçek hesap üyelikleriyle karşılaştır; PAM dışından erişebilen hesapları işaretle. Son dönem silme işlemlerini örnekle ve her biri için onay kaydını eşle — onaysız silme işlemi bulgu adayıdır.
- **İncelenecek Kayıtlar ve Örnekleme:** Tüm ayrıcalıklı hesap (privileged account)lar tam liste olarak; silme işlemleri son dönem üzerinden örneklenir, örneklem gerekçesi ve dönemi çalışma kâğıdında belirtilir.
- **Kanıtın Sınırları:** Rol tanımı, fiilî yetkiyi tek başına göstermez; gerçek üyelik ve oturum kaydıyla birlikte doğrulanmalıdır. İz kaydı yalnız kaydedilen işlemleri kapsar.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** v3 kapsam boşluğu analizi — fidye yazılımı kurtarma kabiliyeti
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 11/6 (en az yetki, yıllık gözden geçirme); BDDK-BSY Md. 13/3 (iz kayıtlarının düzenli izlenmesi); BDDK-BSY Md. 27/4 (yedekleme kayıtları)
- **İyi Uygulama (Standart/Baseline):** NIST SP 800-53B Tablo 3-5 CM-5(4) Dual Authorization (yalnız HIGH taban); ISO/IEC 27002:2022 5.18 (ayrıcalıklı erişim yetkilendirmeleri)
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 13.6, 14.1–14.3

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG05-12 — Yedeklerden geri yükleme testi tanımlı periyotta yapılıyor, sonucu kayıt altına alınıyor ve RPO/RTO hedefleriyle karşılaştırılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi + Mülakat · **Kaynak:** v3-GAP-10 · **İlişkili üst kontrol:** `KG05-06`

- **Denetim Amacı:** Yedeğin varlığı ile kurtarma kabiliyeti arasındaki farkı kapatmak; taahhüt edilen kurtarma sürelerinin ölçülmüş olmasını sağlamak.
- **Olası Riskler:** Test edilmemiş yedek, olay anında bozuk, eksik veya beklenenden çok daha yavaş geri yüklenebilir çıkar; sözleşmede taahhüt edilen RTO aşılır.
- **Beklenen Kanıt:** Geri yükleme test planı ve periyodu; son dönem test tutanakları (tarih, kapsam, süre, sonuç); ölçülen geri yükleme sürelerinin RPO/RTO hedefleriyle karşılaştırması; başarısız testler için aksiyon kayıtları.
- **Kanıta Ulaşım Yöntemi:** Test tutanakları ve aksiyon kayıtları süreç sahibinden ve ITSM sisteminden alınır; yedekleme ürününün restore job geçmişi salt okunur (read-only) olarak incelenir.
- **Kabul Ölçütleri:** Geri yükleme testi kurumun tanımladığı periyotta yapılmalı (BDDK-BSY Md. 28/3 kapsamında süreklilik planı için asgari yılda bir kez), farklı iş yükü sınıflarını kapsamalı ve ölçülen süre RPO/RTO hedefleriyle karşılaştırılmalıdır. Sapma varsa sebep analizi ve aksiyon kaydı bulunmalıdır.
- **İnceleme ve Test Adımları:** Son dört çeyreğin test tutanaklarını al; test kapsamının kritik iş yüklerini içerdiğini doğrula — yalnız küçük/temsili olmayan VM ile yapılan test kabul ölçütü (acceptance criteria)nü kapatmaz. Ölçülen süreleri KG01-04'teki RPO/RTO hedefleriyle karşılaştır.
- **İncelenecek Kayıtlar ve Örnekleme:** Son dört çeyreğin tüm test tutanakları. Örnekleme yapılmaz; kapsam dışı bırakılan iş yükü sınıfları analizde belirtilir.
- **Kanıtın Sınırları:** Test sonucu test anındaki ortam ve veri hacmi için geçerlidir; olay anındaki toplu kurtarma senaryosunu (aynı anda çok sayıda VM) tek başına kanıtlamaz.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** v3 kapsam boşluğu analizi — fidye yazılımı kurtarma kabiliyeti
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 28/3 (süreklilik planının yılda en az bir kez test edilmesi); BDDK-BSY Md. 27/4 (yedekleme kayıtları)
- **İyi Uygulama (Standart/Baseline):** NIST SP 800-53 Rev.5 CP-4 (süreklilik planı testi), CP-9 (sistem yedekleme)
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG05-13 — Yedekler şifreleniyor ve yedek şifreleme anahtarları üretim anahtar yönetimi (key management)nden ayrık mı saklanıyor?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi + Doküman İncelemesi · **Kaynak:** v3-GAP-11 · **İlişkili üst kontrol:** `KG05-02`

- **Denetim Amacı:** Yedek ortamının ele geçirilmesi hâlinde veri gizliliğini korumak ve üretim anahtar yönetimi (key management)nin kaybı hâlinde yedeğin okunamaz hâle gelmesini önlemek.
- **Olası Riskler:** Şifresiz yedek, ortamın çalınması veya yanlış paylaşılması hâlinde doğrudan müşteri verisi sızıntısıdır. Yedek anahtarının üretim KMS'inde tutulması ise KMS kaybında yedeği kullanılamaz hâle getirir.
- **Beklenen Kanıt:** Yedekleme işi bazında şifreleme ayarı çıktısı; anahtar saklama yeri ve erişim yetkileri; anahtar yedekleme/kurtarma prosedürü; anahtar rotasyon kayıtları.
- **Kanıta Ulaşım Yöntemi:** Yedekleme ürününün job/repository şifreleme ayarları salt okunur (read-only) okunur; anahtar yönetim sisteminin envanterinden yedek anahtarlarının bulunduğu alan ve erişim yetkileri incelenir.
- **Kabul Ölçütleri:** Müşteri verisi içeren tüm yedekler şifreli olmalıdır. Yedek şifreleme anahtarları üretim vSAN/VM şifreleme anahtarlarından ayrı tutulmalı, erişimi kısıtlı olmalı ve anahtar kurtarma prosedürü yazılı olmalıdır. Süresi dolan anahtarlar derhal engellenmelidir.
- **İnceleme ve Test Adımları:** Şifreleme ayarını job bazında oku ve şifresiz kalan işleri listele. Anahtarın nerede saklandığını ve kimlerin eriştiğini ayrı doğrula — anahtarın yedekle aynı sistemde tutulması kabul ölçütü (acceptance criteria)nü karşılamaz.
- **İncelenecek Kayıtlar ve Örnekleme:** Tüm koruma işleri; anahtar erişim yetkileri tam liste olarak incelenir.
- **Kanıtın Sınırları:** Şifreleme ayarı ölçüm anını gösterir; geçmiş yedeklerin şifreli olduğunu kanıtlamaz. Anahtar ayrıklığı, anahtar kurtarma prosedürünün işlediğini göstermez.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** v3 kapsam boşluğu analizi — fidye yazılımı kurtarma kabiliyeti
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 9/2 (şifreleme anahtarlarının yaşam döngüsü boyunca güvenliği, geçerlilik süresi dolan anahtarların derhal engellenmesi); CBDDO BİGR 3.1.9.13 (sanallaştırma ortamının yedeklenmesi), 4.3.1.5 (anahtar yönetimi)
- **İyi Uygulama (Standart/Baseline):** NIST SP 800-53 Rev.5 SC-28 (beklemedeki bilginin korunması), SC-12 (kriptografik anahtar oluşturma ve yönetimi)
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

