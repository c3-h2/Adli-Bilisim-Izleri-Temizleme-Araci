# KG10 - VM Template, Klonlama, Snapshot ve BM Klonlama Yönetimi

**Çalışma:** VMware MSP Denetimi · **Sürüm:** v4 — 14 Eylül 2026  
**Doküman:** Kontrol grubu çalışma listesi — 8 kontrol  
**Hazırlayan:** KKB İç Denetim Başkanlığı — BT Denetimi (danışmanlık çıktısıdır, son karar denetçinindir)  
**Ana dizin:** `00 - Ana Dizin ve Dokuman Haritasi.xlsx`

---

> Uyumsuzluk hükmü yalnızca **Bağlayıcı Kriter (Mevzuat)** alanındaki maddeye atıfla verilebilir. **İyi Uygulama** alanı tek başına uyumsuzluk dayanağı değildir. Terim ve kısaltmalar için `03 - Terimler` ve `04 - Kisaltmalar` dokümanlarına, metodoloji için `01 - Kapsam ve Metodoloji` dokümanına bakınız.

| Kontrol ID | Denetim Sorusu | Öncelik | Test Yöntemi | Kaynak |
|---|---|---|---|---|
| `KG10-01` | Golden image/sabit şablon (template) süreçlerinde hardening sonrası onay süreci uygulanıyor mu? | Yüksek | Doküman İncelemesi + Güvenlik Denetimi | 12 KG |
| `KG10-02` | VM clone ve dağıtım onayı kritik sistemlerde zorunlu mu? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG10-03` | Snapshot kullanım politikası, maksimum süre ve otomasyonla temizlik prosedürü var mı? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG10-04` | Snapshot rollback/delete öncesi onay ve geri dönüş etkisi analiz edilmiş mi? | Orta | Doküman İncelemesi + Güvenlik Denetimi | 12 KG |
| `KG10-05` | BM (bare-metal) veya platformlar arası klonlama (clone) için lisans, sürüm ve uyumluluk kontrolü var mı? | Orta | Doküman İncelemesi | 12 KG |
| `KG10-06` | VM yaşam döngüsünü (create, template, clone, patch, snapshot, retire) otomatik raporlama karşılıyor mu? | Orta | Güvenlik Denetimi | 12 KG |
| `KG10-07` | ESXi: VM dağıtımı onaylı ve güvenli şablon (template) sürecinden geçiyor mu? | Yüksek | Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı | EK G3-09 |
| `KG10-08` | ESXi: Kurulumu tamamlanmış VM alternatif ağ veya çıkarılabilir ortam (removable media)dan izinsiz başlatılabiliyor mu? | Orta | Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı | EK G3-10 |

## KG10-01 — Golden image/sabit şablon (template) süreçlerinde hardening sonrası onay süreci uygulanıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Üretime giden VM'lerin güvenli başlangıç noktasıyla alınmasını sağlamak.
- **Olası Riskler:** Güvenlik ayarsız imajların çoğalmasıyla genişletilmiş zafiyet yüzeyi.
- **Beklenen Kanıt:** Template onay kayıtları, imaj doğrulama sonuçları, patch durumu
- **Kanıta Ulaşım Yöntemi:** Template listesi çıkarılır, güvenlik kontrolünden geçen imajların listesi doğrulanır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS hardening guidance, NIST SP 800-53 (CM-6)
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.6 (imaj bütünlüğünün denetlenmesi ve izlenmesi), BDDK-BSY Md. 16/1 (yama yönetimi prosedürü)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG10-02 — VM clone ve dağıtım onayı kritik sistemlerde zorunlu mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Yetkisiz veya yanlış konfigürasyonlu VM üretimini engellemek.
- **Olası Riskler:** Gereksiz/kaçak VM çoğalması.
- **Beklenen Kanıt:** Clone ticketları, onay akışı, task log
- **Kanıta Ulaşım Yöntemi:** Clone history raporu örneklenir, onaysız operasyonlar filtrelenir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (CM-3), CIS VM lifecycle
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 24/1 (değişiklik yönetimi prosedürü, yetkili onayı)
- **İyi Uygulama (Standart/Baseline):** ISO/IEC 27001:2022 Ek A A.8.32 (değişiklik yönetimi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG10-03 — Snapshot kullanım politikası, maksimum süre ve otomasyonla temizlik prosedürü var mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Performans bozulması ve disk büyümesi riskini kontrol etmek.
- **Olası Riskler:** Uzun ömürlü snapshot yüzünden I/O düşüşü.
- **Beklenen Kanıt:** Snapshot envanteri, otomatik temizlik/policy ayarları
- **Kanıta Ulaşım Yöntemi:** Aktif snapshot listesi raporları alınır, yaş ve sayı eşiği ihlalleri raporlanır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS VM Snapshot controls, NIST SP 800-53 (SI-2)
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.2 (kapasite izlenmesi), BDDK-BSY Md. 13/3 (iz kayıtlarının düzenli izlenmesi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG10-04 — Snapshot rollback/delete öncesi onay ve geri dönüş etkisi analiz edilmiş mi?

**Öncelik:** Orta · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Hatalı geri yükleme ile operasyon etki alanını öngörmek.
- **Olası Riskler:** Uygun plan olmadan geri alma ile veri kaybı.
- **Beklenen Kanıt:** Rollback talimatı, etki analizi ve onay kayıtları
- **Kanıta Ulaşım Yöntemi:** Kritik VM örneklerinde işlem öncesi plan dokümanı ve işlem sonrası durum karşılaştırılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (CP-2), CIS recovery guidance
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 24/1 (değişiklik yönetimi, test, geri alma planı, yetkili onayı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG10-05 — BM (bare-metal) veya platformlar arası klonlama (clone) için lisans, sürüm ve uyumluluk kontrolü var mı?

**Öncelik:** Orta · **Test Yöntemi:** Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Uyumlu olmayan platform hedeflerine taşımayı engellemek.
- **Olası Riskler:** Aygıt sürücü sorunları ve lisans ihlalleri.
- **Beklenen Kanıt:** HCL uyumluluk kayıtları, klonlama (clone) talimatı, lisans doğrulama
- **Kanıta Ulaşım Yöntemi:** Klonlama örneklerinde hedef donanım ve lisans uygunluğu raporları incelenir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VMware HCL ve migration guides, NIST SP 800-53 (CM-2)
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.1 (kararlı sürümler, üretici desteği), BDDK-BSY Md. 24/1 (değişiklik yönetimi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG10-06 — VM yaşam döngüsünü (create, template, clone, patch, snapshot, retire) otomatik raporlama karşılıyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Denetim izinin tutarlılığını ve geriye dönük izlenebilirliği sağlamak.
- **Olası Riskler:** Hangi VM'in hangi tarihte ne şekilde değiştiği bilinmez.
- **Beklenen Kanıt:** VM lifecycle dashboard, otomasyon logları, audit export
- **Kanıta Ulaşım Yöntemi:** VM ID bazlı lifecycle query ile olay zaman çizelgesi çıkarılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (AU-6, AU-12), CIS ops guidance
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 13/1 (iz kayıtları asgari içerik: sistem, tarih/saat, değişiklik, tekil kullanıcı), BDDK-BSY Md. 13/3 (düzenli izleme)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG10-07 — ESXi: VM dağıtımı onaylı ve güvenli şablon (template) sürecinden geçiyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı · **Kaynak:** G3-09 · **İlişkili üst kontrol:** `KG10-01`

- **Denetim Amacı:** VM dağıtımının onaylı şablon (template) sürecine bağlılığını doğrulamak.
- **Olası Riskler:** — (kaynak metin kırpıldı)
- **Beklenen Kanıt:** — (kaynak metin kırpıldı)
- **Kanıta Ulaşım Yöntemi:** — (kaynak metin kırpıldı)
- **Kabul Ölçütleri:** KAYNAK METİN KIRPILDI - kabul ölçütü (acceptance criteria) 'ESXi 7 kapsamında standart VM dağıtım yöntemi be...' ifadesiyle yarıda kesildi; tam metin kullanıcıdan sağlanmalı.
- **İnceleme ve Test Adımları:** — (kaynak metin kırpıldı)
- **İncelenecek Kayıtlar ve Örnekleme:** — (kaynak metin kırpıldı)
- **Kanıtın Sınırları:** — (kaynak metin kırpıldı)

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** — (kaynak metin kırpıldı)
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.6 (imaj bütünlüğünün denetlenmesi ve izlenmesi)
- **Teknik Referanslar:** — (kaynak metin kırpıldı)
- **Erişim Referansları:** — (kaynak metin kırpıldı)
- **Denetim Yöntemi Referansları:** — (kaynak metin kırpıldı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG10-08 — ESXi: Kurulumu tamamlanmış VM alternatif ağ veya çıkarılabilir ortam (removable media)dan izinsiz başlatılabiliyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı · **Kaynak:** G3-10 · **İlişkili üst kontrol:** `KG10-01`

- **Denetim Amacı:** Alternatif açılış kaynaklarının kısıtlanmasını doğrulamak.
- **Olası Riskler:** — (kaynak metin kırpıldı)
- **Beklenen Kanıt:** — (kaynak metin kırpıldı)
- **Kanıta Ulaşım Yöntemi:** — (kaynak metin kırpıldı)
- **Kabul Ölçütleri:** — (kaynak metin kırpıldı)
- **İnceleme ve Test Adımları:** — (kaynak metin kırpıldı)
- **İncelenecek Kayıtlar ve Örnekleme:** — (kaynak metin kırpıldı)
- **Kanıtın Sınırları:** — (kaynak metin kırpıldı)

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** — (kaynak metin kırpıldı)
- **Teknik Referanslar:** — (kaynak metin kırpıldı)
- **Erişim Referansları:** — (kaynak metin kırpıldı)
- **Denetim Yöntemi Referansları:** — (kaynak metin kırpıldı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

