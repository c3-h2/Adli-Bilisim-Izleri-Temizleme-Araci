# KG03 - ESXi Hypervisor Güvenliği

**Çalışma:** VMware MSP Denetimi · **Sürüm:** v4 — 14 Eylül 2026  
**Doküman:** Kontrol grubu çalışma listesi — 32 kontrol  
**Hazırlayan:** KKB İç Denetim Başkanlığı — BT Denetimi (danışmanlık çıktısıdır, son karar denetçinindir)  
**Ana dizin:** `00 - Ana Dizin ve Dokuman Haritasi.xlsx`

---

> Uyumsuzluk hükmü yalnızca **Bağlayıcı Kriter (Mevzuat)** alanındaki maddeye atıfla verilebilir. **İyi Uygulama** alanı tek başına uyumsuzluk dayanağı değildir. Terim ve kısaltmalar için `03 - Terimler` ve `04 - Kisaltmalar` dokümanlarına, metodoloji için `01 - Kapsam ve Metodoloji` dokümanına bakınız.

| Kontrol ID | Denetim Sorusu | Öncelik | Test Yöntemi | Kaynak |
|---|---|---|---|---|
| `KG03-01` | ESXi host yapılandırmaları CIS ESXi Benchmark'a göre merkezileştirilmiş policy ile karşılaştırılıyor mu? | Yüksek | Güvenlik Denetimi + Doküman İncelemesi | 12 KG |
| `KG03-02` | SSH, ESXi Shell ve DCUI erişimi bakım dışı zamanlarda kapalı tutuluyor mu? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG03-03` | Lockdown Mode/benzer yönetim kısıtı uygulandı mı ve istisna süreçleri kayıtlı mı? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG03-04` | Host zaman senkronizasyonu (time synchronization / NTP) güvenilir bir zaman kaynağına bağlı mı? | Orta | Güvenlik Denetimi | 12 KG |
| `KG03-05` | Yönetim ve API bağlantılarında TLS/sertifika ayarları güvenli mi? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG03-06` | Host firmware/BMC fiziksel güvenlik kontrolleri ve bütünlük süreçleri düzenli izleniyor mu? | Orta | Doküman İncelemesi + Güvenlik Denetimi | 12 KG |
| `KG03-07` | ESXi: BMC yönetim güvenliği kontrolü, kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-02 |
| `KG03-08` | ESXi: DCUI Idle Session Timeout kontrolü, kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-03 |
| `KG03-09` | ESXi: Shell ve SSH Idle Session Timeout kontrolü, kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-04 |
| `KG03-10` | ESXi: Shell Service Availability Timeout kontrolü, kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-05 |
| `KG03-11` | ESXi: API ve Host Client oturum sınırları kontrolü, kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-10 |
| `KG03-12` | ESXi: Lockdown ve bypass hesapları kontrolü, kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-11 |
| `KG03-13` | ESXi: Host oturum uyarı metinleri (login banner) kontrolü, kabul ölçütlerini karşılıyor mu? | Orta | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-13 |
| `KG03-14` | ESXi: CIM ve SNMP koşullu yetki sınırı kontrolü, kabul ölçütlerini karşılıyor mu? | Orta | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-14 |
| `KG03-15` | ESXi: SSH daemon yetenek sınırlamaları (capability restrictions) kontrolü, kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-15 |
| `KG03-16` | ESXi: SSH keepalive süre parametreleri kontrolü, kabul ölçütlerini karşılıyor mu? | Orta | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-16 |
| `KG03-17` | ESXi: VM konsol sınırları kontrolü, kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-17 |
| `KG03-18` | ESXi: Son VM konsol bağlantısı kapandığında misafir oturumu (guest session) kilitleniyor mu? | Orta | Yapılandırma İncelemesi (Configuration Review) | EK G1-22 |
| `KG03-19` | ESXi: Host ve VM dvFilter erişimi kontrolü, kabul ölçütlerini karşılıyor mu? | Orta | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-14 |
| `KG03-20` | ESXi: Standard vSwitch MAC güvenliği kontrolü, kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-15 |
| `KG03-21` | ESXi: Standard vSwitch VLAN sınırları kontrolü, kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-16 |
| `KG03-22` | ESXi: Intel SGX kapsamı kontrolü, kabul ölçütlerini karşılıyor mu? | Düşük | Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı | EK G3-02 |
| `KG03-23` | ESXi: Gereksiz host yönetim servisleri kontrolü, kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı | EK G3-03 |
| `KG03-24` | ESXi: Gereksiz VM donanımı ve 3D kontrolü, kabul ölçütlerini karşılıyor mu? | Orta | Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı | EK G3-04 |
| `KG03-25` | ESXi: Guest OS'nin aygıt bağlama/değiştirme (device connect/edit) yetkisi kontrolü, kabul ölçütlerini karşılıyor mu? | Yüksek | Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı | EK G3-05 |
| `KG03-26` | ESXi: Gereksiz Tools bilgi/işlev modülleri kontrolü, kabul ölçütlerini karşılıyor mu? | Orta | Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı | EK G3-06 |
| `KG03-27` | ESXi: ESXi 7 gereksiz guest işlevleri kontrolü, kabul ölçütlerini karşılıyor mu? | Orta | Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı | EK G3-07 |
| `KG03-28` | ESXi: ESXi 7 guest-host masaüstü entegrasyonları kontrolü, kabul ölçütlerini karşılıyor mu? | Orta | Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı | EK G3-08 |
| `KG03-29` | ESXi: İmzasız veya kurulu olmayan ikili dosyaların host üzerinde çalıştırılması engellenmiş mi (VMkernel.Boot.execInstalledOnly)? | Yüksek | Yapılandırma İncelemesi (Configuration Review) | v3-GAP v3-GAP-01 |
| `KG03-30` | ESXi: Host'larda UEFI Secure Boot etkin mi ve etkinleştirilemeyen host'lar için onaylı istisna kaydı tutuluyor mu? | Yüksek | Yapılandırma İncelemesi (Configuration Review) | v3-GAP v3-GAP-02 |
| `KG03-31` | ESXi: Host'larda TPM 2.0 mevcut ve vCenter üzerindeki host attestation durumu başarılı mı? | Orta | Yapılandırma İncelemesi (Configuration Review) | v3-GAP v3-GAP-03 |
| `KG03-32` | ESXi: Sanal makinelerde gereksiz aygıt ve host-guest iletişim kanalları (VMCI, USB/xHCI denetleyici, seri/paralel port, CD-ROM/floppy, paylaşılan klasör) kaldırılmış veya devre dışı bırakılmış mı? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | v3-GAP v3-GAP-04 |

## KG03-01 — ESXi host yapılandırmaları CIS ESXi Benchmark'a göre merkezileştirilmiş policy ile karşılaştırılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi + Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Host seviyesinde standart dışı ve riskli ayarların yayılmasını engellemek.
- **Olası Riskler:** Gereksiz servislerin açık kalması, bilinen exploit yüzeyi.
- **Beklenen Kanıt:** Host profile export, patch ve ayar karşılaştırma raporları
- **Kanıta Ulaşım Yöntemi:** Host Profiles üzerinden çıktılar alınarak CIS kontrol seti ile otomatik kıyas yapılır, farklılıkların risk açıklaması talep edilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS VMware ESXi 7 Benchmark v1.6.0, NIST SP 800-53 (CM-6, SI-2)
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 16/1 (yama yönetimi prosedürü, kritik yamaların önceliklendirilmesi), CBDDO 3.1.9.1 (sanallaştırma ürünlerinde üretici desteği devam eden kararlı sürümler, güvenlik duyurularının takibi)
- **İyi Uygulama (Standart/Baseline):** CIS VMware ESXi 7.0 Benchmark v1.5.0 ve CIS VMware ESXi 8.0 Benchmark v1.3.0 (L1 profile) — host profile diff ile kıyas

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-02 — SSH, ESXi Shell ve DCUI erişimi bakım dışı zamanlarda kapalı tutuluyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Lokal müdahale kanallarını daraltmak.
- **Olası Riskler:** Yetkisiz yerel erişim veya kötüye kullanılabilir yönetim oturumları.
- **Beklenen Kanıt:** Host security state çıktıları, servis durum listeleri
- **Kanıta Ulaşım Yöntemi:** Tüm hostlar için servis durumu kontrol edilir, açık kalanlar için iş gerekçesi ve onay belgeleri istenir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (CM-7), CIS ESXi hardening section
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 5.1.1.4 (gerekli olmayan servisler kapatılmalı), BDDK-BSY Md. 14/7 (uzaktan erişim onay ve iz kaydı zorunluluğu)
- **İyi Uygulama (Standart/Baseline):** CIS VMware ESXi 7.0 Benchmark v1.5.0, 5.3 (L1) Ensure SSH is disabled, CIS VMware ESXi 8.0 Benchmark v1.3.0, 3.1 (L1) Host should deactivate SSH — Audit: Get-VMHost | Get-VMHostService | Where { $_.key -eq "TSM-SSH" } | Select VMHost, Key, Label, Policy, Running, Required

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-03 — Lockdown Mode/benzer yönetim kısıtı uygulandı mı ve istisna süreçleri kayıtlı mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Hosta doğrudan erişim riskini azaltıp yönetimi merkezileştirmek.
- **Olası Riskler:** Direkt host konfigürasyonunda denetimsiz değişiklik.
- **Beklenen Kanıt:** Lockdown durumu raporu, istisna listeleri
- **Kanıta Ulaşım Yöntemi:** vCenter konfigürasyonundan lockdown raporu alınır, istisna loglarının onay döngüsü doğrulanır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VMware vCenter/ESXi güvenlik belgeleri, NIST SP 800-53 (AC-3)
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 5.1.1.4 (gerekli olmayan servisler ve erişim kanalları kapatılmalı)
- **İyi Uygulama (Standart/Baseline):** CIS VMware ESXi 8.0 Benchmark v1.3.0, 3.20 (L1) Host must enable lockdown mode (Normal veya Strict)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-04 — Host zaman senkronizasyonu (time synchronization / NTP) güvenilir bir zaman kaynağına bağlı mı?

**Öncelik:** Orta · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Olay saatlerinin doğruluğunu garanti etmek.
- **Olası Riskler:** Log korelasyonunda hatalı zaman nedeniyle yanlış olay sıralaması.
- **Beklenen Kanıt:** NTP konfigürasyonu, zaman kaydırma ölçüm raporu
- **Kanıta Ulaşım Yöntemi:** Tüm hosts üzerinde NTP durum görüntüsü alınır ve referans saat sunucularıyla karşılaştırılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (AU-8), CIS ESXi NTP kontrolü
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 5.1.1.11 (sunucularda NTP ile zaman senkronizasyonu sağlanmalı), BDDK-BSY Md. 13/1-b (iz kayıtları tarih, saat ve zaman dilimi bilgisi barındırmalı)
- **İyi Uygulama (Standart/Baseline):** CIS VMware ESXi 7.0 Benchmark v1.5.0, 2.1 (L1) Ensure NTP time synchronization is configured properly, CIS VMware ESXi 8.0 Benchmark v1.3.0, 2.6 (L1) reliable time synchronization sources ve 2.7 (L1) time sync services enabled and running — Audit: Get-VMHost | Select Name, @{N="NTPSetting",E={$_ | Get-VMHostNtpServer}}

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-05 — Yönetim ve API bağlantılarında TLS/sertifika ayarları güvenli mi?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Kriptografik zayıflıklardan doğan interception riskini azaltmak.
- **Olası Riskler:** Eski protokollerle MITM veya oturum taklitleme.
- **Beklenen Kanıt:** TLS sürüm listesi, sertifika envanteri, expiration raporu
- **Kanıta Ulaşım Yöntemi:** Yönetim endpoint test araçlarıyla TLS/sertifika durumları kontrol edilir, eski sürümler tespit edilirse risk notu verilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-52r2, CIS secure protocols
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 4.3.1.2 (güncel ve güvenli kripto algoritmalar kullanılmalı), CBDDO 4.3.1.3 (anahtar uzunlukları yeterli olmalı), CBDDO 4.3.1.4 (sertifikaların geçerlilik süreleri takip edilmeli), CBDDO 4.3.1.5 (sertifika iptal kontrolü yapılmalı), CBDDO 4.3.1.6 (sertifikalar merkezi olarak yönetilmeli), CBDDO 4.3.1.7 (güvenli protokoller kullanılmalı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-06 — Host firmware/BMC fiziksel güvenlik kontrolleri ve bütünlük süreçleri düzenli izleniyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Alt seviye kalıcılık (firmware) saldırılarını azaltmak.
- **Olası Riskler:** Yetkisiz firmware değişikliğiyle kalıcı erişim.
- **Beklenen Kanıt:** Firmware envanteri, upgrade logları, fiziksel erişim denetimi
- **Kanıta Ulaşım Yöntemi:** CMDB'de host-id bazlı firmware kayıtları ile sahaya/operasyon notları karşılaştırılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (CM-8), üretici güvenlik ve fiziksel güvenlik belgeleri
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 16/1 (yama yönetimi prosedürü), CBDDO 3.1.9.1 (üretici desteği devam eden kararlı sürümler, güvenlik duyuruları takip edilmeli)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-07 — ESXi: BMC yönetim güvenliği kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-02 · **İlişkili üst kontrol:** `KG03-06`

- **Denetim Amacı:** BMC üzerinden bağımsız host erişim yolunun kapatılmasını doğrulamak.
- **Olası Riskler:** BMC ele geçirilirse ESXi/PAM kontrollerinden bağımsız konsol veya sanal medya erişimiyle bütün host etkilenebilir. + RISK-B
- **Beklenen Kanıt:** BMC rol/hesap ve servis exportu, yönetim ağı (management network) kuralları, sertifika ve kimlik doğrulama ayarları.
- **Kanıta Ulaşım Yöntemi:** Fiziksel sunucunun üreticisi/modeliyle eşleşen BMC/BIOS/UEFI yönetiminden ilgili hesap, port, saat, log veya CPU özelliğini salt okunur (read-only) görüntüleyin. Model bilinmediğinden iDRAC/iLO için kesin menü yolu verilmez; firmware ekran başlığı ve model kanıta eklenir.
- **Kabul Ölçütleri:** BMC'de varsayılan/ortak yönetici kimliği olmamalı, erişim yönetim ağlarıyla sınırlı, gereksiz servisler kapalı ve yetkiler görevle uyumlu olmalı. Desteklenen MFA ve dizin entegrasyonu ayrıca incelenir.
- **İnceleme ve Test Adımları:** Uzaktan konsol/sanal medya dahil tüm BMC erişim yollarını rol matrisiyle karşılaştır; tenant ağından erişim reddini kontrollü testle doğrula. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** BMC rol/hesap ve servis exportu, yönetim ağı (management network) kuralları, sertifika ve kimlik doğrulama ayarları. + KAYIT-B
- **Kanıtın Sınırları:** İzleme ve uzaktan kurtarma araçları BMC servislerine bağımlı olabilir. + SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:1.5; CIS-ESX8:1.8
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 16/1 (yama yönetimi prosedürü); CBDDO 3.1.9.1 (üretici desteği devam eden kararlı sürümler; güvenlik duyurularının takibi)
- **Teknik Referanslar:** CIS-ESX8:1.5; CIS-ESX8:1.8 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-08 — ESXi: DCUI Idle Session Timeout kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-03 · **İlişkili üst kontrol:** `KG03-02`

- **Denetim Amacı:** Boşta kalan konsol oturumunun otomatik kapanmasını doğrulamak.
- **Olası Riskler:** Gözetimsiz konsol oturumu yetkisiz host yönetimine izin verebilir. + RISK-B
- **Beklenen Kanıt:** Her host için DcuiTimeOut etkin değeri, kontrollü boşta oturum testi.
- **Kanıta Ulaşım Yöntemi:** AS-ADV
- **Kabul Ölçütleri:** UserVars.DcuiTimeOut pozitif ve en çok 600 saniye olmalı.
- **İnceleme ve Test Adımları:** Saniye birimini ve 0/sınırsız durumunu kontrol et; örnek test hostunda oturum davranışını doğrula. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** Her host için DcuiTimeOut etkin değeri, kontrollü boşta oturum testi. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:3.7; CIS-ESX7:5.1
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 14/7 (bağlantının süresi kısıtlanır)
- **Teknik Referanslar:** CIS-ESX8:3.7; CIS-ESX7:5.1 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.; VMW-SCG kaynak varyantları: esxi-8.dcui-timeout. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-09 — ESXi: Shell ve SSH Idle Session Timeout kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-04 · **İlişkili üst kontrol:** `KG03-02`

- **Denetim Amacı:** Boşta kalan yetkili shell oturumunun kapanmasını doğrulamak.
- **Olası Riskler:** Boşta kalan yetkili shell, host ve bağlı müşteriler için yetkisiz komut çalıştırma fırsatı yaratır. + RISK-B
- **Beklenen Kanıt:** ESXiShellInteractiveTimeOut çıktısı ve boşta oturum testi.
- **Kanıta Ulaşım Yöntemi:** AS-ADV
- **Kabul Ölçütleri:** UserVars.ESXiShellInteractiveTimeOut pozitif ve en çok 300 saniye olmalı. Bu ölçüt oturum içindir.
- **İnceleme ve Test Adımları:** Oturum süresini servis kullanılabilirlik süresinden ayır; ayar ve fiili kapanma davranışını eşleştir. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** ESXiShellInteractiveTimeOut çıktısı ve boşta oturum testi. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:3.8; CIS-ESX7:5.8
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 14/7 (bağlantının süresi kısıtlanır)
- **Teknik Referanslar:** CIS-ESX8:3.8; CIS-ESX7:5.8 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.; VMW-SCG kaynak varyantları: esxi-8.shell-interactive-timeout. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-10 — ESXi: Shell Service Availability Timeout kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-05 · **İlişkili üst kontrol:** `KG03-02`

- **Denetim Amacı:** Shell servisinin açık kalma süresinin sınırlı olmasını doğrulamak.
- **Olası Riskler:** Bakım için açılan yönetim servisi gereksiz yere erişilebilir kalabilir. + RISK-B
- **Beklenen Kanıt:** ESXiShellTimeOut etkin değeri, servis açılma/kapanma kayıtları.
- **Kanıta Ulaşım Yöntemi:** AS-ADV
- **Kabul Ölçütleri:** UserVars.ESXiShellTimeOut pozitif ve en çok 3600 saniye olmalı. Boşta oturum ayarı bunun yerine kullanılamaz.
- **İnceleme ve Test Adımları:** Servis süre ayarını ayrı kontrol et; ESXiShellInteractiveTimeOut kanıtıyla kapatma. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** ESXiShellTimeOut etkin değeri, servis açılma/kapanma kayıtları. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:3.9; CIS-ESX7:5.9
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 14/7 (bağlantının süresi kısıtlanır)
- **Teknik Referanslar:** CIS-ESX8:3.9; CIS-ESX7:5.9 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.; VMW-SCG kaynak varyantları: esxi-8.shell-timeout. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-11 — ESXi: API ve Host Client oturum sınırları kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-10 · **İlişkili üst kontrol:** `KG03-01`

- **Denetim Amacı:** Yönetim arayüzü oturumlarının süreyle sınırlı olmasını doğrulamak.
- **Olası Riskler:** Unutulan API veya tarayıcı oturumu yerel shell kapalıyken de ortak yönetim erişimini sürdürebilir. + RISK-B
- **Beklenen Kanıt:** Config.HostAgent.vmacore.soap.sessionTimeout; UserVars.HostClientSessionTimeout; onaylı süreler.
- **Kanıta Ulaşım Yöntemi:** AS-ADV
- **Kabul Ölçütleri:** SOAP/API ve Host Client için onaylı pozitif süreler tanımlı olmalı, iki ayrı ayar ayrı test edilir. Kaynakta evrensel bir sayı verilmez.
- **İnceleme ve Test Adımları:** İki arayüzde etkin ayar ve kontrollü idle oturum davranışını ayrı doğrula. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** Config.HostAgent.vmacore.soap.sessionTimeout. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:3.16; CIS-ESX8:3.17
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 14/7 (bağlantının süresi kısıtlanır)
- **Teknik Referanslar:** CIS-ESX8:3.16; CIS-ESX8:3.17 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.; VMW-SCG kaynak varyantları: esxi-8.api-soap-timeout, esxi-8.host-client-session-timeout. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-12 — ESXi: Lockdown ve bypass hesapları kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-11 · **İlişkili üst kontrol:** `KG03-03`

- **Denetim Amacı:** Hosta doğrudan erişimin kısıtlanmasını ve bypass hesaplarının kontrolünü doğrulamak.
- **Olası Riskler:** Geniş bypass listesi vCenter/PAM ayrımını atlatır; kurtarma yolu olmayan Strict mod ise yönetim kaybında hostu erişilemez kılabilir. + RISK-B
- **Beklenen Kanıt:** Lockdown modu, DCUI.Access, Exception Users, acil erişim ve kurtarma test kaydı.
- **Kanıta Ulaşım Yöntemi:** Host Security Profile içindeki Lockdown Mode ve Exception Users listesini, Advanced System Settings içindeki DCUI.Access ile birlikte okuyun; acil erişim kimliğini PAM/IdP kaydıyla eşleştirin.
- **Kabul Ölçütleri:** L1: Normal veya Strict, L2 seçilmişse Strict. DCUI.Access ve Exception Users yalnız onaylı bypass hesaplarını kapsamalı. Normal ve Strict aynı host için iki ayrı zorunluluk değildir.
- **İnceleme ve Test Adımları:** Profili belirle; modun gerçek enum/değerini kontrol et. Yalnız adminDisabled boolean sonucu Normal/Strict ayrımını kanıtlamaz. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** Lockdown modu, DCUI.Access, Exception Users, acil erişim ve kurtarma test kaydı. + KAYIT-B
- **Kanıtın Sınırları:** vCenter bağlantı kaybı ve DCUI kapanması için bağımsız kurtarma yolu test edilmiş olmalı. + SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:3.18; CIS-ESX8:3.19; CIS-ESX8:3.20; CIS-ESX8:3.21; CIS-ESX7:4.8; CIS-ESX7:5.5; CIS-ESX7:5.6; CIS-ESX7:5.10
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 5.1.1.4 (gerekli olmayan servisler ve erişim kanalları kapatılmalı)
- **İyi Uygulama (Standart/Baseline):** CIS VMware ESXi 8.0 Benchmark v1.3.0, 3.20 (L1) Host must enable lockdown mode (Normal veya Strict)
- **Teknik Referanslar:** CIS-ESX8:3.18; CIS-ESX8:3.19; CIS-ESX8:3.20; CIS-ESX8:3.21; CIS-ESX7:4.8; CIS-ESX7:5.5; CIS-ESX7:5.6; CIS-ESX7:5.10 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.; VMW-SCG kaynak varyantları: esxi-8.lockdown-dcui-access, esxi-8.lockdown-exception-users, esxi-8.lockdown-mode. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-13 — ESXi: Host oturum uyarı metinleri (login banner) kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-13 · **İlişkili üst kontrol:** `KG03-01`

- **Denetim Amacı:** Giriş yüzeylerinde onaylı kullanım bildiriminin tutarlı gösterilmesini doğrulamak.
- **Olası Riskler:** Yetkili kullanım ve izleme koşulları kullanıcılara tutarlı bildirilemez. + RISK-B
- **Beklenen Kanıt:** Annotations.WelcomeMessage, SSH Banner hedefi ve içerik, ekran örneği.
- **Kanıta Ulaşım Yöntemi:** AS-ADV
- **Kabul Ölçütleri:** DCUI/Host Client ve SSH uyarı metni kurumca onaylı kullanım bildirimiyle eşleşmeli.
- **İnceleme ve Test Adımları:** Her giriş yolunda doğru metni doğrula; hukuki etkinlik sonucu üretme. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** Annotations.WelcomeMessage, SSH Banner hedefi ve içerik, ekran örneği. + KAYIT-B
- **Kanıtın Sınırları:** DCUI görünümü ve otomasyon etkileşimi değişebilir. + SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:3.24; CIS-ESX8:3.25; CIS-ESX8:6.5.7
- **Teknik Referanslar:** CIS-ESX8:3.24; CIS-ESX8:3.25; CIS-ESX8:6.5.7 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.; VMW-SCG kaynak varyantları: esxi-8.annotations-welcomemessage, esxi-8.etc-issue, esxi-8.ssh-login-banner. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-14 — ESXi: CIM ve SNMP koşullu yetki sınırı kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-14 · **İlişkili üst kontrol:** `KG03-02`

- **Denetim Amacı:** İzleme servislerinin en az yetki (least privilege)yle sınırlandırılmasını doğrulamak.
- **Olası Riskler:** İzleme servisi ortak yönetici yetkisine veya yetkisiz veri aktarımına dönüşebilir. + RISK-B
- **Beklenen Kanıt:** Servis gereksinimi, hesap/yetki listesi, SNMP etkin yapılandırması ve hedefleri.
- **Kanıta Ulaşım Yöntemi:** SVC-SEC
- **Kabul Ölçütleri:** CIM/SNMP gerekiyorsa servis hesabı (service account) ve hedefler sınırlandırılmış olmalı, CIM için yalnız gerekli Host.Config.SystemManagement ve Host.CIM.CIMInteraction yetkileri değerlendirilir.
- **İnceleme ve Test Adımları:** Gereksizse servis kapatma kontrolüne bağla; gerekli servislerde hedef ve yetkiyi ürünün sürümlü izleme belgesiyle karşılaştır. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** Servis gereksinimi, hesap/yetki listesi, SNMP etkin yapılandırması ve hedefleri. + KAYIT-B
- **Kanıtın Sınırları:** Yetersiz yetki meşru donanım izlemesini bozabilir. + SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:6.1.1; CIS-ESX8:6.4.1; CIS-ESX7:2.5; CIS-ESX7:5.4
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 5.1.1.4 (gerekli olmayan servisler kapatılmalı)
- **Teknik Referanslar:** CIS-ESX8:6.1.1; CIS-ESX8:6.4.1; CIS-ESX7:2.5; CIS-ESX7:5.4 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-15 — ESXi: SSH daemon yetenek sınırlamaları (capability restrictions) kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-15 · **İlişkili üst kontrol:** `KG03-02`

- **Denetim Amacı:** SSH üzerinden yönetim ağı (management network) sınırlarının aşılamamasını doğrulamak.
- **Olası Riskler:** Yetkili SSH oturumu TCP/Unix socket tüneli veya kullanıcı ortamıyla yönetim ağı (management network) sınırlarını aşabilir. + RISK-B
- **Beklenen Kanıt:** Etkin sshd yapılandırması, Include/override bilgisi, onaylı forwarding ihtiyaçları.
- **Kanıta Ulaşım Yöntemi:** SSH-FILES
- **Kabul Ölçütleri:** GatewayPorts=no, HostbasedAuthentication=no, IgnoreRhosts=yes, AllowStreamLocalForwarding=no, AllowTcpForwarding=no, PermitTunnel=no, PermitUserEnvironment=no. Kaynakta izin verilen iş ihtiyacı istisnası ayrıca yazılır.
- **İnceleme ve Test Adımları:** Her parametreyi etkin değerinden kontrol et; yalnız örnek/durağan dosyanın varlığıyla uygun sonucu verme. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** Etkin sshd yapılandırması, Include/override bilgisi, onaylı forwarding ihtiyaçları. + KAYIT-B
- **Kanıtın Sınırları:** Meşru tünel kullanan yönetim iş akışları etkilenebilir. Shell erişimi olan kullanıcı kendi yönlendirme aracını çalıştırabilir; SSH forwarding ayarı tek başına tam ağ izolasyonu değildir. + SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:6.5.3; CIS-ESX8:6.5.4; CIS-ESX8:6.5.8; CIS-ESX8:6.5.9; CIS-ESX8:6.5.10; CIS-ESX8:6.5.11; CIS-ESX8:6.5.12; SSH-MAN
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.9 (sanallaştırma yönetim ortamına erişim kontrolü)
- **Teknik Referanslar:** CIS-ESX8:6.5.3; CIS-ESX8:6.5.4; CIS-ESX8:6.5.8; CIS-ESX8:6.5.9; CIS-ESX8:6.5.10; CIS-ESX8:6.5.11; CIS-ESX8:6.5.12; SSH-MAN Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.; VMW-SCG kaynak varyantları: esxi-8.ssh-gateway-ports, esxi-8.ssh-host-based-auth, esxi-8.ssh-rhosts, esxi-8.ssh-stream-local-forwarding, esxi-8.ssh-tcp-forwarding, esxi-8.ssh-tunnels, esxi-8.ssh-user-environment. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-16 — ESXi: SSH keepalive süre parametreleri kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-16 · **İlişkili üst kontrol:** `KG03-02`

- **Denetim Amacı:** Sahipsiz SSH bağlantılarının tespit ve kapatılmasını doğrulamak.
- **Olası Riskler:** Ölü bağlantıların açık kalması kaynak tüketimine ve sahipsiz yönetim bağlantılarına yol açabilir. + RISK-B
- **Beklenen Kanıt:** Etkin iki sshd değeri ve kurumun onaylı canlılık/süre politikası.
- **Kanıta Ulaşım Yöntemi:** SSH-FILES
- **Kabul Ölçütleri:** ClientAliveCountMax ve ClientAliveInterval onaylı bağlantı canlılık politikasıyla uyumlu olmalı. Bunlar kullanıcı klavye hareketsizliğini tek başına kanıtlayan ölçüt olarak kullanılmaz.
- **İnceleme ve Test Adımları:** Sayısal değerleri kaynakta tanımlanmayan bir eşik uydurmadan karşılaştır; idle shell kontrolünü Shell ve SSH Idle Session Timeout sorusuyla ayrı yürüt. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** Etkin iki sshd değeri ve kurumun onaylı canlılık/süre politikası. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:6.5.5; CIS-ESX8:6.5.6; SSH-MAN
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 14/7 (bağlantının süresi kısıtlanır)
- **Teknik Referanslar:** CIS-ESX8:6.5.5; CIS-ESX8:6.5.6; SSH-MAN Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.; VMW-SCG kaynak varyantları: esxi-8.ssh-idle-timeout-count, esxi-8.ssh-idle-timeout-interval. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-17 — ESXi: VM konsol sınırları kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-17 · **İlişkili üst kontrol:** `KG03-01`

- **Denetim Amacı:** Konsol oturumlarının yetki ve süreyle sınırlandırılmasını doğrulamak.
- **Olası Riskler:** Paylaşılan konsol oturumu başka operatörün açık kimliğini kullanma ve müşteri ekranını izleme fırsatı yaratır. + RISK-B
- **Beklenen Kanıt:** VM console ayarları, konsol rol yetkileri, guest desktop autolock değeri/testi.
- **Kanıta Ulaşım Yöntemi:** AS-ADV
- **Kabul Ölçütleri:** RemoteDisplay.maxConnections=1, ESXi 8'de son konsol kapanınca misafir kilitleme ayarı etkin olmalı. Konsol kullanım yetkisi onaylı rollerle sınırlı olmalı.
- **İnceleme ve Test Adımları:** Eşzamanlı ikinci konsol ve son konsol kapanışı testlerini ayrı kaydet; OS kilit desteğini doğrula. + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** VM console ayarları, konsol rol yetkileri, guest desktop autolock değeri/testi. + KAYIT-B
- **Kanıtın Sınırları:** Ortak sorun giderme ve misafir OS (guest OS) kilit desteği etkilenebilir. + SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:7.5; CIS-ESX8:7.6; CIS-ESX7:8.1.1; CIS-ESX7:8.3.2
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 11/6 (yetkilendirme; en az yetki)
- **Teknik Referanslar:** CIS-ESX8:7.5; CIS-ESX8:7.6; CIS-ESX7:8.1.1; CIS-ESX7:8.3.2 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.; VMW-SCG kaynak varyantları: vm-8.limit-console-connections. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-18 — ESXi: Son VM konsol bağlantısı kapandığında misafir oturumu (guest session) kilitleniyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) · **Kaynak:** G1-22 · **İlişkili üst kontrol:** `KG03-01`

- **Denetim Amacı:** Konsol kapanışında misafir oturumu (guest session) kilidinin etkin olmasını doğrulamak.
- **Olası Riskler:** Açık kalan misafir masaüstüne daha sonra bağlanan kullanıcı önceki yöneticinin oturumunu kullanabilir; konsol erişim yetkisi bu riski ortadan kaldırmaz.
- **Beklenen Kanıt:** Hedef nesne/sürüm bilgisi ve VM Settings etkin ayar çıktısı; onaylı baseline ve istisnalar.
- **Kanıta Ulaşım Yöntemi:** SCG-RO(VM Settings)
- **Kabul Ölçütleri:** SCG vSphere 8 U3 profili seçilmişse: tools.guest.desktop.autolock = TRUE. Başka sürüm veya kaynak profiline otomatik uygulanmaz.
- **İnceleme ve Test Adımları:** TEST-1
- **İncelenecek Kayıtlar ve Örnekleme:** Hedef nesne/sürüm bilgisi ve VM Settings etkin ayar çıktısı; onaylı baseline ve istisnalar. + KAYIT-B2
- **Kanıtın Sınırları:** SINIR-2

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VMW-SCG: vm-8.vmrc-lock
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 14/7 (kullanıcı belli aralıklarla kimliğini tekrar doğrulamaya zorlanır)
- **Teknik Referanslar:** VMW-SCG: vm-8.vmrc-lock; VMW-SCG kaynak varyantları: vm-8.vmrc-lock. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** VMW-SCG: vm-8.vmrc-lock
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-19 — ESXi: Host ve VM dvFilter erişimi kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-14 · **İlişkili üst kontrol:** `KG03-01`

- **Denetim Amacı:** dvFilter bağlantılarının onaylı modüllerle sınırlı olmasını doğrulamak.
- **Olası Riskler:** Yetkisiz filtre bağlantısı müşteri trafiğini görme veya değiştirme imkanı doğurabilir. + RISK-C + RISK-B
- **Beklenen Kanıt:** Host DVFilterBindIpAddress ve VM filter eşlemeleri; güvenlik appliance envanteri.
- **Kanıta Ulaşım Yöntemi:** AS-ADV
- **Kabul Ölçütleri:** Host bind IP kullanılmıyorsa boş; kullanılıyorsa onaylı appliance IP'si olmalı. VM ethernetX.filterY.name yalnız gerçek koruma modülüne bağlanmalı; kaynak örnek adı gerçek değer sayılmaz.
- **İnceleme ve Test Adımları:** Host ve VM ayarlarını ayrı incele; her açık bağlantının onaylı modülle ilişkisini doğrula. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** Host DVFilterBindIpAddress ve VM filter eşlemeleri. + KAYIT-B
- **Kanıtın Sınırları:** NSX veya üçüncü taraf (third-party) güvenlik ürünlerinin ihtiyaç duyduğu filter kaldırılmaz. + SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:5.3; CIS-ESX8:7.20; CIS-ESX7:2.6; CIS-ESX7:8.4.1
- **Teknik Referanslar:** CIS-ESX8:5.3; CIS-ESX8:7.20; CIS-ESX7:2.6; CIS-ESX7:8.4.1 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.; VMW-SCG kaynak varyantları: esxi-8.network-dvfilter, vm-8.dvfilter. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-20 — ESXi: Standard vSwitch MAC güvenliği kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-15 · **İlişkili üst kontrol:** `KG06-01`

- **Denetim Amacı:** Standard vSwitch güvenlik politikalarının Reject olmasını doğrulamak.
- **Olası Riskler:** MAC taklidi (MAC spoofing) ve gereksiz dinleme imkanı müşteri ağ ayrımını zayıflatır. + RISK-C + RISK-B
- **Beklenen Kanıt:** Standard switch/port group security policy ve override değerleri, istisna VM listesi.
- **Kanıta Ulaşım Yöntemi:** Hedef hostun standard virtual switch ve port group yapılandırmasında Security ve VLAN özelliklerini okuyun. Port group override ve fiziksel uplink native/trunk VLAN bilgilerini birlikte alın; VDS ile standard switch ayarlarını karıştırmayın.
- **Kabul Ölçütleri:** Standard vSwitch ve port grubu (port group) için Forged Transmits, MAC Changes ve Promiscuous Mode Reject olmalı; ihtiyaç istisnaları ayrı port grubunda ve yetkili VM'lerle sınırlı olmalı.
- **İnceleme ve Test Adımları:** Üst switch ile port grubu (port group) etkin değerlerini karşılaştır; üç ayarı ayrı alt sonuçla kaydet. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** Standard switch/port group security policy ve override değerleri, istisna VM listesi. + KAYIT-B
- **Kanıtın Sınırları:** Kümeleme ve ağ appliance iş yükleri istisna gerektirebilir. + SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:5.6; CIS-ESX8:5.7; CIS-ESX8:5.8; CIS-ESX7:7.1; CIS-ESX7:7.2; CIS-ESX7:7.3
- **Teknik Referanslar:** CIS-ESX8:5.6; CIS-ESX8:5.7; CIS-ESX8:5.8; CIS-ESX7:7.1; CIS-ESX7:7.2; CIS-ESX7:7.3 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.; VMW-SCG kaynak varyantları: esxi-8.network-reject-forged-transmit-standardswitch, esxi-8.network-reject-mac-changes-standardswitch, esxi-8.network-reject-promiscuous-mode-standardswitch. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-21 — ESXi: Standard vSwitch VLAN sınırları kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-16 · **İlişkili üst kontrol:** `KG06-02`

- **Denetim Amacı:** VLAN sınırlarının yetkili iş yükleriyle sınırlı olmasını doğrulamak.
- **Olası Riskler:** Geniş veya yanlış etiketleme VM'ye başka tenant VLAN'larına ulaşma imkanı verebilir. + RISK-C + RISK-B
- **Beklenen Kanıt:** Port group VLAN listesi, fiziksel uplink native/reserved VLAN bilgisi, VGT ihtiyacı.
- **Kanıta Ulaşım Yöntemi:** Hedef hostun standard virtual switch ve port group yapılandırmasında Security ve VLAN özelliklerini okuyun. Port group override ve fiziksel uplink native/trunk VLAN bilgilerini birlikte alın; VDS ile standard switch ayarlarını karıştırmayın.
- **Kabul Ölçütleri:** Native VLAN ve fiziksel switchin ayrılmış VLAN değerleri izinsiz kullanılmamalı; VLAN 4095/VGT sadece onaylı iş yükünde. ESXi 7'de VLAN 0 koşulu kendi maddesinde ayrıca değerlendirilir.
- **İnceleme ve Test Adımları:** Mantıksal ve fiziksel uçların VLAN kapsamını karşılaştır; özel değerlere ilişkin sürüm koşullarını ayrı kontrol et. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** Port group VLAN listesi, fiziksel uplink native/reserved VLAN bilgisi, VGT ihtiyacı. + KAYIT-B
- **Kanıtın Sınırları:** VGT kullanan ağ appliance'ları için işlevsel test gerekir. + SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS-ESX8:5.9; CIS-ESX8:5.10; CIS-ESX7:7.4; CIS-ESX7:7.5; CIS-ESX7:7.6
- **Teknik Referanslar:** CIS-ESX8:5.9; CIS-ESX8:5.10; CIS-ESX7:7.4; CIS-ESX7:7.5; CIS-ESX7:7.6 Kesin PDF/basılı sayfa, profil ve madde başlığı: CIS Eşlemesi sayfasında aynı Kaynak + Madde kaydı. Erişim için kaynağın Audit bölümü.; VMW-SCG kaynak varyantları: esxi-8.network-vgt. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX7; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-22 — ESXi: Intel SGX kapsamı kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Düşük · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı · **Kaynak:** G3-02 · **İlişkili üst kontrol:** `KG03-01`

- **Denetim Amacı:** SGX etkinliğinin profil kapsamıyla uyumunu doğrulamak.
- **Olası Riskler:** — (kaynak metin kırpıldı)
- **Beklenen Kanıt:** — (kaynak metin kırpıldı)
- **Kanıta Ulaşım Yöntemi:** — (kaynak metin kırpıldı)
- **Kabul Ölçütleri:** SGX destekleyen ve seçilmiş L2 kapsamındaki Intel hostlarda SGX etkinliği BIOS/UEFI üzerinden doğrulanmalı.
- **İnceleme ve Test Adımları:** — (kaynak metin kırpıldı)
- **İncelenecek Kayıtlar ve Örnekleme:** — (kaynak metin kırpıldı)
- **Kanıtın Sınırları:** — (kaynak metin kırpıldı)

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** — (kaynak metin kırpıldı)
- **Teknik Referanslar:** — (kaynak metin kırpıldı)
- **Erişim Referansları:** — (kaynak metin kırpıldı)
- **Denetim Yöntemi Referansları:** — (kaynak metin kırpıldı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-23 — ESXi: Gereksiz host yönetim servisleri kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı · **Kaynak:** G3-03 · **İlişkili üst kontrol:** `KG03-02`

- **Denetim Amacı:** Gereksiz yönetim servislerinin kapalı olmasını doğrulamak.
- **Olası Riskler:** — (kaynak metin kırpıldı)
- **Beklenen Kanıt:** — (kaynak metin kırpıldı)
- **Kanıta Ulaşım Yöntemi:** — (kaynak metin kırpıldı)
- **Kabul Ölçütleri:** SSH, ESXi Shell ve MOB normal işletimde kapalı olmalı. ESXi 8 için SLP kapalı; CIM/SNMP gerekiyorsa belgeli koşullu sıkılaştırma ayrıca uygulanmalı.
- **İnceleme ve Test Adımları:** — (kaynak metin kırpıldı)
- **İncelenecek Kayıtlar ve Örnekleme:** — (kaynak metin kırpıldı)
- **Kanıtın Sınırları:** — (kaynak metin kırpıldı)

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** — (kaynak metin kırpıldı)
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 5.1.1.4 (gerekli olmayan servisler kapatılmalı)
- **Teknik Referanslar:** — (kaynak metin kırpıldı)
- **Erişim Referansları:** — (kaynak metin kırpıldı)
- **Denetim Yöntemi Referansları:** — (kaynak metin kırpıldı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-24 — ESXi: Gereksiz VM donanımı ve 3D kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı · **Kaynak:** G3-04 · **İlişkili üst kontrol:** `KG03-01`

- **Denetim Amacı:** Gereksiz donanım yüzeyinin kaldırılmasını doğrulamak.
- **Olası Riskler:** — (kaynak metin kırpıldı)
- **Beklenen Kanıt:** — (kaynak metin kırpıldı)
- **Kanıta Ulaşım Yöntemi:** — (kaynak metin kırpıldı)
- **Kabul Ölçütleri:** Gerekmeyen aygıtlar kaldırılmış/devre dışı olmalı; 3D ve passthrough yalnız kaynak profiline göre gereksinimi belgeli iş yüklerinde. Aygıt ve L1/L2 profil ayrımı için CIS Eşlemesi sayfasındaki ilgili kaynak maddeleri incelenir; ESXi 7 ve 8 önerileri birbirine uygulanmaz.
- **İnceleme ve Test Adımları:** — (kaynak metin kırpıldı)
- **İncelenecek Kayıtlar ve Örnekleme:** — (kaynak metin kırpıldı)
- **Kanıtın Sınırları:** — (kaynak metin kırpıldı)

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** — (kaynak metin kırpıldı)
- **Teknik Referanslar:** — (kaynak metin kırpıldı)
- **Erişim Referansları:** — (kaynak metin kırpıldı)
- **Denetim Yöntemi Referansları:** — (kaynak metin kırpıldı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-25 — ESXi: Guest OS'nin aygıt bağlama/değiştirme (device connect/edit) yetkisi kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı · **Kaynak:** G3-05 · **İlişkili üst kontrol:** `KG03-01`

- **Denetim Amacı:** Misafir OS (guest OS)'nin aygıt bağlama yetkisinin kısıtlanmasını doğrulamak.
- **Olası Riskler:** — (kaynak metin kırpıldı)
- **Beklenen Kanıt:** — (kaynak metin kırpıldı)
- **Kanıta Ulaşım Yöntemi:** — (kaynak metin kırpıldı)
- **Kabul Ölçütleri:** isolation.device.edit.disable=TRUE ve isolation.device.connectable.disable=TRUE olmalı.
- **İnceleme ve Test Adımları:** — (kaynak metin kırpıldı)
- **İncelenecek Kayıtlar ve Örnekleme:** — (kaynak metin kırpıldı)
- **Kanıtın Sınırları:** — (kaynak metin kırpıldı)

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** — (kaynak metin kırpıldı)
- **Teknik Referanslar:** — (kaynak metin kırpıldı)
- **Erişim Referansları:** — (kaynak metin kırpıldı)
- **Denetim Yöntemi Referansları:** — (kaynak metin kırpıldı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-26 — ESXi: Gereksiz Tools bilgi/işlev modülleri kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı · **Kaynak:** G3-06 · **İlişkili üst kontrol:** `KG03-01`

- **Denetim Amacı:** Tools modüllerinin profil bazlı kapatılmasını doğrulamak.
- **Olası Riskler:** — (kaynak metin kırpıldı)
- **Beklenen Kanıt:** — (kaynak metin kırpıldı)
- **Kanıta Ulaşım Yöntemi:** — (kaynak metin kırpıldı)
- **Kabul Ölçütleri:** Gerekmiyorsa: globalconf.enabled=false; containerinfo.poll-interval=0; appinfo.disabled=true; gueststoreupgrade.policy=off; servicediscovery.disabled=true; guestoperations.disabled=true. Windows MSI transforms=false. L1: GlobalConf, Guest Store Upgrade ve Windows MSI transforms; L2: ContainerInfo, Appinfo, Service Discovery ve Guest Operations. Kaynak maddeleri CIS Eşlemesi sayfasındadır; guest OS için ilgili Audit bölümü kullanılır.
- **İnceleme ve Test Adımları:** — (kaynak metin kırpıldı)
- **İncelenecek Kayıtlar ve Örnekleme:** — (kaynak metin kırpıldı)
- **Kanıtın Sınırları:** — (kaynak metin kırpıldı)

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** — (kaynak metin kırpıldı)
- **Teknik Referanslar:** — (kaynak metin kırpıldı)
- **Erişim Referansları:** — (kaynak metin kırpıldı)
- **Denetim Yöntemi Referansları:** — (kaynak metin kırpıldı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-27 — ESXi: ESXi 7 gereksiz guest işlevleri kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı · **Kaynak:** G3-07 · **İlişkili üst kontrol:** `KG03-01`

- **Denetim Amacı:** Guest OS baseline uyumunu doğrulamak.
- **Olası Riskler:** — (kaynak metin kırpıldı)
- **Beklenen Kanıt:** — (kaynak metin kırpıldı)
- **Kanıta Ulaşım Yöntemi:** — (kaynak metin kırpıldı)
- **Kabul Ölçütleri:** Guest OS içinde gerekmeyen servis ve işlevler kurumsal OS baseline değerine göre kapalı olmalı.
- **İnceleme ve Test Adımları:** — (kaynak metin kırpıldı)
- **İncelenecek Kayıtlar ve Örnekleme:** — (kaynak metin kırpıldı)
- **Kanıtın Sınırları:** — (kaynak metin kırpıldı)

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** — (kaynak metin kırpıldı)
- **Teknik Referanslar:** — (kaynak metin kırpıldı)
- **Erişim Referansları:** — (kaynak metin kırpıldı)
- **Denetim Yöntemi Referansları:** — (kaynak metin kırpıldı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-28 — ESXi: ESXi 7 guest-host masaüstü entegrasyonları kontrolü, kabul ölçütlerini karşılıyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı · **Kaynak:** G3-08 · **İlişkili üst kontrol:** `KG03-01`

- **Denetim Amacı:** Guest-host masaüstü entegrasyon parametrelerinin tek tek doğrulanmasını sağlamak.
- **Olası Riskler:** — (kaynak metin kırpıldı)
- **Beklenen Kanıt:** — (kaynak metin kırpıldı)
- **Kanıta Ulaşım Yöntemi:** — (kaynak metin kırpıldı)
- **Kabul Ölçütleri:** CIS ESXi 7 profili için her parametre ayrı doğrulanır: isolation.tools.ghi.autologon.disable = TRUE (CIS 8.4.2); isolation.bios.bbs.disable = TRUE (CIS 8.4.3); isolation.tools.ghi.protocolhandler.info.disable = TRUE (CIS 8.4.4); isolation.tools.unity.taskbar.disable = TRUE (CIS 8.4.5); isolation.tools.unityActive.disable = TRUE (CIS 8.4.6); isolation.tools.unity.windowContents.disable = TRUE (CIS 8.4.7); isolation.tools.unity.push.update.disable = TRUE (CIS 8.4.8); isolation.tools.vmxDnDVersionGet.disable = TRUE (CIS 8.4.9); isolation.tools.guestDnDVersionSet.disable = TRUE (CIS 8.4.10); isolation.ghi.host.shellAction.disable = TRUE (CIS 8.4.11); isolation.tools.dispTopoRequest.disable = TRUE (CIS 8.4.12); isolation.tools.trashFolderState.disable = TRUE (CIS 8.4.13); isolation.tools.ghi.trayicon.disable = TRUE (CIS 8.4.14); isolation.tools.unity.disable = TRUE (CIS 8.4.15); isolation.tools.unityInterlockOperation.disable = TRUE (CIS 8.4.16); isolation.tools.getCreds.disable = TRUE (CIS 8.4.17); isolation.tools.hgfsServerSet.disable = TRUE (CIS 8.4.18); isolation.tools.ghi.launchmenu.change = TRUE (CIS 8.4.19); isolation.tools.memSchedFakeSampleStats.disable = TRUE (CIS 8.4.20); isolation.tools.setGUIOptions.enable = FALSE veya ayar yok (CIS 8.4.23). Parametre adının disable/enable son ekindan beklenen değer çıkarılmaz; isolation.tools.ghi.launchmenu.change için de kaynak değeri TRUE kullanılır.
- **İnceleme ve Test Adımları:** — (kaynak metin kırpıldı)
- **İncelenecek Kayıtlar ve Örnekleme:** — (kaynak metin kırpıldı)
- **Kanıtın Sınırları:** — (kaynak metin kırpıldı)

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** — (kaynak metin kırpıldı)
- **Teknik Referanslar:** — (kaynak metin kırpıldı)
- **Erişim Referansları:** — (kaynak metin kırpıldı)
- **Denetim Yöntemi Referansları:** — (kaynak metin kırpıldı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-29 — ESXi: İmzasız veya kurulu olmayan ikili dosyaların host üzerinde çalıştırılması engellenmiş mi (VMkernel.Boot.execInstalledOnly)?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) · **Kaynak:** v3-GAP-01 · **İlişkili üst kontrol:** `KG03-01`

- **Denetim Amacı:** Saldırganın host üzerine kendi ikili dosyasını (şifreleyici, arka kapı, tünel aracı) bırakıp çalıştırmasını hypervisor seviyesinde engellemek.
- **Olası Riskler:** ESXi fidye yazılımı olaylarının ortak adımı, yönetim erişimi elde edildikten sonra host üzerinde özel bir şifreleyici çalıştırmaktır. Ayar kapalıyken guest OS ve vCenter kontrollerinin tamamı baypas edilerek hypervisor seviyesinde kalıcılık sağlanabilir.
- **Beklenen Kanıt:** Tüm host'lar için VMkernel.Boot.execInstalledOnly değerinin salt okunur (read-only) çıktısı; ayarın boot yapılandırmasında kalıcı olduğunu gösteren kayıt; UEFI Secure Boot durum çıktısı; FALSE olan host'lar için onaylı istisna kaydı.
- **Kanıta Ulaşım Yöntemi:** vSphere Client > Host > Configure > System > Advanced System Settings > VMkernel.Boot.execInstalledOnly. PowerCLI karşılığı: Get-VMHost | Get-AdvancedSetting -Name VMkernel.Boot.execInstalledOnly | Select Entity, Name, Value. Komut sözdizimi kurumun PowerCLI/FortiOS benzeri sürüm farklılıklarına karşı çalıştırılmadan önce üretici dokümantasyonuyla teyit edilmelidir.
- **Kabul Ölçütleri:** Envanterdeki tüm ESXi host'larında VMkernel.Boot.execInstalledOnly = TRUE olmalı ve değer yeniden başlatma sonrası kalıcı olmalıdır. Ayar, UEFI Secure Boot ile birlikte etkin olmalıdır; Secure Boot etkin değilse bu ayar tek başına yeterli sayılmaz. FALSE olan host'lar süreli ve onaylı bir istisna kaydına bağlı olmalıdır.
- **İnceleme ve Test Adımları:** Host envanterinin tamamı için değeri oku ve FALSE olanları listele. Çalışma zamanı (runtime) değeri ile boot yapılandırmasını ayrı doğrula; yalnız tek bir ekran görüntüsüyle yetinme. Sonucu KG03-30 (Secure Boot) çıktısıyla birlikte değerlendir; iki ayardan biri eksikse kontrolü "uygun" kapatma.
- **İncelenecek Kayıtlar ve Örnekleme:** Tüm host envanteri üzerinden tam liste alınmalıdır; örnekleme (sampling) yapılacaksa farklı donanım modeli, ESXi sürümü ve küme temsil edilmelidir. Yeni eklenen host'lar ayrıca kontrol edilir.
- **Kanıtın Sınırları:** Yapılandırma kanıtı yalnız ölçüm anını gösterir; dönem boyunca etkin kaldığını kanıtlamaz — config drift veya değişiklik yönetimi kaydı ayrıca aranır. Secure Boot etkin değilken ayarın koruma değeri sınırlıdır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** v3 kapsam boşluğu analizi — ESXi fidye yazılımı sertleştirme kılavuzları
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 15 (güvenlik konfigürasyon yönetimi); CBDDO BİGR 3.1.9.6 (imaj bütünlüğünün denetlenmesi ve izlenmesi)
- **İyi Uygulama (Standart/Baseline):** NIST SP 800-53 Rev.5 CM-7 (en az işlevsellik), SI-7 (yazılım/bilgi bütünlüğü)
- **Teknik Referanslar:** VMware gelişmiş ayar adı: VMkernel.Boot.execInstalledOnly. CIS VMware ESXi 8.0 Benchmark — donanım/temel yapılandırma bölümündeki ilgili madde. NOT: kesin madde numarası bu turda doğrulanmamıştır; CIS Eşlemesi sayfası temin edildiğinde eşlenmelidir.
- **Erişim Referansları:** RO-VMW-ADV
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-30 — ESXi: Host'larda UEFI Secure Boot etkin mi ve etkinleştirilemeyen host'lar için onaylı istisna kaydı tutuluyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) · **Kaynak:** v3-GAP-02 · **İlişkili üst kontrol:** `KG03-01`

- **Denetim Amacı:** Boot zincirinin bütünlüğünü donanım seviyesinden başlatarak imzasız VIB, kernel modülü ve önyükleyici değişikliğini engellemek.
- **Olası Riskler:** Secure Boot kapalıyken saldırgan imzasız VIB veya değiştirilmiş önyükleyici yükleyerek yeniden başlatmaya dayanıklı kalıcılık kurabilir; imaj bütünlüğü doğrulaması etkisiz kalır.
- **Beklenen Kanıt:** Host bazında Secure Boot durum çıktısı; sunucu firmware ekranından alınmış model ve Secure Boot ayarı görüntüsü; desteklemeyen donanım için envanter işareti ve onaylı istisna kaydı.
- **Kanıta Ulaşım Yöntemi:** ESXi üzerinde salt okunur (read-only): /usr/lib/vmware/secureboot/bin/secureBoot.py -s . Ek olarak sunucu üreticisinin BIOS/UEFI yönetim ekranında Secure Boot durumu okunur; firmware ekran başlığı ve sunucu modeli kanıta eklenir. Model bilinmediğinden iDRAC/iLO için kesin menü yolu verilmemiştir.
- **Kabul Ölçütleri:** Donanımı destekleyen tüm host'larda UEFI Secure Boot etkin olmalıdır. Desteklemeyen veya etkinleştirilemeyen host'lar envanterde işaretli, gerekçesi yazılı ve süreli bir istisna kaydına bağlı olmalıdır. TPM ile birlikte değerlendirilir (KG03-31).
- **İnceleme ve Test Adımları:** Host envanterinin tamamı için durumu oku. Kapalı olanlar için donanım desteği olup olmadığını üretici uyumluluk listesiyle karşılaştır; desteklediği hâlde kapalı olanları ayrı bulgu adayı olarak işaretle. Üretimde Secure Boot etkinleştirme denemesi yapma.
- **İncelenecek Kayıtlar ve Örnekleme:** Tam host envanteri. Örnekleme yapılacaksa her donanım modeli ve ESXi sürümü temsil edilmelidir; istisna listesi ayrıca tam olarak incelenir.
- **Kanıtın Sınırları:** Secure Boot etkinliği yalnız ölçüm anını gösterir. Firmware seviyesindeki değişiklikler ESXi çıktısına yansımayabilir; BMC/firmware erişim kontrolü KG03-06 kapsamında ayrıca değerlendirilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** v3 kapsam boşluğu analizi — ESXi fidye yazılımı sertleştirme kılavuzları
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 15 (güvenlik konfigürasyon yönetimi); CBDDO BİGR 3.1.9.6 (imaj bütünlüğünün denetlenmesi ve izlenmesi)
- **İyi Uygulama (Standart/Baseline):** NIST SP 800-53 Rev.5 SI-7 (yazılım, bellenim ve bilgi bütünlüğü)
- **Teknik Referanslar:** CIS VMware ESXi 8.0 Benchmark — donanım bölümü Secure Boot maddesi. NOT: kesin madde numarası bu turda doğrulanmamıştır; CIS Eşlemesi sayfası temin edildiğinde eşlenmelidir.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-31 — ESXi: Host'larda TPM 2.0 mevcut ve vCenter üzerindeki host attestation durumu başarılı mı?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) · **Kaynak:** v3-GAP-03 · **İlişkili üst kontrol:** `KG03-06`

- **Denetim Amacı:** Host boot bütünlüğünün donanım kökenli olarak ölçülmesini ve vCenter tarafından doğrulanabilmesini sağlamak.
- **Olası Riskler:** TPM ve attestation olmadan host'un güvenilir bir durumda açıldığı doğrulanamaz; boot zincirine yapılan müdahale tespitsiz kalır.
- **Beklenen Kanıt:** Küme bazında attestation durum çıktısı; TPM mevcut olmayan host listesi ve gerekçesi; attestation "Failed" veren host'lar için olay/aksiyon kaydı.
- **Kanıta Ulaşım Yöntemi:** vSphere Client > Cluster > Monitor > Security > Attestation ekranından host bazında durum okunur. PowerCLI karşılığı kurumun PowerCLI sürümüne göre değişebileceğinden komut, çalıştırılmadan önce üretici dokümantasyonuyla teyit edilmelidir.
- **Kabul Ölçütleri:** TPM 2.0 bulunan host'larda attestation durumu "Passed" olmalıdır. "Failed" veya "N/A" olan host'lar için gerekçe ve aksiyon kaydı bulunmalıdır. TPM bulunmayan host'lar envanterde işaretli ve onaylı istisna kaydına bağlı olmalıdır.
- **İnceleme ve Test Adımları:** Küme bazında attestation tablosunu al; "Failed" durumundaki host'lar için ilgili olay kaydını ve kapatma aksiyonunu iste. Attestation durumunu Secure Boot çıktısıyla birlikte değerlendir; Secure Boot kapalı bir host'ta attestation anlamlı sonuç vermez.
- **İncelenecek Kayıtlar ve Örnekleme:** Tüm kümeler ve host'lar. Örnekleme yapılacaksa her donanım modeli temsil edilmelidir.
- **Kanıtın Sınırları:** Attestation durumu ölçüm anını gösterir; geçmiş dönemdeki başarısızlıklar yalnız olay kayıtlarından izlenebilir. TPM'in fiziksel varlığı, doğru yapılandırıldığını tek başına kanıtlamaz.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** v3 kapsam boşluğu analizi — ESXi fidye yazılımı sertleştirme kılavuzları
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 15 (güvenlik konfigürasyon yönetimi)
- **İyi Uygulama (Standart/Baseline):** NIST SP 800-53 Rev.5 SI-7 (bütünlük doğrulama), SC-51 sınıfı donanım kökenli güven (kurumun taban profiline göre değerlendirilir)
- **Teknik Referanslar:** CIS VMware ESXi 8.0 Benchmark — donanım bölümü TPM maddesi. NOT: kesin madde numarası bu turda doğrulanmamıştır; CIS Eşlemesi sayfası temin edildiğinde eşlenmelidir.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG03-32 — ESXi: Sanal makinelerde gereksiz aygıt ve host-guest iletişim kanalları (VMCI, USB/xHCI denetleyici, seri/paralel port, CD-ROM/floppy, paylaşılan klasör) kaldırılmış veya devre dışı bırakılmış mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** v3-GAP-04 · **İlişkili üst kontrol:** `KG03-01`

- **Denetim Amacı:** Hypervisor kaçış (sandbox escape) zincirlerinin giriş noktası olan VM aygıt yüzeyini daraltmak; çok kiracılı ortamda bir müşteriden diğerine geçiş yolunu kapatmak.
- **Olası Riskler:** Guest içinde yönetici yetkisi elde eden bir saldırganın VMX süreci üzerinden host'a çıkması (VMSA-2025-0004 kapsamındaki CVE-2025-22224 / 22225 / 22226 zinciri vahşi doğada istismar edilmiştir). Çok kiracılı MSP ortamında bu, bir müşterinin iş yükünden diğer müşterilerin verisine erişim anlamına gelir. Gereksiz aygıtlar bu zincirlerin saldırı yüzeyini oluşturur.
- **Beklenen Kanıt:** VM envanteri üzerinden aygıt listesi çıktısı; istisna gerektiren VM'ler için iş gerekçesi ve onay kaydı; şablon (template) üzerindeki varsayılan aygıt yapılandırması.
- **Kanıta Ulaşım Yöntemi:** vSphere Client > VM > Edit Settings > Virtual Hardware (aygıt listesi) ve VM Options > Advanced > Configuration Parameters (isolation.* parametreleri). PowerCLI ile toplu envanter alınabilir; komut sözdizimi kurumun sürümüne göre teyit edilmelidir.
- **Kabul Ölçütleri:** Üretim VM'lerinde iş gereği bulunmayan aygıtlar (USB/xHCI denetleyici, seri ve paralel port, floppy, bağlı CD-ROM/ISO, paylaşılan klasör) bulunmamalı; kaldırılamayanlar devre dışı olmalıdır. Şablonlarda bu aygıtlar varsayılan olarak yer almamalıdır. Çok kiracılı ortamda istisnalar müşteri ve VM bazında onaylı olmalıdır.
- **İnceleme ve Test Adımları:** Örneklem VM'ler için aygıt listesini ve ilgili isolation.* parametrelerini birlikte oku. Şablonları ayrıca kontrol et — şablon (template)daki gereksiz aygıt tüm yeni VM'lere yayılır. İstisnaların onay kaydını iste. Üretimde aygıt kaldırma denemesi yapma.
- **İncelenecek Kayıtlar ve Örnekleme:** Farklı müşteri (tenant), iş yükü sınıfı ve şablon (template)dan üretilmiş VM'leri kapsayan tabakalı örneklem; kullanılan tüm şablonlar tam olarak incelenir.
- **Kanıtın Sınırları:** Aygıt envanteri ölçüm anını gösterir; VM yaşam döngüsü boyunca aygıt eklenmediğini kanıtlamaz — değişiklik kaydı ayrıca aranır. Aygıt yüzeyinin daraltılması kaçış zafiyetlerini ortadan kaldırmaz, yalnız yüzeyi azaltır; yama yönetimi (KG11) tamamlayıcıdır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** v3 kapsam boşluğu analizi — VMSA-2025-0004 hypervisor kaçış zinciri
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 15 (güvenlik konfigürasyon yönetimi); CBDDO BİGR 3.1.9.11 (VM'ler arası trafik ve etkileşim kontrolü)
- **İyi Uygulama (Standart/Baseline):** NIST SP 800-53 Rev.5 CM-7 (en az işlevsellik), SC-39 (süreç yalıtımı)
- **Teknik Referanslar:** CIS VMware ESXi 8.0 Benchmark — sanal makine bölümü (7.x) aygıt ve isolation maddeleri; mevcut KG03-24 kontrolüyle birlikte değerlendirilir. NOT: bu satır için kesin madde numarası doğrulanmamıştır.
- **Erişim Referansları:** RO-VMW-ADV; CIS-ESX8
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

