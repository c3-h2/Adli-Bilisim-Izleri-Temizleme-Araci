# KG04 - vCenter ve Yönetim Düzeyi

**Çalışma:** VMware MSP Denetimi · **Sürüm:** v4 — 14 Eylül 2026  
**Doküman:** Kontrol grubu çalışma listesi — 13 kontrol  
**Hazırlayan:** KKB İç Denetim Başkanlığı — BT Denetimi (danışmanlık çıktısıdır, son karar denetçinindir)  
**Ana dizin:** `00 - Ana Dizin ve Dokuman Haritasi.xlsx`

---

> Uyumsuzluk hükmü yalnızca **Bağlayıcı Kriter (Mevzuat)** alanındaki maddeye atıfla verilebilir. **İyi Uygulama** alanı tek başına uyumsuzluk dayanağı değildir. Terim ve kısaltmalar için `03 - Terimler` ve `04 - Kisaltmalar` dokümanlarına, metodoloji için `01 - Kapsam ve Metodoloji` dokümanına bakınız.

| Kontrol ID | Denetim Sorusu | Öncelik | Test Yöntemi | Kaynak |
|---|---|---|---|---|
| `KG04-01` | vCenter SSO, kimlik doğrulama ve merkezi doğrulama (identity source) (ID source) ayarları en güvenli düzeyde mi? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG04-02` | API, CLI ve admin yetkileri için kısıtlı erişim modeli uygulanmış mı? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG04-03` | vCenter yedeklemesi düzenli mi, yedekler geri dönüş testi (restore test)nden geçmiş mi? | Yüksek | Güvenlik Denetimi + Doküman İncelemesi | 12 KG |
| `KG04-04` | Rol ve izinler düzenli access review ile doğrulanıyor mu? | Yüksek | Doküman İncelemesi + Güvenlik Denetimi | 12 KG |
| `KG04-05` | vCenter ve bileşenleri vendor destek döngüsünde kalacak şekilde güncel mi? | Yüksek | Güvenlik Denetimi + Doküman İncelemesi | 12 KG |
| `KG04-06` | Yönetim trafiği için ayrı bir yönetim ağı (management network) ve erişim sınırı tasarımı mevcut mu? | Orta | Güvenlik Denetimi + Doküman İncelemesi | 12 KG |
| `KG04-07` | vCenter: vSphere Client boşta kalan (idle) yönetici oturumunu belirlenen sürede sonlandırıyor mu? | Yüksek | Yapılandırma İncelemesi (Configuration Review) | EK G1-24 |
| `KG04-08` | vCenter: vSphere Client ve VCSA SSH giriş uyarıları (login banner) kurumsal olarak onaylı mı ve doğru yüzeyde gösteriliyor mu? | Orta | Yapılandırma İncelemesi (Configuration Review) | EK G1-26 |
| `KG04-09` | vCenter: vCenter kurumsal kimlik entegrasyonu ve yerel hesap (local account) istisnaları kontrol ediliyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G1-28 |
| `KG04-10` | vCenter: vCenter global permission ve propagate seçenekleri müşteri kapsamını aşıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-22 |
| `KG04-11` | vCenter: VCSA SSH erişimi rutin kullanım dışında kapalı mı? | Yüksek | Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı | EK G3-11 |
| `KG04-12` | vCenter, ESXi ve NSX yönetim arayüzlerinin internetten ve genel kurumsal ağdan fiilen erişilebilir olmadığı periyodik olarak taramayla doğrulanıyor mu? | Yüksek | Doküman İncelemesi + Güvenlik Denetimi | v3-GAP v3-GAP-05 |
| `KG04-13` | Yönetim düzlemine erişim jump host / bastion üzerinden zorunlu kılınmış mı ve doğrudan erişim istisnaları kayıt altına alınıyor mu? | Yüksek | Doküman İncelemesi + Güvenlik Denetimi | v3-GAP v3-GAP-06 |

## KG04-01 — vCenter SSO, kimlik doğrulama ve merkezi doğrulama (identity source) (ID source) ayarları en güvenli düzeyde mi?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Yönetim düzleminde kimlik doğrulamanın manipülasyona kapalı olmasını sağlamak.
- **Olası Riskler:** Kullanıcı kimliklendirmede sahtecilik ve yetki hilesi.
- **Beklenen Kanıt:** SSO yapılandırma ekran çıktıları, domain policy, kimlik doğrulama logları
- **Kanıta Ulaşım Yöntemi:** vCenter yönetim konsolundan authentication policy'ler çekilir, politika dışı kullanıcı grupları denetlenir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS VMware vCenter Benchmark, NIST SP 800-53 (IA-2, IA-4)
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 11/6 (yetkilendirme ve yıllık gözden geçirme), CBDDO 3.1.9.9 (sanallaştırma yönetim ortamına erişim kontrolü)
- **İyi Uygulama (Standart/Baseline):** ISO/IEC 27002:2022 5.18 (erişim haklarının merkezi kaydı, yetkilendirme prosedürleri)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG04-02 — API, CLI ve admin yetkileri için kısıtlı erişim modeli uygulanmış mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Yüksek etkili arayüzleri en az yetki (least privilege) ile sınırlamak.
- **Olası Riskler:** Token sızıntısı sonrası geniş kapsamlı manipülasyon.
- **Beklenen Kanıt:** API izin listeleri, endpoint policy, yetki kısıtlama ayarları
- **Kanıta Ulaşım Yöntemi:** Kimlik ve erişim loglarıyla yüksek riskli API çağrılarının kimliklerine göre filtrelenmesi yapılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (AC-6), CIS vCenter API hardening
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 11/6 (en az yetki, sadece bilmesi gereken veri), CBDDO 3.1.9.9 (yönetim ortamına erişim kontrolü)
- **İyi Uygulama (Standart/Baseline):** NIST SP 800-53 Rev.5 AC-2(11) (kullanım koşullarının uygulanması)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG04-03 — vCenter yedeklemesi düzenli mi, yedekler geri dönüş testi (restore test)nden geçmiş mi?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi + Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Yönetim katmanı bozulduğunda hızlı servis kazandırmak.
- **Olası Riskler:** Yedekleme yapılsa da geri dönüşte çalışmayan ya da bozuk kopyalar.
- **Beklenen Kanıt:** Backup job kayıtları, restore test sonuçları
- **Kanıta Ulaşım Yöntemi:** Son üç yedekleme dönemi alınır, en az bir restore test kaydıyla eşleştirilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (CP-9), CIS vCenter backup guidance
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 27/4 (yedeklerin sıklığı, yöntemi, ortam ve konumlarının güncel olarak kayıt altına alınması), CBDDO 3.1.9.13 (sanallaştırma ortamının yedeklenmesi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG04-04 — Rol ve izinler düzenli access review ile doğrulanıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Zamana bağlı yetki birikimini kontrol altına almak.
- **Olası Riskler:** İşten ayrılan hesaplar ve eski görev yetkilerinin kalması.
- **Beklenen Kanıt:** Access review listeleri, recertification tutanakları
- **Kanıta Ulaşım Yöntemi:** Son review dönemi belgelenir, yetki mapleriyle çalışan görev dağılımı kıyaslanır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (AC-2), CIS vCenter RBAC
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 11/6 (erişim yetkisi olan kullanıcılar yılda en az bir defa bilgi varlığı sahibi tarafından gözden geçirilir)
- **İyi Uygulama (Standart/Baseline):** ISO/IEC 27002:2022 5.18 (erişim haklarının düzenli gözden geçirilmesi, ayrıcalıklı erişim yetkilendirmeleri)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG04-05 — vCenter ve bileşenleri vendor destek döngüsünde kalacak şekilde güncel mi?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi + Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Destek dışı sürümden gelen yüksek riskleri minimize etmek.
- **Olası Riskler:** Bilinen CVE'ye karşı savunmasız kalma.
- **Beklenen Kanıt:** Sürüm listesi, vendor lifecycle/patch advisories, uyumluluk listeleri
- **Kanıta Ulaşım Yöntemi:** Envanterden alınan sürüm bilgisi üretici yaşam döngüsü ile karşılaştırılır, destek dışı kalmış bileşen işaretlenir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS ve VMware ürün yaşam döngüsü belgeleri, NIST SP 800-53 (SI-2)
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.1 (üretici desteği devam eden ve kararlı sürümler kullanılmalı, güvenlik duyuruları takip edilmeli), BDDK-BSY Md. 16/1 (yama yönetimi prosedürü)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG04-06 — Yönetim trafiği için ayrı bir yönetim ağı (management network) ve erişim sınırı tasarımı mevcut mu?

**Öncelik:** Orta · **Test Yöntemi:** Güvenlik Denetimi + Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Yönetim oturumlarının iş yükü/sunucu trafiğinden ayrı tutulması.
- **Olası Riskler:** Yönetim trafik saldırılarının diğer VLAN'lara sıçraması.
- **Beklenen Kanıt:** Ağ diyagramı, mgmt port/ACL kayıtları, güvenlik duvarı kuralı
- **Kanıta Ulaşım Yöntemi:** vCenter network haritası ve firewall konfigürasyonları ile yönetim segmenti kontrol edilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (SC-7), CIS network segmentation, VMware altyapı önerileri
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.6.6 (yönetimsel işlemler için ayrı yönetim ağları kullanılmalı, ağlar katmanlara ayrılmalı, VLAN'lar arasında erişim denetimi yapılmalı), BDDK-BSY Md. 14/2 (güvenlik duvarı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG04-07 — vCenter: vSphere Client boşta kalan (idle) yönetici oturumunu belirlenen sürede sonlandırıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) · **Kaynak:** G1-24 · **İlişkili üst kontrol:** `KG04-02`

- **Denetim Amacı:** Yönetim oturumunun boşta süresiyle kapanmasını doğrulamak.
- **Olası Riskler:** Gözetimsiz tarayıcı oturumu tüm müşteri VM envanterinde ayrıcalıklı işlem yapılmasına yol açabilir.
- **Beklenen Kanıt:** Hedef nesne/sürüm bilgisi ve vSphere Client Configuration etkin ayar çıktısı; onaylı baseline ve istisnalar.
- **Kanıta Ulaşım Yöntemi:** SCG-RO(vSphere Client Configuration)
- **Kabul Ölçütleri:** SCG vSphere 8 U3 profili seçilmişse: "Session Timeout" = 15 minutes. Başka sürüm veya kaynak profiline otomatik uygulanmaz.
- **İnceleme ve Test Adımları:** TEST-1
- **İncelenecek Kayıtlar ve Örnekleme:** Hedef nesne/sürüm bilgisi ve vSphere Client Configuration etkin ayar çıktısı; onaylı baseline ve istisnalar. + KAYIT-B2
- **Kanıtın Sınırları:** SINIR-2

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VMW-SCG: vcenter-8.administration-client-session-timeout
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 14/7 (bağlantının süresi kısıtlanır)
- **Teknik Referanslar:** VMW-SCG: vcenter-8.administration-client-session-timeout; VMW-SCG kaynak varyantları: vcenter-8.administration-client-session-timeout. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** VMW-SCG: vcenter-8.administration-client-session-timeout
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG04-08 — vCenter: vSphere Client ve VCSA SSH giriş uyarıları (login banner) kurumsal olarak onaylı mı ve doğru yüzeyde gösteriliyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) · **Kaynak:** G1-26 · **İlişkili üst kontrol:** `KG04-02`

- **Denetim Amacı:** Giriş uyarı metinlerinin tüm yüzeylerde tutarlı olmasını doğrulamak.
- **Olası Riskler:** Bir yönetim yüzeyinin uyarı kapsamı dışında kalması kullanım koşullarının tutarsız uygulanmasına neden olabilir; banner erişim engeli olarak yorumlanamaz.
- **Beklenen Kanıt:** Hedef nesne/sürüm bilgisi ve vCenter Server SSO Configuration, vCenter Server Advanced Settings etkin ayar çıktısı; onaylı baseline ve istisnalar.
- **Kanıta Ulaşım Yöntemi:** SCG-RO(vCenter Server SSO Configuration, vCenter Server Advanced Settings)
- **Kabul Ölçütleri:** Client login message etkin olmalı, mesaj, ayrıntı ve SSH /etc/issue içeriği kurumun onaylı metniyle tutarlı olmalı. Kaynaktaki örnek hukuk metni aynen zorunlu tutulmaz.
- **İnceleme ve Test Adımları:** TEST-1
- **İncelenecek Kayıtlar ve Örnekleme:** Hedef nesne/sürüm bilgisi ve vCenter Server SSO Configuration, vCenter Server Advanced Settings etkin ayar çıktısı; onaylı baseline ve istisnalar. + KAYIT-B2
- **Kanıtın Sınırları:** SINIR-2

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VMW-SCG: vcenter-8.administration-login-message-details, vcenter-8.administration-login-message-enable, vcenter-8.administration-login-message-text, vcenter-8.etc-issue
- **Teknik Referanslar:** VMW-SCG: vcenter-8.administration-login-message-details, vcenter-8.administration-login-message-enable, vcenter-8.administration-login-message-text, vcenter-8.etc-issue; VMW-SCG kaynak varyantları: aynı. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** VMW-SCG: vcenter-8.administration-login-message-details, vcenter-8.administration-login-message-enable, vcenter-8.administration-login-message-text, vcenter-8.etc-issue
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG04-09 — vCenter: vCenter kurumsal kimlik entegrasyonu ve yerel hesap (local account) istisnaları kontrol ediliyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G1-28 · **İlişkili üst kontrol:** `KG04-01`

- **Denetim Amacı:** Merkezi kimlik entegrasyonunun ve yerel istisnaların gözetimini doğrulamak.
- **Olası Riskler:** vCenter kimlik ve ayrıcalıklı erişim yönetimi yeterli değilse, gereğinden geniş, sahipsiz veya zamanında kapatılmamış hesaplar yetkisiz erişim ve işlem riskini artırır. + RISK-B
- **Beklenen Kanıt:** SSO yapılandırması, kullanıcı/rol exportu, login logları
- **Kanıta Ulaşım Yöntemi:** VIPERM
- **Kabul Ölçütleri:** SSO/identity federation kullanımı kurulu sürümün desteğiyle doğrulanmalı, kimlik kaynağı kesintisindeki yerel erişim sahipli, korumalı ve izlenebilir olmalı.
- **İnceleme ve Test Adımları:** TEST-2 + TAIL-1
- **İncelenecek Kayıtlar ve Örnekleme:** SSO yapılandırması, kullanıcı/rol exportu, login logları. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-1

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST-53: IA-2; AC-2
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 11/6 (yetkilendirme; yıllık gözden geçirme)
- **Teknik Referanslar:** NIST-53: IA-2; AC-2; VMW-SCG kaynak varyantları: vcenter-8.administration-sso-groups. Üretici Eşlemesi sayfasındaki sürüm/parametre ve kullanım sınırı birlikte okunur.
- **Erişim Referansları:** VMW-SCG; RO-VMW-PERM
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG04-10 — vCenter: vCenter global permission ve propagate seçenekleri müşteri kapsamını aşıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-22 · **İlişkili üst kontrol:** `KG04-04`

- **Denetim Amacı:** Global yetki kalıtımının tenant sınırını aşmamasını doğrulamak.
- **Olası Riskler:** Üst klasördeki kalıtım tenant sınırını görünmeden genişletir. + RISK-C + RISK-B
- **Beklenen Kanıt:** Global permissions, roller, klasör/resource pool izinleri.
- **Kanıta Ulaşım Yöntemi:** VIPERM
- **Kabul Ölçütleri:** Global/kalıtılan yetkiler yalnız gerekli nesneleri kapsamalı.
- **İnceleme ve Test Adımları:** İki müşteri hesabıyla karşılıklı VM/console/snapshot erişimini salt okunur (read-only) test et. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** Global permissions, roller, klasör/resource pool izinleri. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-4

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST-53: AC-3; BIGR: 4.3.1.4; NIST-53: AC-3; AC-6; BIGR: 3.1.9.9 | 3.1.9.9 — basılı s.61 / PDF 65
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 11/6 (en az yetki; sadece bilmesi gereken veri)
- **Teknik Referanslar:** NIST-53: AC-3; BIGR: 4.3.1.4; NIST-53: AC-3; AC-6; BIGR: 3.1.9.9 | 3.1.9.9 — basılı s.61 / PDF 65
- **Erişim Referansları:** VMW-SCG; RO-VMW-PERM
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG04-11 — vCenter: VCSA SSH erişimi rutin kullanım dışında kapalı mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi (Configuration Review) - kaynak metin kırpıldı · **Kaynak:** G3-11 · **İlişkili üst kontrol:** `KG04-02`

- **Denetim Amacı:** VCSA SSH erişiminin rutin kullanımda kapalı olmasını doğrulamak.
- **Olası Riskler:** — (kaynak metin kırpıldı)
- **Beklenen Kanıt:** — (kaynak metin kırpıldı)
- **Kanıta Ulaşım Yöntemi:** — (kaynak metin kırpıldı)
- **Kabul Ölçütleri:** — (kaynak metin kırpıldı)
- **İnceleme ve Test Adımları:** — (kaynak metin kırpıldı)
- **İncelenecek Kayıtlar ve Örnekleme:** — (kaynak metin kırpıldı)
- **Kanıtın Sınırları:** — (kaynak metin kırpıldı)

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** — (kaynak metin kırpıldı)
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 5.1.1.4 (gerekli olmayan servisler kapatılmalı)
- **Teknik Referanslar:** — (kaynak metin kırpıldı)
- **Erişim Referansları:** — (kaynak metin kırpıldı)
- **Denetim Yöntemi Referansları:** — (kaynak metin kırpıldı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG04-12 — vCenter, ESXi ve NSX yönetim arayüzlerinin internetten ve genel kurumsal ağdan fiilen erişilebilir olmadığı periyodik olarak taramayla doğrulanıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** v3-GAP-05 · **İlişkili üst kontrol:** `KG04-06`

- **Denetim Amacı:** Yönetim düzlemi maruziyetini tasarım dokümanına değil, fiilî ölçüme dayanarak doğrulamak.
- **Olası Riskler:** Kitlesel istismar kampanyalarının ortak ilk erişim yolu, yönetim arayüzünün internete açık olmasıdır: CVE-2021-21974 (OpenSLP) üzerinden ESXiArgs fidye yazılımı ve CVE-2026-59310 (vCenter syslog path traversal → kimlik doğrulamasız root RCE) bu yolla kitlesel olarak sömürülmüştür. Tasarımda izole görünen yönetim ağı (management network), hatalı güvenlik duvarı kuralı, NAT veya geçici erişim nedeniyle fiilen açık olabilir.
- **Beklenen Kanıt:** Son iki döneme ait dış tarama raporu (yönetim IP blokları dahil); kurumsal ağdan alınmış iç tarama çıktısı; yönetim VLAN'ına gelen güvenlik duvarı kural export'u; varsa dış saldırı yüzeyi (EASM) envanter çıktısı; tespit edilen açıklıklar için kapatma kayıtları.
- **Kanıta Ulaşım Yöntemi:** Kurumun zafiyet/port tarama platformundan yönetim IP blokları için son raporlar; güvenlik duvarı yönetim arayüzünden yönetim VLAN'ına gelen kural listesinin salt okunur (read-only) export'u. Denetçi kendi tarama işlemini yürütmez; kurumun mevcut raporlarını ve kural kayıtlarını inceler.
- **Kabul Ölçütleri:** vCenter (443), ESXi (443, 902) ve NSX Manager (443) yönetim arayüzleri internetten erişilebilir olmamalıdır. Kurumsal ağdan erişim yalnız yönetim VLAN'ı ve/veya jump host kaynak adresleriyle sınırlı olmalıdır. Doğrulama kurumun tanımladığı periyotta tekrarlanmalı ve sonucu kayıt altına alınmalıdır.
- **İnceleme ve Test Adımları:** Dış tarama raporunda yönetim IP bloklarının kapsandığını önce doğrula — kapsam dışı bırakılmış blok varsa bu başlı başına bulgudur. Güvenlik duvarı kurallarındaki kaynak nesnelerini gerçek adres gruplarına kadar aç; "any" veya geniş grup kullanımını işaretle. Geçici olarak açılmış kuralların kapanış kaydını iste.
- **İncelenecek Kayıtlar ve Örnekleme:** Son iki dönem tarama raporunun tamamı; yönetim VLAN'ına gelen kuralların tam listesi (örnekleme (sampling) yapılmaz). Geçici erişim talepleri ayrıca incelenir.
- **Kanıtın Sınırları:** Tarama sonucu tarama anını ve tarama kaynağının görebildiği yolu gösterir; farklı bir ağ segmentinden veya VPN üzerinden erişim yolu açık kalmış olabilir. Güvenlik duvarı kural kaydı, kuralın fiilen uygulandığını tek başına kanıtlamaz.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** v3 kapsam boşluğu analizi — ESXiArgs ve CVE-2026-59310 ilk erişim yolu
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 14/2 (güvenlik duvarı); CBDDO BİGR 3.1.6.5 (izin verilmeyen trafiğin engellenmesi), 3.1.6.6 (ağların izole edilmesi, yönetim ağı), 3.1.9.9 (sanallaştırma yönetim ortamına erişim kontrolü)
- **İyi Uygulama (Standart/Baseline):** NIST SP 800-53 Rev.5 SC-7 (sınır koruması), RA-5 (zafiyet izleme ve tarama)
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 13.6, 14.1–14.3

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG04-13 — Yönetim düzlemine erişim jump host / bastion üzerinden zorunlu kılınmış mı ve doğrudan erişim istisnaları kayıt altına alınıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** v3-GAP-06 · **İlişkili üst kontrol:** `KG04-02`

- **Denetim Amacı:** Yönetim erişimini tek bir denetlenebilir noktadan geçirerek oturum kaydı, çok bileşenli kimlik doğrulama ve kaynak adres kısıtını tek yerde uygulanabilir kılmak.
- **Olası Riskler:** Yönetici iş istasyonundan doğrudan erişim, ele geçirilmiş bir uç noktanın kimlik bilgileriyle hypervisor yönetimine doğrudan ulaşmasına imkân verir; oturum kaydı ve ayrıcalıklı erişim izlemesi devre dışı kalır.
- **Beklenen Kanıt:** Jump host / bastion mimari dokümanı; yönetim arayüzlerine erişimi kaynak adresle sınırlayan kural ve politika çıktısı; jump host oturum kayıtları örneği; doğrudan erişim istisnalarının onay ve süre kaydı.
- **Kanıta Ulaşım Yöntemi:** Ayrıcalıklı erişim yönetimi (PAM) platformundan yönetim hedeflerine ait oturum kayıtlarının salt okunur (read-only) listesi; güvenlik duvarı ve vCenter/ESXi kaynak adres kısıtı yapılandırması; istisna talep kayıtları ITSM sisteminden alınır.
- **Kabul Ölçütleri:** vCenter, ESXi ve NSX yönetim arayüzlerine erişim yalnız tanımlı jump host / bastion kaynak adreslerinden mümkün olmalıdır. Doğrudan erişim istisnaları süreli, gerekçeli ve onaylı olmalı; süre sonunda kapatıldığı kayıtla gösterilebilmelidir.
- **İnceleme ve Test Adımları:** Kaynak adres kısıtını hem güvenlik duvarında hem platform tarafında ayrı doğrula — yalnız birinde uygulanmışsa tek nokta arızası vardır. Son dönem oturum kayıtlarından jump host dışı kaynak adres bulunup bulunmadığını kontrol et; bulunanları istisna kayıtlarıyla eşle.
- **İncelenecek Kayıtlar ve Örnekleme:** Son dönem yönetim oturumlarının tamamı üzerinden kaynak adres analizi; istisna kayıtlarının tam listesi. Örnekleme yapılacaksa farklı yönetici rolü ve müşteri kapsamı temsil edilmelidir.
- **Kanıtın Sınırları:** Yapılandırma kanıtı ilgili anı gösterir. Oturum kayıtları yalnız kaydedilen erişim yollarını kapsar; kayıt dışı bir yol (ör. konsol, BMC) varsa bu kontrolle görünmez — KG03-06 ve KG03-02 ile birlikte değerlendirilmelidir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** v3 kapsam boşluğu analizi — ESXi fidye yazılımı sertleştirme kılavuzları
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 14/7 (uzaktan erişim: onay, çok bileşenli kimlik doğrulama, iz kaydı, süre/cihaz kısıtı); CBDDO BİGR 3.1.9.9 (sanallaştırma yönetim ortamına erişim kontrolü)
- **İyi Uygulama (Standart/Baseline):** ISO/IEC 27002:2022 5.18 (ayrıcalıklı erişim yetkilendirmeleri); NIST SP 800-53 Rev.5 AC-17 (uzaktan erişim), AC-3 (erişim zorlaması)
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 13.6, 14.1–14.3

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

