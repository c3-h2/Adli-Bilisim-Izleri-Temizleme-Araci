# KG01 - Yönetimsel Çerçeve, Sözleşme ve Sorumluluklar

**Çalışma:** VMware MSP Denetimi · **Sürüm:** v4 — 14 Eylül 2026  
**Doküman:** Kontrol grubu çalışma listesi — 6 kontrol  
**Hazırlayan:** KKB İç Denetim Başkanlığı — BT Denetimi (danışmanlık çıktısıdır, son karar denetçinindir)  
**Ana dizin:** `00 - Ana Dizin ve Dokuman Haritasi.xlsx`

---

> Uyumsuzluk hükmü yalnızca **Bağlayıcı Kriter (Mevzuat)** alanındaki maddeye atıfla verilebilir. **İyi Uygulama** alanı tek başına uyumsuzluk dayanağı değildir. Terim ve kısaltmalar için `03 - Terimler` ve `04 - Kisaltmalar` dokümanlarına, metodoloji için `01 - Kapsam ve Metodoloji` dokümanına bakınız.

| Kontrol ID | Denetim Sorusu | Öncelik | Test Yöntemi | Kaynak |
|---|---|---|---|---|
| `KG01-01` | MSP ile müşteri arasında rol ve sorumluluklar (RACI), güvenlik, yedekleme, izleme, kriz yönetimi ve değişiklik süreçleri için yazılı ve imzalı olarak tanımlanmış mı? | Yüksek | Doküman İncelemesi + Mülakat | 12 KG |
| `KG01-02` | Her müşterinin onboarding aşaması için teknik ve güvenlik kapsam dokümanı hazırlanıp onay alınıyor mu? | Yüksek | Doküman İncelemesi | 12 KG |
| `KG01-03` | Değişiklik yönetim süreçlerinde acil ve normal değişiklik akışları ayrık mı ve her ikisi için ayrı onay kontrolü bulunuyor mu? | Yüksek | Doküman İncelemesi + Güvenlik Denetimi | 12 KG |
| `KG01-04` | RPO/RTO/MTTR hedefleri yazılı ve teknik hedeflerle ilişkilendirilmiş mi, periyodik ölçüm planı var mı? | Yüksek | Doküman İncelemesi | 12 KG |
| `KG01-05` | DR/olasılık senaryoları için runbook onaylı ve düzenli test edilmiş mi? | Orta | Doküman İncelemesi | 12 KG |
| `KG01-06` | Üçüncü taraf erişimleri için due diligence ve periyodik erişim yeniden değerlendirmesi (access recertification) uygulanıyor mu? | Yüksek | Güvenlik Denetimi + Doküman İncelemesi | 12 KG |

## KG01-01 — MSP ile müşteri arasında rol ve sorumluluklar (RACI), güvenlik, yedekleme, izleme, kriz yönetimi ve değişiklik süreçleri için yazılı ve imzalı olarak tanımlanmış mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi + Mülakat · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Görev karmaşasının önüne geçmek, 'kim hangi olayda ne yapar' belirsizliğini kaldırmak ve hesap verebilirlik zincirini kurmak.
- **Olası Riskler:** Olay anında gecikme, yetkisiz işlem, denetim bulgularında sorumluluk yüklenebilirliğinde boşluk.
- **Beklenen Kanıt:** MSA/SLA ve ekleri, RACI matrisi, sorumluluk dağılımı ve onay listeleri, değişiklik yönetimi planları
- **Kanıta Ulaşım Yöntemi:** İlgili sözleşme depo alanından son imzalı revizyonlar alınır, en az son 3 ay içinde değişen görev dağılımı kayıtlarıyla karşılaştırılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** BDDK Siber Güvenlik Rehberi, CIS VMware Benchmark serisi, NIST SP 800-53 (PM-9, PM-5), NIST SP 800-100 (dokümandan korunmuş, bu turda doğrulanmadı)
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 29/1 (dış hizmet gözetim mekanizması: risklerin tüm yönleriyle değerlendirilmesi, sağlayıcı seçiminde özen, hizmetlerin yazılı hale getirilmesi, düzenli takip), BDDK-DHY Md. 5/1 (sözleşmede asgari unsurlar: kapsam, performans, gizlilik, denetim hakkı, veri güvenliği, süreklilik/çıkış planı), BDDK-DHY Md. 4/8 (karar alma gücü ve sorumluluğun bankada olması)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG01-02 — Her müşterinin onboarding aşaması için teknik ve güvenlik kapsam dokümanı hazırlanıp onay alınıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Kapsam dışı gereksinimlerin (örn. log koruma süresi, tenant izolasyon kuralı, kısıtlı yönetim hesabı) sonradan ortaya çıkmasını engellemek.
- **Olası Riskler:** Proje sonunda fonksiyon eksik kalır, denetim boşluğu doğar, uyum ve güvenlik kontrolü atlanır.
- **Beklenen Kanıt:** Müşteri talep formu, teknik tasarım dokümanı, risk kabul/izin formları, kapsam değişiklik kayıtları
- **Kanıta Ulaşım Yöntemi:** Onboarding ticket dosyası ve proje klasöründen dokümanlar alınır, başlangıçta imzalanan kapsam ile geçerlilik tarihli onayların uyumu kontrol edilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS VMware ESXi 7 Benchmark, BDDK risk yönetimi dokümanları, NIST SP 800-37/800-53 (dokümandan korunmuş, bu turda doğrulanmadı)
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 29/1-b,d,e (sağlayıcı seçiminde özen, dış hizmet sistemlerinin bankanın risk yönetimi ve güvenlik politikalarına uygunluğu, veri aktarımında güvenlik tedbirleri), BDDK-DHY Md. 5/1-a (hizmet kapsamının sözleşmede tanımlanması)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG01-03 — Değişiklik yönetim süreçlerinde acil ve normal değişiklik akışları ayrık mı ve her ikisi için ayrı onay kontrolü bulunuyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Acil değişiklik adı altında kontrolsüz işlemlerin önlenmesi.
- **Olası Riskler:** Gece yarısı yapılan denetimsiz değişiklikler, geri dönülemez yapılandırma hatası, yüksek etkili yanlış ayarlar.
- **Beklenen Kanıt:** ITSM ticket geçmişi, acil değişiklik (emergency change) onay formu, uygulama sonrası geri alma planı (rollback plan)
- **Kanıta Ulaşım Yöntemi:** Son 6 aylık değişiklik kayıtları filtrelenerek 'urgent' işaretli olaylar ile normal süreçlerin karşılaştırılması yapılır, her birinde onay zinciri doğrulanır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (CM-3), CIS Change/Configuration Management, ITIL v4
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 24/1 (değişiklik yönetimi prosedürü, test, geri alma planı, yetkili onayı), BDDK-BSY Md. 24/3 (acil değişikliklerin sonradan onayı ve iz kaydı)
- **İyi Uygulama (Standart/Baseline):** ISO/IEC 27001:2022 Ek A A.8.32 (değişiklik yönetimi), NIST SP 800-53B Tablo 3-5 (CM-3 - MOD/HIGH taban)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG01-04 — RPO/RTO/MTTR hedefleri yazılı ve teknik hedeflerle ilişkilendirilmiş mi, periyodik ölçüm planı var mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** İş sürekliliği beklentileri ile teknik kapasite ve mimari planlar arasındaki uyumu sağlamak.
- **Olası Riskler:** Sözleşmede taahhüt edilen sürelerin aşılması, müşteri memnuniyeti/ihlal riski artar.
- **Beklenen Kanıt:** SLA ve BCP dokümanları, test raporları, KPI/Metrik çıktıları
- **Kanıta Ulaşım Yöntemi:** Son 4 çeyrek için raporlar ile hedefler karşılaştırılır, sapma varsa açık sebep analizi istenir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-34, NIST SP 800-53 (CP-2, CP-4), BDDK süreklilik planlama prensipleri
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 28/3 (süreklilik planının yılda en az bir kez test edilmesi). Not: RPO/RTO hedeflerinin yazılı olması için doğrudan hüküm bu turda getirilemedi, ilişkili hüküm Md. 28/3

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG01-05 — DR/olasılık senaryoları için runbook onaylı ve düzenli test edilmiş mi?

**Öncelik:** Orta · **Test Yöntemi:** Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Acil durumda operasyonel disiplini koruyup beklenmedik davranışı minimize etmek.
- **Olası Riskler:** Senaryo kâğıt üzerinde kalır, gerçek zamanda yanlış sıralama ve düzensiz rollback.
- **Beklenen Kanıt:** Runbook dokümanı, senaryo bazlı test tutanakları, iyileştirme aksiyon kayıtları
- **Kanıta Ulaşım Yöntemi:** Test tarihleri alınır, kritik senaryoların en az son 2 uygulama bulgusuyla bağlantısı istenir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (CP-4), CIS incident ve recovery önerileri
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 28/3 (süreklilik planının yılda en az bir kez test edilmesi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG01-06 — Üçüncü taraf erişimleri için due diligence ve periyodik erişim yeniden değerlendirmesi (access recertification) uygulanıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi + Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Tedarikçi hesaplarının açık kalmasının ve yetki aşımının önüne geçmek.
- **Olası Riskler:** Sözleşmede olmayan erişim, geçici hesapların kalması, tedarikçi hesabının suistimali.
- **Beklenen Kanıt:** Üçüncü taraf hesap listeleri, erişim ve onay kayıtları, periyodik recertification tutanakları
- **Kanıta Ulaşım Yöntemi:** IAM envanterinde 'third-party' etiketli hesaplar filtrelenir, her hesap için onay tarihleri ve son kullanım bakılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (SA-9), NIST SP 800-171, BDDK tedarikçi yönetimi
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 14/7 (uzaktan erişim: bilgi güvenliği sorumlusu onayı, çok bileşenli kimlik doğrulama, iz kaydı, süre/cihaz kısıtı, periyodik yeniden doğrulama), BDDK-BSY Md. 29/1-ç (dış hizmetin düzenli takibi)
- **İyi Uygulama (Standart/Baseline):** ISO/IEC 27002:2022 5.18 (erişim haklarının düzenli gözden geçirilmesi, ayrıcalıklı erişim yetkilendirmeleri)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

