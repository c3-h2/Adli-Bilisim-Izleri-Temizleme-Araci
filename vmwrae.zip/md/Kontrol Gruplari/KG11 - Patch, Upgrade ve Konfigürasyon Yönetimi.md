# KG11 - Patch, Upgrade ve Konfigürasyon Yönetimi

**Çalışma:** VMware MSP Denetimi · **Sürüm:** v4 — 14 Eylül 2026  
**Doküman:** Kontrol grubu çalışma listesi — 8 kontrol  
**Hazırlayan:** KKB İç Denetim Başkanlığı — BT Denetimi (danışmanlık çıktısıdır, son karar denetçinindir)  
**Ana dizin:** `00 - Ana Dizin ve Dokuman Haritasi.xlsx`

---

> Uyumsuzluk hükmü yalnızca **Bağlayıcı Kriter (Mevzuat)** alanındaki maddeye atıfla verilebilir. **İyi Uygulama** alanı tek başına uyumsuzluk dayanağı değildir. Terim ve kısaltmalar için `03 - Terimler` ve `04 - Kisaltmalar` dokümanlarına, metodoloji için `01 - Kapsam ve Metodoloji` dokümanına bakınız.

| Kontrol ID | Denetim Sorusu | Öncelik | Test Yöntemi | Kaynak |
|---|---|---|---|---|
| `KG11-01` | Tüm temel katmanlar (ESXi, vCenter, NSX, vCloud) için risk tabanlı yama planı ve önceliklendirme var mı? | Yüksek | Doküman İncelemesi + Güvenlik Denetimi | 12 KG |
| `KG11-02` | Upgrade öncesi staging test ve geri dönüş planı bulunuyor mu? | Yüksek | Doküman İncelemesi | 12 KG |
| `KG11-03` | Upgrade sonrasında config drift kontrolü otomatik mi yapılmış? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG11-04` | Uyum ve destek belgelerine göre sürüm uyumluluk (interoperability) kontrolü yapılıyor mu? | Yüksek | Doküman İncelemesi | 12 KG |
| `KG11-05` | Yama ve upgrade faaliyetlerinde güvenli otomasyon araçları kullanılmakta mı? | Orta | Doküman İncelemesi + Güvenlik Denetimi | 12 KG |
| `KG11-06` | Acil yama taleplerinde hız-ağırlaştırılmış kontrol yerine acil prosedür uygulanıyor mu? | Orta | Doküman İncelemesi + Güvenlik Denetimi | 12 KG |
| `KG11-07` | Sanallaştırma katmanı (ESXi, vCenter, NSX, Cloud Director) kimliği doğrulanmış (authenticated) zafiyet taramasına dahil mi ve bulgu kapatma SLA'i tanımlı mı? | Yüksek | Doküman İncelemesi + Güvenlik Denetimi | v3-GAP v3-GAP-12 |
| `KG11-08` | Broadcom/VMware VMSA güvenlik duyuruları izleniyor, ortama etkisi değerlendiriliyor ve gerektiğinde acil yama süreci tetikleniyor mu? | Yüksek | Doküman İncelemesi + Mülakat | v3-GAP v3-GAP-13 |

## KG11-01 — Tüm temel katmanlar (ESXi, vCenter, NSX, vCloud) için risk tabanlı yama planı ve önceliklendirme var mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Kritik açığı hızlı kapatırken değişim istikrarını korumak.
- **Olası Riskler:** Yüksek riskli CVE'lerin açık kalması.
- **Beklenen Kanıt:** Patch takvimi, risk sınıflaması, sürüm durumu raporları
- **Kanıta Ulaşım Yöntemi:** Son 6 ay patch geçmişi ile vulnerability listesi karşılaştırılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-40r3, NIST SP 800-53 (SI-2), CIS patching
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 16/1 (yama yönetimi prosedürü, kritik yamaların önceliklendirilmesi), BDDK-BSY Md. 16/3 (otomatik güvenlik açığı tarama araçları, kritik açıkların öncelikli raporlanması)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG11-02 — Upgrade öncesi staging test ve geri dönüş planı bulunuyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Üretim riski almadan güncellemeleri güvenli geçirmeyi sağlamak.
- **Olası Riskler:** Test edilmeden yapılan upgrade sonrası kesinti.
- **Beklenen Kanıt:** Pilot test sonuçları, canary sonuçları, rollback dokümanı
- **Kanıta Ulaşım Yöntemi:** Plan dokümanı ile gerçek geçiş kayıtları karşılaştırılır, başarısız canary testleri sorgulanır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (CP-10), CIS change governance
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 24/1 (değişiklik yönetimi prosedürü, test, geri alma planı, yetkili onayı)
- **İyi Uygulama (Standart/Baseline):** ISO/IEC 27001:2022 Ek A A.8.32 (değişiklik yönetimi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG11-03 — Upgrade sonrasında config drift kontrolü otomatik mi yapılmış?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Güncelleme sonrası beklenmedik ayar değişikliklerinin tespitini sağlamak.
- **Olası Riskler:** Güvenlik policy'lerinin geçersizleşmesi.
- **Beklenen Kanıt:** Post-change audit sonucu, host profile diff raporları
- **Kanıta Ulaşım Yöntemi:** Önceki/duruma göre host profile karşılaştırması yapılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS configuration drift, NIST SP 800-53 (CM-6)
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 24/1 (değişiklik yönetimi prosedürü)
- **İyi Uygulama (Standart/Baseline):** NIST SP 800-53B Tablo 3-5 (CM-2 Baseline Configuration - MOD/HIGH taban, CM-6 Configuration Settings - LOW/MOD/HIGH taban)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG11-04 — Uyum ve destek belgelerine göre sürüm uyumluluk (interoperability) kontrolü yapılıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Uyumsuz upgrade kombinasyonlarının önlenmesi.
- **Olası Riskler:** Destek dışı sürüm karışımı ile stabilite kaybı.
- **Beklenen Kanıt:** Uyumluluk matrisi, release note karşılaştırması, upgrade karar notu
- **Kanıta Ulaşım Yöntemi:** Upgrade planları üretici release/compatibility matrix ile eşleştirilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VMware vCenter/vSphere Support Matrix, NIST CM-3
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.1 (üretici desteği devam eden kararlı sürümler, sürüm değişikliklerinin takibi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG11-05 — Yama ve upgrade faaliyetlerinde güvenli otomasyon araçları kullanılmakta mı?

**Öncelik:** Orta · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** İnsan hatasını azaltmak, auditable değişiklik izi sağlamak.
- **Olası Riskler:** Manuel müdahalelerde unutulan adımlar.
- **Beklenen Kanıt:** Patch pipeline scripti, log çıktıları, onaylı pipeline workflow
- **Kanıta Ulaşım Yöntemi:** Kullanılan araç zinciri ve her adımın log imzası kontrol edilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (CM-3), CIS automation controls
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 24/1 (değişiklik yönetimi prosedürü, iz kaydı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG11-06 — Acil yama taleplerinde hız-ağırlaştırılmış kontrol yerine acil prosedür uygulanıyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** 'Acil' etiketin de denetim altına alınmasını sağlamak.
- **Olası Riskler:** Acil işlemde izlenebilirlik kaybı ve risk kabul hatası.
- **Beklenen Kanıt:** Emergency change formu, onay notları, sonradan kapatma raporu
- **Kanıta Ulaşım Yöntemi:** Son dönemde emergency kategorisindeki ticket'lar örneklenerek ek onay gereksinimi doğrulanır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (IR-4), CIS critical patch guidance
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 24/3 (acil değişikliklerin sonradan onayı ve iz kaydı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG11-07 — Sanallaştırma katmanı (ESXi, vCenter, NSX, Cloud Director) kimliği doğrulanmış (authenticated) zafiyet taramasına dahil mi ve bulgu kapatma SLA'i tanımlı mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** v3-GAP-12 · **İlişkili üst kontrol:** `KG11-01`

- **Denetim Amacı:** Yama planının varsayıma değil, ölçülmüş zafiyet envanterine dayanmasını sağlamak.
- **Olası Riskler:** Sanallaştırma katmanı sunucu taramalarının kapsamı dışında bırakıldığında, host ve yönetim düzlemindeki bilinen zafiyetler envantere hiç girmez; yama önceliklendirmesi eksik veri üzerinden yapılır.
- **Beklenen Kanıt:** Tarama kapsam tanımı (varlık grubu / IP blokları) ve sanallaştırma varlıklarının bu kapsamda olduğunu gösteren çıktı; son iki döneme ait tarama raporları; bulgu kapatma SLA tanımı ve gecikmiş bulgu listesi; kimlik doğrulamalı tarama için kullanılan hesabın yetkileri.
- **Kanıta Ulaşım Yöntemi:** Kurumun zafiyet yönetimi platformundan varlık grubu tanımı ve son raporlar salt okunur (read-only) olarak alınır; tarama hesabının yetkileri vCenter/ESXi tarafında ayrıca doğrulanır (salt okunur rol olmalıdır).
- **Kabul Ölçütleri:** ESXi host'ları, vCenter/VCSA, NSX Manager ve Cloud Director bileşenleri zafiyet tarama kapsamında olmalı; tarama kimlik doğrulamalı yapılmalıdır. Bulgu kapatma SLA'i kritiklik seviyesine göre tanımlı olmalı ve gecikmiş bulgular izlenmelidir. Tarama hesabı en az yetki (least privilege) ilkesine uygun, salt okunur (read-only) olmalıdır.
- **İnceleme ve Test Adımları:** Varlık envanterini tarama kapsamıyla karşılaştır; kapsamda olmayan host veya bileşen varsa bu başlı başına bulgudur. Taramanın kimlik doğrulamalı yapıldığını rapordaki kimlik doğrulama durumu alanından doğrula — kimlik doğrulamasız tarama hypervisor zafiyetlerinin çoğunu görmez. Gecikmiş bulguları SLA ile karşılaştır.
- **İncelenecek Kayıtlar ve Örnekleme:** Varlık envanterinin tamamı ile tarama kapsamının karşılaştırması; son iki dönem raporu. Bulgu örneklemi kritiklik seviyesine göre tabakalandırılır.
- **Kanıtın Sınırları:** Tarama sonucu tarama anını ve tarayıcının görebildiği yüzeyi gösterir; sıfırıncı gün zafiyetlerini kapsamaz. Kimlik doğrulamasız tarama sonucu, kapsama kanıtı olarak kabul edilmez.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** v3 kapsam boşluğu analizi — BDDK-BSY Md. 16/3 kapsama boşluğu
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 16/3 (otomatik zafiyet taraması); BDDK-BSY Md. 16/1 (yama yönetimi prosedürü); CBDDO BİGR 3.5.3.3-4 (zafiyet ve yama yönetimi)
- **İyi Uygulama (Standart/Baseline):** NIST SP 800-53 Rev.5 RA-5 (zafiyet izleme ve tarama), RA-5(5) (ayrıcalıklı erişimle tarama)
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 13.6, 14.1–14.3

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG11-08 — Broadcom/VMware VMSA güvenlik duyuruları izleniyor, ortama etkisi değerlendiriliyor ve gerektiğinde acil yama süreci tetikleniyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi + Mülakat · **Kaynak:** v3-GAP-13 · **İlişkili üst kontrol:** `KG11-06`

- **Denetim Amacı:** Üretici duyurusu ile kurumdaki karar arasındaki süreyi ölçülebilir ve kayıtlı hâle getirmek.
- **Olası Riskler:** Hypervisor kaçış ve kimlik doğrulama atlatma zafiyetleri yalnız yama ile kapanır. Duyuru takibi kurumsallaşmamışsa tespit süresi haftalara çıkar: CVE-2024-37085 (AD "ESX Admins" atlatma) ve VMSA-2025-0004 kapsamındaki kaçış zinciri, duyuru sonrası kısa sürede fidye yazılımı gruplarınca kullanılmıştır.
- **Beklenen Kanıt:** VMSA duyuru takip mekanizmasının tanımı (abonelik, besleme, sorumlu rol); son dört çeyrekte yayımlanan kritik VMSA'ler için etki değerlendirme kayıtları; acil yama tetikleme kararları ve uygulama tarihleri; CISA KEV kataloğuyla eşleştirme yapılıyorsa buna ilişkin kayıt.
- **Kanıta Ulaşım Yöntemi:** Duyuru takip kayıtları ve etki değerlendirmeleri süreç sahibinden; acil yama kararları ITSM değişiklik kayıtlarından alınır; kurulu sürümler vCenter envanterinden salt okunur (read-only) olarak doğrulanır.
- **Kabul Ölçütleri:** VMSA duyuruları tanımlı bir sorumlu tarafından izlenmeli; her kritik duyuru için ortam etkisi (etkilenen sürüm ve bileşen envanteri üzerinden) kayıtlı olarak değerlendirilmeli; etkilenen durumda acil yama prosedürü tanımlı süre içinde tetiklenmelidir. Fiilen istismar edilen zafiyetler (CISA KEV) için ayrı ve daha kısa bir süre tanımlı olmalıdır.
- **İnceleme ve Test Adımları:** Son dört çeyreğin kritik VMSA listesini kurumun etki değerlendirme kayıtlarıyla eşle; değerlendirilmemiş duyuru varsa bulgu adayıdır. Etkilenen olarak işaretlenen duyurular için yama uygulama tarihini duyuru tarihiyle karşılaştır ve kurumun tanımlı süresiyle değerlendir. Kurulu sürümleri vCenter envanterinden doğrula — yalnız kayıt üzerinden sonuç verme.
- **İncelenecek Kayıtlar ve Örnekleme:** Son dört çeyreğin kritik VMSA duyurularının tamamı. Örnekleme yapılmaz; kapsanmayan dönem analizde belirtilir.
- **Kanıtın Sınırları:** Kayıt üzerinden yapılan inceleme, yamanın fiilen tüm host'lara uygulandığını kanıtlamaz; kurulu sürüm envanteriyle çapraz doğrulama gerekir. Duyuru takibi sıfırıncı gün riskini ortadan kaldırmaz.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** v3 kapsam boşluğu analizi — VMSA-2025-0004 ve CVE-2024-37085 tespit süresi
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 16/1 (yama yönetimi prosedürü); CBDDO BİGR 3.1.9.1 (üretici desteği devam eden kararlı sürümler; güvenlik duyurularının takibi)
- **İyi Uygulama (Standart/Baseline):** NIST SP 800-53 Rev.5 SI-2 (kusur giderme), SI-5 (güvenlik uyarıları ve tavsiyeleri), RA-3 (risk değerlendirme)
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4; IIA-GIAS: 13.4, 13.6, 14.1–14.3

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

