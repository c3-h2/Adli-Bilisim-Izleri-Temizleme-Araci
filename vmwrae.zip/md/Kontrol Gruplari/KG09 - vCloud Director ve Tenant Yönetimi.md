# KG09 - vCloud Director ve Tenant Yönetimi

**Çalışma:** VMware MSP Denetimi · **Sürüm:** v4 — 14 Eylül 2026  
**Doküman:** Kontrol grubu çalışma listesi — 10 kontrol  
**Hazırlayan:** KKB İç Denetim Başkanlığı — BT Denetimi (danışmanlık çıktısıdır, son karar denetçinindir)  
**Ana dizin:** `00 - Ana Dizin ve Dokuman Haritasi.xlsx`

---

> Uyumsuzluk hükmü yalnızca **Bağlayıcı Kriter (Mevzuat)** alanındaki maddeye atıfla verilebilir. **İyi Uygulama** alanı tek başına uyumsuzluk dayanağı değildir. Terim ve kısaltmalar için `03 - Terimler` ve `04 - Kisaltmalar` dokümanlarına, metodoloji için `01 - Kapsam ve Metodoloji` dokümanına bakınız.

| Kontrol ID | Denetim Sorusu | Öncelik | Test Yöntemi | Kaynak |
|---|---|---|---|---|
| `KG09-01` | Tenant onboarding workflow'u güvenlik kontrolleriyle bütünleşik mi? | Yüksek | Doküman İncelemesi + Güvenlik Denetimi | 12 KG |
| `KG09-02` | Tenantlar arasında ağ, hesap ve compute izolasyonu teknik olarak uygulanmış mı? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG09-03` | Tenant yöneticilerinin rol ve erişimleri sadece kendi tenant kapsamını kapsıyor mu? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG09-04` | Tenant quota, resource limit ve izleme politikaları uygulanıyor mu? | Orta | Güvenlik Denetimi | 12 KG |
| `KG09-05` | Tenant offboarding işlemlerinde hesap, VM ve depolama kalıntıları (residual data) tamamen temizleniyor mu? | Yüksek | Güvenlik Denetimi + Doküman İncelemesi | 12 KG |
| `KG09-06` | Tenant şablon (template)ları merkezi yönetiliyor ve güvenli imaj onayı var mı? | Orta | Doküman İncelemesi + Güvenlik Denetimi | 12 KG |
| `KG09-07` | Cloud Director: Rights bundle ve global role yayınları sadece hedef organizasyonları kapsıyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-01 |
| `KG09-08` | Cloud Director: Tenant hesabı başka organizasyonun VM, ağ, katalog ve görevlerini görebiliyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-02 |
| `KG09-09` | Cloud Director: Paylaşılan katalog ve şablon (template)larda sırlar veya müşteri kalıntıları (residual data) temizleniyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-03 |
| `KG09-10` | Cloud Director: Catalog, vApp template ve content library paylaşımı yalnız hedef organizationlarla sınırlandırılmış mı? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-04 |

## KG09-01 — Tenant onboarding workflow'u güvenlik kontrolleriyle bütünleşik mi?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Yeni kiracıların kontrolsüz yetki ve ağ açığıyla devreye girmesini engellemek.
- **Olası Riskler:** Onboarding'de unutulan izolasyon ve rol hataları.
- **Beklenen Kanıt:** Onboarding checklisti, onaylı template, test kapanış tutanakları
- **Kanıta Ulaşım Yöntemi:** Son 12 onboard kaydı incelenir, güvenlik checklist'in eksiksiz doldurulduğu teyit edilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS vCloud Director, NIST SP 800-53 (AC-2)
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 29/1-b,d (sağlayıcı seçiminde özen, dış hizmet sistemlerinin bankanın güvenlik politikalarına uygunluğu), BDDK-BSY Md. 11/6 (yetkilendirme)
- **İyi Uygulama (Standart/Baseline):** ISO/IEC 27002:2022 5.18 (erişim haklarının sağlanması ve iptali süreci)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG09-02 — Tenantlar arasında ağ, hesap ve compute izolasyonu teknik olarak uygulanmış mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Çok kiracılı yapıda izole çalışma alanını garanti etmek.
- **Olası Riskler:** Bir tenant'tan diğerine veri ve trafik geçişi.
- **Beklenen Kanıt:** Org-VDC mapping, network topology, firewall kuralları
- **Kanıta Ulaşım Yöntemi:** vCloud API/admin export ile tenant sınırları kontrol edilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (SC-7), CIS multitenancy guide
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.11 (sanal makineler arası trafik güvenlik kontrollerinden geçirilmeli), CBDDO 3.1.6.6 (ağların izole edilmesi), BDDK-BSY Md. 14/2 (güvenlik duvarı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG09-03 — Tenant yöneticilerinin rol ve erişimleri sadece kendi tenant kapsamını kapsıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Yetki sınırını koruyarak çapraz erişim riskini sıfırlamak.
- **Olası Riskler:** Tenant admin hesabının sistem yöneticisi yetkisi elde etmesi.
- **Beklenen Kanıt:** Permission mapping, role template, deny kontrol listeleri
- **Kanıta Ulaşım Yöntemi:** Tenant kullanıcıları rol bazında raporlanır, out-of-scope izni test edilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS vCloud RBAC, NIST SP 800-53 (AC-3, AC-6)
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 11/6 (en az yetki, sadece bilmesi gereken veri, yıllık gözden geçirme)
- **İyi Uygulama (Standart/Baseline):** NIST SP 800-53 Rev.5 AC-2(11) (kullanım koşulları), ISO/IEC 27002:2022 5.18 (görevler ayrılığı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG09-04 — Tenant quota, resource limit ve izleme politikaları uygulanıyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Kaynak tükenmesi ile diğer tenant etkilenmesini önlemek.
- **Olası Riskler:** Noisy-neighbor nedeniyle kritik iş yükü yavaşlaması.
- **Beklenen Kanıt:** Quota ayarları, kullanım raporları, alarm listesi
- **Kanıta Ulaşım Yöntemi:** Tenant bazlı quota ve gerçek tüketimi karşılaştır, limit aşımı örnekleri aranır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (SC-5), CIS cloud tenancy controls
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.2 (sanallaştırma ortamının kapasitesinin izlenmesi ve kapasite planlaması)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG09-05 — Tenant offboarding işlemlerinde hesap, VM ve depolama kalıntıları (residual data) tamamen temizleniyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi + Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Kapanan müşterinin geri dönemez erişim izi bırakmasını engellemek.
- **Olası Riskler:** Hesap kalıntıları (residual data) ile yetki dışı erişim.
- **Beklenen Kanıt:** Offboarding checklist, silme logları, kalan kaynak taraması
- **Kanıta Ulaşım Yöntemi:** Kapanış ticket'ında listelenen kaynaklarla canlı envanter karşılaştırılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (AC-2(3)), BDDK hesap yönetimi ilkeleri
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 11/6 (erişimin gerekli olduğu süre zarfında yetkilendirme, gözden geçirme), CBDDO 3.1.9.13 (sanallaştırma ortamının yedeklenmesi)
- **İyi Uygulama (Standart/Baseline):** ISO/IEC 27002:2022 5.18 (erişim haklarının zamanında kaldırılması)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG09-06 — Tenant şablon (template)ları merkezi yönetiliyor ve güvenli imaj onayı var mı?

**Öncelik:** Orta · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Kötü amaçlı veya eksik güvenlikli imajın yayılmasını engellemek.
- **Olası Riskler:** Standart dışı imajla virüs/logiksel arka kapı bulaşması.
- **Beklenen Kanıt:** Template versioning, onay süreçleri, imaj doğrulama kayıtları
- **Kanıta Ulaşım Yöntemi:** Şablon kütüphanesi sürüm geçmişi ile güvenlik kontrol sonuçları karşılaştırılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS template governance, NIST SP 800-53 (CM-2)
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.6 (imaj bütünlüğünün denetlenmesi ve izlenmesi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG09-07 — Cloud Director: Rights bundle ve global role yayınları sadece hedef organizasyonları kapsıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-01 · **İlişkili üst kontrol:** `KG09-03`

- **Denetim Amacı:** Rol yayınlarının sözleşme kapsamıyla sınırlı olmasını doğrulamak.
- **Olası Riskler:** Geniş rol yayını müşteriye beklenmeyen yönetim kabiliyeti verir. + RISK-C + RISK-B
- **Beklenen Kanıt:** Global roles, rights bundles ve published tenants exportu.
- **Kanıta Ulaşım Yöntemi:** Cloud Director Provider portal/OpenAPI rol ve rights bundle nesnelerini published tenant kapsamıyla alın; tenant oturumunda görünen organization/nesne listesiyle karşılaştırın. Provider çıktısının tenant yetkisini tek başına kanıtladığını varsaymayın.
- **Kabul Ölçütleri:** Yayımlanan haklar hizmet sözleşmesi ve rol matrisiyle sınırlı olmalı.
- **İnceleme ve Test Adımları:** Bir rolün haklarını ve yayımlandığı organizasyonları birlikte kontrol et. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** Global roles, rights bundles ve published tenants exportu. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-4

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** VMW-VCD: Global Roles, Query Global Role Tenants; NIST-53: AC-3; AC-6; BIGR: 4.3.1.4 | 4.3.1.4 — basılı s.164 / PDF 168
- **Teknik Referanslar:** VMW-VCD: Global Roles, Query Global Role Tenants; NIST-53: AC-3; AC-6; BIGR: 4.3.1.4 | 4.3.1.4 — basılı s.164 / PDF 168
- **Erişim Referansları:** VMW-VCD; NIST-ASSESS
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG09-08 — Cloud Director: Tenant hesabı başka organizasyonun VM, ağ, katalog ve görevlerini görebiliyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-02 · **İlişkili üst kontrol:** `KG09-02`

- **Denetim Amacı:** Çapraz organizasyon erişim engelinin etkinliğini doğrulamak.
- **Olası Riskler:** API veya portal üzerinden başka müşterinin verisi açığa çıkar. + RISK-C + RISK-B
- **Beklenen Kanıt:** İki tenant test hesabı, API cevapları, rol ve nesne listesi.
- **Kanıta Ulaşım Yöntemi:** Cloud Director Provider portal/OpenAPI rol ve rights bundle nesnelerini published tenant kapsamıyla alın; tenant oturumunda görünen organization/nesne listesiyle karşılaştırın. Provider çıktısının tenant yetkisini tek başına kanıtladığını varsaymayın.
- **Kabul Ölçütleri:** İzin verilmeyen çapraz organizasyon (cross-organization) okuma/değiştirme reddedilmeli.
- **İnceleme ve Test Adımları:** Bilinen test nesnesine diğer tenant ile eriş; kendi nesnesine olumlu erişimle birlikte kaydet. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** İki tenant test hesabı, API cevapları, rol ve nesne listesi. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-4

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST-53: AC-3; NIST-53: AC-3; SC-4; BIGR: 4.3.1.4 | 4.3.1.4 — basılı s.164 / PDF 168
- **Teknik Referanslar:** NIST-53: AC-3; NIST-53: AC-3; SC-4; BIGR: 4.3.1.4 | 4.3.1.4 — basılı s.164 / PDF 168
- **Erişim Referansları:** VMW-VCD; NIST-ASSESS
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG09-09 — Cloud Director: Paylaşılan katalog ve şablon (template)larda sırlar veya müşteri kalıntıları (residual data) temizleniyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-03 · **İlişkili üst kontrol:** `KG09-06`

- **Denetim Amacı:** Paylaşılan imajlarda sır/kalıntı (residual data) temizliğini doğrulamak.
- **Olası Riskler:** Şablon içindeki token/parola/veri tüm abonelere yayılabilir. + RISK-C + RISK-B
- **Beklenen Kanıt:** Katalog paylaşım listesi, imaj üretim ve kontrol kayıtları.
- **Kanıta Ulaşım Yöntemi:** Cloud Director katalog nesnesinin paylaşım, publish/subscription ve template/vApp üyeliğini hedef organization kimliğiyle alın; imajın üretim/onay kaydını katalog sahibinden temin edin.
- **Kabul Ölçütleri:** İmaj onayı, bütünlük kontrolü ve gizli veri temizleme kanıtı olmalı.
- **İnceleme ve Test Adımları:** Bir paylaşılan şablon (template)un kaynağını ve yayım öncesi denetimini kontrol et. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** Katalog paylaşım listesi, imaj üretim ve kontrol kayıtları. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-4

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST-53: SI-7; NIST-53: SI-7; MP-6; BIGR: 3.1.9.6; 4.3.1.5 | 3.1.9.6 — basılı s.61 / PDF 65 4.3.1.5 — basılı s.164 / PDF 168
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.6 (imaj bütünlüğünün denetlenmesi ve izlenmesi)
- **Teknik Referanslar:** NIST-53: SI-7; NIST-53: SI-7; MP-6; BIGR: 3.1.9.6; 4.3.1.5 | 3.1.9.6 — basılı s.61 / PDF 65 4.3.1.5 — basılı s.164 / PDF 168
- **Erişim Referansları:** VMW-VCD; NIST-ASSESS
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG09-10 — Cloud Director: Catalog, vApp template ve content library paylaşımı yalnız hedef organizationlarla sınırlandırılmış mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-04 · **İlişkili üst kontrol:** `KG09-06`

- **Denetim Amacı:** Katalog paylaşım sınırının onayla uyumunu doğrulamak.
- **Olası Riskler:** vCloud Director müşteri alanı ve yetki izolasyonu yeterli değilse, bir müşteri diğerinin verisine, yönetim nesnesine veya hizmet kaynağına erişebilir. + RISK-C + RISK-B
- **Beklenen Kanıt:** Catalog sharing ve publish/subscription ayarları
- **Kanıta Ulaşım Yöntemi:** Cloud Director katalog nesnesinin paylaşım, publish/subscription ve template/vApp üyeliğini hedef organization kimliğiyle alın; imajın üretim/onay kaydını katalog sahibinden temin edin.
- **Kabul Ölçütleri:** Özel katalog başka tenantta görünmez; paylaşım listesi onayla eşleşir.
- **İnceleme ve Test Adımları:** TEST-2 + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** Catalog sharing ve publish/subscription ayarları. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-4

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST-53: AC-4; SC-4
- **Teknik Referanslar:** NIST-53: AC-4; SC-4
- **Erişim Referansları:** VMW-VCD; NIST-ASSESS
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

