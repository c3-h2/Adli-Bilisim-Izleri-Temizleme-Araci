# KG08 - vMotion, Migration, HA-DRS, Affinity Kuralları

**Çalışma:** VMware MSP Denetimi · **Sürüm:** v4 — 14 Eylül 2026  
**Doküman:** Kontrol grubu çalışma listesi — 8 kontrol  
**Hazırlayan:** KKB İç Denetim Başkanlığı — BT Denetimi (danışmanlık çıktısıdır, son karar denetçinindir)  
**Ana dizin:** `00 - Ana Dizin ve Dokuman Haritasi.xlsx`

---

> Uyumsuzluk hükmü yalnızca **Bağlayıcı Kriter (Mevzuat)** alanındaki maddeye atıfla verilebilir. **İyi Uygulama** alanı tek başına uyumsuzluk dayanağı değildir. Terim ve kısaltmalar için `03 - Terimler` ve `04 - Kisaltmalar` dokümanlarına, metodoloji için `01 - Kapsam ve Metodoloji` dokümanına bakınız.

| Kontrol ID | Denetim Sorusu | Öncelik | Test Yöntemi | Kaynak |
|---|---|---|---|---|
| `KG08-01` | vMotion ve Storage vMotion yetkileri sadece gerekli kullanıcı/rollere ve yetkili ağlara kısıtlı mı? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG08-02` | HA/DRS affinity ve anti-affinity kuralları kritik servislere göre uygulanmış mı? | Yüksek | Güvenlik Denetimi + Doküman İncelemesi | 12 KG |
| `KG08-03` | HA admission control ve failover parametreleri iş taleplerine uygun mu? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG08-04` | Bakım pencerelerinde vMotion/DRS aksiyonları önceden onaylanmış runbook'a göre mi yürütülüyor? | Orta | Doküman İncelemesi + Güvenlik Denetimi | 12 KG |
| `KG08-05` | vMotion kapasite ve performans alarm eşikleri belirlenmiş mi? | Orta | Güvenlik Denetimi | 12 KG |
| `KG08-06` | Pinned, anti-affinity ve sınıflandırma kurallarına uygun migration istisnaları yönetiliyor mu? | Orta | Doküman İncelemesi + Güvenlik Denetimi | 12 KG |
| `KG08-07` | vMotion: Taşıma işlemi VM'yi izin verilmeyen müşteri veya lokasyon havuzuna götürebiliyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-23 |
| `KG08-08` | vMotion: vMotion sonrasında güvenlik politikası ve müşteri ağı aynı şekilde korunuyor mu? | Yüksek | Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) | EK G2-24 |

## KG08-01 — vMotion ve Storage vMotion yetkileri sadece gerekli kullanıcı/rollere ve yetkili ağlara kısıtlı mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Taşıma işlemlerinde yetkisiz hareketi engellemek.
- **Olası Riskler:** Yetkisi olmayan kullanıcıyla kritik VM'in yer değiştirmesi veya durdurulması.
- **Beklenen Kanıt:** Migration izleme logları, roller, erişim kısıtlama listeleri
- **Kanıta Ulaşım Yöntemi:** Son migration event'leri alınır, kim/kimi taşıdığı ve yetki düzeyi değerlendirilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS vMotion controls, NIST SP 800-53 (AC-2, CM-2)
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 11/6 (en az yetki, yıllık gözden geçirme), CBDDO 3.1.9.9 (yönetim ortamına erişim kontrolü), BDDK-BSY Md. 14/7 (uzaktan erişim kısıtları)
- **İyi Uygulama (Standart/Baseline):** ISO/IEC 27002:2022 5.18 (ayrıcalıklı erişim yetkilendirmeleri)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG08-02 — HA/DRS affinity ve anti-affinity kuralları kritik servislere göre uygulanmış mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi + Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Tek hata alanında yığılmayı engellemek.
- **Olası Riskler:** Bir host/cluster failure ile çok kritik katmanın aynı anda devre dışı kalması.
- **Beklenen Kanıt:** Rule catalog, cluster map, VM-placement raporu
- **Kanıta Ulaşım Yöntemi:** Critical workload'lerin kural eşleşmesi kontrol edilir, ihlal varsa örnekleme (sampling) ile gösterilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (CP-10), VMware HA/DRS best practices
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 27/2 (yedek veri işleme sistemi, süreklilik), BDDK-BSY Md. 28/3 (süreklilik planı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG08-03 — HA admission control ve failover parametreleri iş taleplerine uygun mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Kapanma anında VM başlatma kapasitesinin korunması.
- **Olası Riskler:** Failover anında yetersiz kaynak nedeniyle hizmet verilememesi.
- **Beklenen Kanıt:** Cluster ayarları, resource reservation, geçmiş failover logları
- **Kanıta Ulaşım Yöntemi:** Konfigürasyon ayarları ile son HA tetikleme kayıtları kıyaslanır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS HA/DRS guidance, NIST SP 800-53 (CP-10)
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 27/2 (yedek veri işleme sistemi), CBDDO 3.1.9.2 (kapasite izlenmesi ve planlaması)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG08-04 — Bakım pencerelerinde vMotion/DRS aksiyonları önceden onaylanmış runbook'a göre mi yürütülüyor?

**Öncelik:** Orta · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Planlı bakımın kontrolsüz migration ile servis etkisini azaltmak.
- **Olası Riskler:** Plan dışı VM taşımaları ve beklenmeyen iş etkileri.
- **Beklenen Kanıt:** Bakım talimatı, maintenance mode logları, migration kayıtları
- **Kanıta Ulaşım Yöntemi:** Planlı bakım ticket'larında migration event'leri karşılaştırılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** CIS operations control, NIST SP 800-53 (CP-2)
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 24/1 (değişiklik yönetimi prosedürü, yetkili onayı, test, geri alma planı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG08-05 — vMotion kapasite ve performans alarm eşikleri belirlenmiş mi?

**Öncelik:** Orta · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Kritik SLA etkilerini erkenden tespit etmek.
- **Olası Riskler:** Ani ağ/memory baskısıyla performans düşüşü.
- **Beklenen Kanıt:** Alarm kuralları, performans metrikleri geçmişi
- **Kanıta Ulaşım Yöntemi:** Son 30 günlük vMotion job süreleri incelenir, eşik ihlalleri raporlanır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (SI-4), CIS performance monitoring
- **Bağlayıcı Kriter (Mevzuat):** CBDDO 3.1.9.2 (kapasite izlenmesi), BDDK-BSY Md. 13/3 (iz kayıtlarının düzenli izlenmesi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG08-06 — Pinned, anti-affinity ve sınıflandırma kurallarına uygun migration istisnaları yönetiliyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Kritik VM'lerin iş kurallarını bozan yer değiştirmeyi önlemek.
- **Olası Riskler:** Yanlış yere taşınan VM'den dolayı lisans/performans/uyum ihlali.
- **Beklenen Kanıt:** İş yükü sınıflandırması, migration policy override listesi
- **Kanıta Ulaşım Yöntemi:** Migration event'leriyle sınıflandırma listesi eşleştirilir, override alanları gerekçelendirilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (CP-10, SC-7), CIS migration controls
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 24/1 (değişiklik yönetimi, onay), CBDDO 3.1.9.11 (VM'ler arası trafik kontrolü)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG08-07 — vMotion: Taşıma işlemi VM'yi izin verilmeyen müşteri veya lokasyon havuzuna götürebiliyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-23 · **İlişkili üst kontrol:** `KG08-01`

- **Denetim Amacı:** Taşıma hedeflerinin sözleşme sınırlarıyla uyumunu doğrulamak.
- **Olası Riskler:** Taşıma veri yerleşimi ve fiziksel izolasyon şartlarını bozabilir. + RISK-C + RISK-B
- **Beklenen Kanıt:** Cluster/datacenter hedef listesi, taşıma yetkileri, görev kayıtları.
- **Kanıta Ulaşım Yöntemi:** Host VMkernel adapters üzerindeki vMotion hizmetini, VM encryption/migration ayarını ve vCenter Tasks/Events içindeki taşıma kaydını okuyun. Aynı görev için kaynak/hedef host, müşteri, segment ve DFW üyeliğini ön/son kanıtlarla eşleştirin.
- **Kabul Ölçütleri:** İzinli hedefler sınıflandırma ve sözleşme sınırlarıyla uyumlu olmalı.
- **İnceleme ve Test Adımları:** Bir tenant için izinli ve izinsiz hedef yetkilerini karşılaştır. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** Cluster/datacenter hedef listesi, taşıma yetkileri, görev kayıtları. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-4

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST-53: AC-3; BDDK-2020: md.25; NIST-53: AC-3; SC-32; BIGR: 3.1.9.13 | 3.1.9.13 — basılı s.62 / PDF 66
- **Teknik Referanslar:** NIST-53: AC-3; BDDK-2020: md.25; NIST-53: AC-3; SC-32; BIGR: 3.1.9.13 | 3.1.9.13 — basılı s.62 / PDF 66
- **Erişim Referansları:** VMW-VMOTION; VMW-SCG
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG08-08 — vMotion: vMotion sonrasında güvenlik politikası ve müşteri ağı aynı şekilde korunuyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Yapılandırma İncelemesi + Kontrollü Test (Configuration Review + Controlled Test) · **Kaynak:** G2-24 · **İlişkili üst kontrol:** `KG08-06`

- **Denetim Amacı:** Taşıma sonrası güvenlik eşdeğerliğini doğrulamak.
- **Olası Riskler:** Taşınan VM yanlış ağda veya farklı güvenlik kapsamında kalabilir. + RISK-C + RISK-B
- **Beklenen Kanıt:** Görev ID, kaynak/hedef host, ön/son ağ ve DFW üyeliği.
- **Kanıta Ulaşım Yöntemi:** Host VMkernel adapters üzerindeki vMotion hizmetini, VM encryption/migration ayarını ve vCenter Tasks/Events içindeki taşıma kaydını okuyun. Aynı görev için kaynak/hedef host, müşteri, segment ve DFW üyeliğini ön/son kanıtlarla eşleştirin.
- **Kabul Ölçütleri:** Taşıma öncesi/sonrası ağ, erişim ve güvenlik kontrolleri eşdeğer olmalı.
- **İnceleme ve Test Adımları:** Test VM taşımasının iki tarafındaki izinli/yasaklı akış sonucunu karşılaştır. + TAIL-2
- **İncelenecek Kayıtlar ve Örnekleme:** Görev ID, kaynak/hedef host, ön/son ağ ve DFW üyeliği. + KAYIT-B
- **Kanıtın Sınırları:** SINIR-4

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST-53: CM-3; NIST-53: CM-3; CA-2; BIGR: 3.1.9.7 | 3.1.9.7 — basılı s.61 / PDF 65
- **Teknik Referanslar:** NIST-53: CM-3; NIST-53: CM-3; CA-2; BIGR: 3.1.9.7 | 3.1.9.7 — basılı s.61 / PDF 65
- **Erişim Referansları:** VMW-VMOTION; VMW-SCG
- **Denetim Yöntemi Referansları:** NIST-ASSESS: 2.4, 3.2–3.4, Ek C; IIA-GIAS: 13.4, 13.6, 14.1–14.3, 14.6

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

