# KG12 - Loglama, İzleme ve Kritik Durum Alarm Yönetimi

**Çalışma:** VMware MSP Denetimi · **Sürüm:** v4 — 14 Eylül 2026  
**Doküman:** Kontrol grubu çalışma listesi — 6 kontrol  
**Hazırlayan:** KKB İç Denetim Başkanlığı — BT Denetimi (danışmanlık çıktısıdır, son karar denetçinindir)  
**Ana dizin:** `00 - Ana Dizin ve Dokuman Haritasi.xlsx`

---

> Uyumsuzluk hükmü yalnızca **Bağlayıcı Kriter (Mevzuat)** alanındaki maddeye atıfla verilebilir. **İyi Uygulama** alanı tek başına uyumsuzluk dayanağı değildir. Terim ve kısaltmalar için `03 - Terimler` ve `04 - Kisaltmalar` dokümanlarına, metodoloji için `01 - Kapsam ve Metodoloji` dokümanına bakınız.

| Kontrol ID | Denetim Sorusu | Öncelik | Test Yöntemi | Kaynak |
|---|---|---|---|---|
| `KG12-01` | vCenter, ESXi, NSX, vCloud logları tek kanalda bütünlüklü ve imzalı toplanıyor mu? | Yüksek | Güvenlik Denetimi + Doküman İncelemesi | 12 KG |
| `KG12-02` | Kritik event sınıfları için alarm eşiği tanımlı ve test edilmiş mi? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG12-03` | Kritik alarm sonrası olay yanıt (incident response) playbook'u ve SLA hedefi uygulanıyor mu? | Yüksek | Doküman İncelemesi + Güvenlik Denetimi | 12 KG |
| `KG12-04` | Kritik güvenlik eventleri (snapshot anomalisi, auth anomaly, migration kritik event) için korelasyon kuralları (correlation rules) var mı? | Yüksek | Güvenlik Denetimi | 12 KG |
| `KG12-05` | Log saklama süresi (retention period) ve arşivleme süreci düzenlemelere uygun mu? | Orta | Doküman İncelemesi + Güvenlik Denetimi | 12 KG |
| `KG12-06` | Varlık üzerindeki alarm yükü için vardiya ve alarm gürültüsü (alert noise) filtreleme politikası çalışıyor mu? | Orta | Doküman İncelemesi + Güvenlik Denetimi | 12 KG |

## KG12-01 — vCenter, ESXi, NSX, vCloud logları tek kanalda bütünlüklü ve imzalı toplanıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi + Doküman İncelemesi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Olay deliline güvenilirlik kazandırmak.
- **Olası Riskler:** Dağınık ve manipüle edilebilir loglarla yanlış teşhis.
- **Beklenen Kanıt:** SIEM yapılandırması, log imza/retention politikası, zaman eşitleme
- **Kanıta Ulaşım Yöntemi:** Merkezdeki son 90 gün log kümesiyle zaman fark ve bütünlük ayarları kontrol edilir.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (AU-6, AU-8, AU-9), NIST SP 800-92
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 13/1 (iz kayıtları asgari içerik: sistem, tarih/saat/zaman dilimi, değişiklik, tekil kullanıcı), BDDK-BSY Md. 13/3 (düzenli izleme, şüpheli işlemlerin derhal incelenmesi), CBDDO 3.1.8.x (iz kayıtlarının tutulması ve izlenmesi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG12-02 — Kritik event sınıfları için alarm eşiği tanımlı ve test edilmiş mi?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Anında müdahale gerektiren olayları kaçırmamak.
- **Olası Riskler:** Alarm gecikmesi, büyüyen olayın fark edilmemesi.
- **Beklenen Kanıt:** Alarm policy, severity mapping, test simülasyon çıktıları
- **Kanıta Ulaşım Yöntemi:** Kritik event catalog'u ve eşik test sonuçları alınır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (SI-4), CIS monitoring best practice
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 13/3 (iz kayıtlarının düzenli izlenmesi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG12-03 — Kritik alarm sonrası olay yanıt (incident response) playbook'u ve SLA hedefi uygulanıyor mu?

**Öncelik:** Yüksek · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Alarmın işleme zamanını ve kaliteyi standartlaştırmak.
- **Olası Riskler:** Çok ses getiren ama etkisiz alarm zincirleri.
- **Beklenen Kanıt:** IR playbook, on-call raporları, kapanış süreleri
- **Kanıta Ulaşım Yöntemi:** Son olay kayıtları örneklenir, kapanış süreleri SLA ile karşılaştırılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-61r2, NIST SP 800-53 (IR-4)
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 18/1 (siber olay yönetimi ve müdahale süreci, Kurumsal SOME, Kuruma raporlama), BDDK-BSY Md. 18/3 (siber olayların Kuruma bildirimi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG12-04 — Kritik güvenlik eventleri (snapshot anomalisi, auth anomaly, migration kritik event) için korelasyon kuralları (correlation rules) var mı?

**Öncelik:** Yüksek · **Test Yöntemi:** Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Tekil event zincirini tek bir alarmda birleştirip saldırı görünürlüğünü artırmak.
- **Olası Riskler:** Parçalı göstergelerle gerçek saldırı kaçırılabilir.
- **Beklenen Kanıt:** Correlation rule export, örnek korelasyon sonuçları, false positive analizleri
- **Kanıta Ulaşım Yöntemi:** Kural tanımları alınır, son 30 günde en az bir kritik kural tetikleyicisi doğrulanır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (SI-4), CIS SIEM playbook
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 13/3 (iz kayıtlarının düzenli izlenmesi, şüpheli işlemlerin derhal incelenmesi)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG12-05 — Log saklama süresi (retention period) ve arşivleme süreci düzenlemelere uygun mu?

**Öncelik:** Orta · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Geçmiş olaylar için yeterli kanıtın kesintisiz kalması.
- **Olası Riskler:** Denetim döneminde geçmiş olayın kanıtlanamaması.
- **Beklenen Kanıt:** Retention policy, arşivleme görevleri, purge logları
- **Kanıta Ulaşım Yöntemi:** Politikadaki süre ile platform ayarı ve gerçek silme geçmişi karşılaştırılır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (AU-11), BDDK regülasyonları, ISO 27001 A.12.4
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 13/3 (iz kayıtları en az 3 yıl saklanmalı)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

## KG12-06 — Varlık üzerindeki alarm yükü için vardiya ve alarm gürültüsü (alert noise) filtreleme politikası çalışıyor mu?

**Öncelik:** Orta · **Test Yöntemi:** Doküman İncelemesi + Güvenlik Denetimi · **Kaynak:** 12 KG (KKB süreç seti)

- **Denetim Amacı:** Kritik alarmlarda müdahale gecikmesini azaltmak.
- **Olası Riskler:** Uyarıya tepki verilemeyen 'alarm yorgunluğu'.
- **Beklenen Kanıt:** Alert tuning raporu, vardiya planı, kapanış performans istatistiği
- **Kanıta Ulaşım Yöntemi:** Alarmların kapama süreleri incelenir, kritik olayların çözüm zamanları hesaplanır.

<details><summary>Dayanak ve referanslar</summary>

- **Orijinal Dayanak/Referans:** NIST SP 800-53 (SI-4), CIS SOC operation guidance
- **Bağlayıcı Kriter (Mevzuat):** BDDK-BSY Md. 13/3 (iz kayıtlarının düzenli izlenmesi), BDDK-BSY Md. 18/1 (siber olay müdahale süreci)

</details>

**Denetim Sonucu:** ☐ uygun ☐ uyumsuzluk ☐ kapsam dışı ☐ değerlendirilemedi  
**Kanıt Referansı:** _______  
**Bulgu Notu:** _______

