# Terimler

**Çalışma:** VMware MSP Denetimi · **Sürüm:** v4 — 14 Eylül 2026  
**Doküman:** Teknik terim sözlüğü ve kaynak/referans kodlarının açılımı  
**Hazırlayan:** KKB İç Denetim Başkanlığı — BT Denetimi (danışmanlık çıktısıdır, son karar denetçinindir)  
**Ana dizin:** `00 - Ana Dizin ve Dokuman Haritasi.xlsx`

---

Türkçeleştirildiğinde anlamı daralan teknik terimlerin kanonik İngilizce karşılıkları ve tanımları. Bu tanımlar **tanımlayıcıdır, denetim kriteri değildir**; bağlayıcı kriter yalnızca kontrol satırlarındaki *Bağlayıcı Kriter (Mevzuat)* alanıdır.

## Sanallaştırma platformu

| Terim (EN) | Türkçe Karşılık | Açıklama | İlgili Grup |
|---|---|---|---|
| **ESXi** | — | VMware'in bare-metal hypervisor'ü; sanal makineleri doğrudan donanım üzerinde çalıştırır. | KG03 |
| **vCenter Server / VCSA** | Merkezi yönetim sunucusu | ESXi host'larını, kümeleri ve politikaları tek noktadan yöneten yönetim düzlemi. VCSA = vCenter Server Appliance (hazır sanal appliance sürümü). | KG04 |
| **Hypervisor** | Sanallaştırma katmanı | Fiziksel donanımı birden çok sanal makineye paylaştıran yazılım katmanı. | KG03 |
| **Host** | Sunucu / ana makine | Hypervisor'ün kurulu olduğu fiziksel sunucu. | KG03 |
| **Guest OS** | Sanal makine işletim sistemi | VM içinde çalışan işletim sistemi; hypervisor'den ayrı yönetilir. "Misafir" çevirisi anlam kaybına yol açtığı için metinlerde guest OS olarak korunmuştur. | KG03 |
| **DCUI (Direct Console User Interface)** | Doğrudan konsol arayüzü | ESXi host'un fiziksel veya BMC konsolundan erişilen metin tabanlı yerel yönetim arayüzü. | KG03 |
| **ESXi Shell** | — | Host üzerinde yerel komut satırı erişimi; rutin işletimde kapalı tutulur. | KG03 |
| **Lockdown Mode** | Kilitleme modu | ESXi host'a vCenter dışından doğrudan yönetim erişimini kısıtlayan mod; Normal ve Strict seviyeleri vardır. | KG03 |
| **Exception User** | İstisna hesap | Lockdown Mode etkinken host'a doğrudan erişebilen, açıkça tanımlanmış bypass hesabı. | KG03 |
| **BMC (Baseboard Management Controller)** | Anakart yönetim denetleyicisi | Sunucunun işletim sisteminden bağımsız uzaktan yönetim denetleyicisi (iDRAC, iLO, XCC vb.); konsol ve sanal medya erişimi verdiği için ESXi kontrollerinden bağımsız bir erişim yoludur. | KG03 |
| **MOB (Managed Object Browser)** | — | vSphere yönetim nesnelerine web üzerinden erişim sağlayan hata ayıklama arayüzü; üretimde kapalı olmalıdır. | KG03 |
| **SLP (Service Location Protocol)** | — | ESXi'de CIM keşfi için kullanılan servis; ESXi 8 baseline'ında kapatılması beklenir. | KG03 |
| **CIM (Common Information Model)** | — | Donanım izleme ajanlarının host'tan veri çekmesini sağlayan yönetim arayüzü. | KG03 |
| **SNMP** | — | Ağ/donanım izleme protokolü; community ve hedef yapılandırması denetlenir. | KG03 |
| **Intel SGX (Software Guard Extensions)** | — | İşlemci üzerinde şifreli ve yalıtılmış bellek bölgesi (enclave) oluşturan donanım özelliği. | KG03 |
| **VMware Tools** | — | Guest OS'e kurulan sürücü ve servis paketi; gereksiz modülleri saldırı yüzeyini artırır. | KG03 |
| **Passthrough / DirectPath I/O** | Doğrudan aygıt aktarımı | Fiziksel PCI aygıtının doğrudan bir VM'e atanması; izolasyonu zayıflatabilir. | KG03 |
| **dvFilter** | — | ESXi'de VM ağ trafiğini güvenlik appliance'ına yönlendiren filtre çerçevesi. | KG03 |

## Depolama

| Terim (EN) | Türkçe Karşılık | Açıklama | İlgili Grup |
|---|---|---|---|
| **vSAN** | — | ESXi host'ların yerel disklerini birleştirerek oluşturulan yazılım tanımlı depolama katmanı. | KG05 |
| **Datastore** | Veri deposu | VM disklerinin tutulduğu mantıksal depolama birimi. | KG05 |
| **Storage Policy (SPBM)** | Depolama politikası | Kullanılabilirlik, performans ve şifreleme gereksinimlerini iş yükü bazında tanımlayan politika seti. | KG05 |
| **FTT (Failures To Tolerate)** | Tolere edilen arıza sayısı | vSAN storage policy'de kaç bileşen arızasına dayanılacağını belirleyen parametre. | KG05 |
| **vSAN File Services** | — | vSAN üzerinde NFS/SMB dosya paylaşımı sunan bileşen. | KG05 |
| **KMS / Key Provider** | Anahtar yönetim sunucusu | vSAN ve VM şifreleme anahtarlarını üreten ve saklayan dış sistem. | KG05 |
| **vmkernel port** | — | Yönetim, vMotion, vSAN gibi hypervisor servislerinin kendi IP arayüzü. | KG05, KG06 |

## Ağ

| Terim (EN) | Türkçe Karşılık | Açıklama | İlgili Grup |
|---|---|---|---|
| **vDS (vSphere Distributed Switch)** | Dağıtık sanal switch | Birden çok host'ta ortak yapılandırma sunan, vCenter'dan yönetilen sanal switch. | KG06 |
| **Standard vSwitch (vSS)** | Standart sanal switch | Tek host kapsamında yapılandırılan sanal switch; vDS ayarlarıyla karıştırılmamalıdır. | KG03 |
| **Port Group / dvPortgroup** | Port grubu | Aynı ağ ve güvenlik politikasını paylaşan sanal port kümesi. | KG06 |
| **Promiscuous Mode** | Karışık mod | Port grubuna bağlı VM'in kendisine ait olmayan trafiği de görmesine izin veren ayar; baseline değeri Reject. | KG06 |
| **Forged Transmits** | Sahte kaynak MAC gönderimi | VM'in kendi MAC adresinden farklı kaynak MAC ile çerçeve göndermesine izin veren ayar; baseline değeri Reject. | KG06 |
| **MAC Address Changes** | MAC adresi değişikliği | Guest OS'in etkin MAC adresini değiştirmesine izin veren ayar; baseline değeri Reject. | KG06 |
| **MAC Learning** | MAC öğrenme | Port üzerinde birden çok MAC adresinin dinamik öğrenilmesi; yalnız belgeli işlev ihtiyacında açılır. | KG06 |
| **VLAN Trunk** | — | Bir port üzerinden birden çok VLAN taşınması; tenant kapsamıyla sınırlandırılmalıdır. | KG06 |
| **NIC Teaming** | Ağ kartı gruplama | Birden çok fiziksel uplink'in yük dağıtımı ve yedeklilik için birlikte kullanılması. | KG06 |
| **Port Mirroring / SPAN** | Port yansıtma | Trafik kopyasının analiz sistemine yönlendirilmesi; yetkisi kısıtlanması gereken yüksek etkili bir işlemdir. | KG06 |
| **NetFlow** | — | Ağ akış kayıtlarının bir toplayıcıya gönderilmesi; hedef adresi denetlenir. | KG06 |
| **VDS Health Check** | — | vDS VLAN/MTU/teaming uyumunu test eden tanılama özelliği; sürekli açık bırakılması önerilmez. | KG06 |
| **IDS / NDR** | Saldırı tespit / ağ tespit ve yanıt | Ağ trafiğinde kötücül davranış tespiti ve yanıtı sağlayan sistemler. | KG06 |

## NSX ve mikrosegmentasyon

| Terim (EN) | Türkçe Karşılık | Açıklama | İlgili Grup |
|---|---|---|---|
| **NSX** | — | VMware'in ağ ve güvenlik sanallaştırma platformu. | KG07 |
| **DFW (Distributed Firewall)** | Dağıtık güvenlik duvarı | Her VM'in sanal ağ kartı seviyesinde uygulanan doğu-batı güvenlik duvarı. | KG07 |
| **Micro-segmentation** | Mikrosegmentasyon | İş yükü seviyesinde ağ yalıtımı yaklaşımı. | KG07 |
| **Default Deny** | Varsayılan reddet | Açıkça izin verilmeyen tüm trafiğin engellendiği politika yaklaşımı. | KG07 |
| **Exclusion List** | İstisna listesi | DFW kapsamı dışında bırakılan VM listesi; yalnız onaylı sistemleri içermelidir. | KG07 |
| **Tier-0 / Tier-1 Gateway** | — | NSX yönlendirme mimarisinde kuzey-güney (T0) ve tenant düzeyi (T1) ağ geçitleri. | KG07 |
| **SpoofGuard** | — | Segment/port üzerinde IP-MAC bağlarını doğrulayarak adres taklidini engelleyen profil. | KG07 |
| **Service Insertion** | Servis zincirleme | Trafiğin üçüncü taraf güvenlik servislerine yönlendirilmesi. | KG07 |
| **Security Tag / Dynamic Group** | Güvenlik etiketi / dinamik grup | VM'lerin etikete veya kritere göre otomatik gruplanıp politikaya bağlanması. | KG07 |
| **Principal Identity** | — | NSX'te sertifika tabanlı otomasyon kimliği. | KG02 |

## Cloud Director ve tenant

| Terim (EN) | Türkçe Karşılık | Açıklama | İlgili Grup |
|---|---|---|---|
| **vCloud Director (VCD)** | — | Çok kiracılı (multi-tenant) bulut hizmeti sunum ve self-servis portal katmanı. | KG09 |
| **Tenant / Organization** | Kiracı / organizasyon | Kaynakları ve verisi diğerlerinden yalıtılmış müşteri birimi. | KG09 |
| **Rights Bundle** | Hak paketi | Organizasyonlara yayımlanabilen (publish) hak kümesi. | KG09 |
| **Global Role** | Genel rol | Sağlayıcı tarafından tanımlanıp seçili organizasyonlara yayımlanan rol. | KG09 |
| **Catalog / vApp Template / Content Library** | Katalog / şablon kütüphanesi | Paylaşılabilir VM ve uygulama şablonu depoları; paylaşım kapsamı denetlenir. | KG09 |
| **Onboarding / Offboarding** | Devreye alma / devreden çıkarma | Müşterinin hizmete alınması ve hizmetten çıkarılması süreçleri. | KG09 |
| **Quota / Resource Limit** | Kota / kaynak sınırı | Tenant'ın tüketebileceği azami kaynak. | KG09 |

## Taşıma, erişilebilirlik, süreklilik

| Terim (EN) | Türkçe Karşılık | Açıklama | İlgili Grup |
|---|---|---|---|
| **vMotion** | — | Çalışan VM'in kesintisiz olarak başka host'a taşınması. | KG08 |
| **Storage vMotion** | — | VM disklerinin çalışırken başka datastore'a taşınması. | KG08 |
| **HA (High Availability)** | Yüksek erişilebilirlik | Host arızasında VM'lerin başka host'ta otomatik yeniden başlatılması. | KG08 |
| **DRS (Distributed Resource Scheduler)** | — | Küme içinde yük dengeleme amaçlı otomatik VM yerleştirme. | KG08 |
| **Affinity / Anti-Affinity Rule** | Birliktelik / ayrıklık kuralı | VM'lerin aynı ya da farklı host'ta çalışmasını zorunlu kılan kural. | KG08 |
| **Admission Control** | Kabul denetimi | HA için ayrılan yedek kapasitenin garanti altına alınması. | KG08 |
| **RPO / RTO / MTTR** | Veri kaybı / kurtarma / onarım hedefi | Recovery Point Objective, Recovery Time Objective, Mean Time To Repair. | KG01 |
| **BCP / DR** | İş sürekliliği / felaket kurtarma | Business Continuity Plan / Disaster Recovery. | KG01 |
| **Runbook** | İşletim yordamı | Adım adım tanımlı operasyonel müdahale dokümanı. | KG01 |
| **RACI** | Sorumluluk matrisi | Responsible, Accountable, Consulted, Informed rollerinin dağılımı. | KG01 |
| **MSA / SLA** | Ana sözleşme / hizmet seviyesi anlaşması | Master Service Agreement ve Service Level Agreement. | KG01 |

## Kimlik ve erişim yönetimi

| Terim (EN) | Türkçe Karşılık | Açıklama | İlgili Grup |
|---|---|---|---|
| **IAM (Identity and Access Management)** | Kimlik ve erişim yönetimi | Hesap yaşam döngüsü ve yetkilendirmenin merkezi yönetimi. | KG02 |
| **SSO (Single Sign-On)** | Tekli oturum açma | vCenter'da kimlik doğrulama ve token servisi. | KG04 |
| **Identity Source / IdP** | Kimlik kaynağı / kimlik sağlayıcı | AD, LDAP, OIDC gibi kurumsal kimlik kaynağı. | KG04 |
| **MFA (Multi-Factor Authentication)** | Çok bileşenli kimlik doğrulama | Birden fazla doğrulama faktörünün birlikte kullanılması. | KG02 |
| **RBAC (Role-Based Access Control)** | Rol tabanlı erişim denetimi | Yetkinin role, rolün kullanıcıya atanması modeli. | KG02 |
| **Least Privilege** | En az yetki | Kullanıcıya yalnız görevini yapmaya yetecek yetkinin verilmesi. | KG02 |
| **Segregation of Duties** | Görevler ayrılığı | Kritik bir işlemin baştan sona tek kişide toplanmaması. | KG02 |
| **Dual Authorization** | İkili onay | Yüksek etkili işlemin iki ayrı yetkili tarafından onaylanması. | KG02 |
| **Access Review / Recertification** | Erişim gözden geçirme / yeniden onaylama | Verilmiş yetkilerin periyodik olarak doğrulanması. | KG02, KG04 |
| **Account Lockout** | Hesap kilitleme | Ardışık başarısız giriş sonrası hesabın geçici kilitlenmesi. | KG02 |
| **Service Account** | Servis hesabı | Kişiye değil uygulamaya veya otomasyona ait hesap. | KG02 |
| **Secret Manager / Vault** | Sır yönetimi | Parola, anahtar ve token'ların merkezi ve denetimli saklandığı sistem. | KG02 |
| **Login Banner** | Oturum uyarı metni | Giriş öncesi gösterilen yasal ve kurumsal uyarı metni. | KG03, KG04 |
| **Idle Session Timeout** | Boşta oturum zaman aşımı | Hareketsiz oturumun otomatik sonlandırılması. | KG03, KG04 |
| **authorized_keys** | — | SSH açık anahtar tabanlı kimlik doğrulama dosyası. | KG02 |
| **Global Permission / Propagate** | Genel izin / alt nesnelere yayma | vCenter envanterinin tamamına uygulanan izin ve iznin nesne hiyerarşisinde alt nesnelere geçmesi. | KG04 |

## Yama ve yapılandırma

| Terim (EN) | Türkçe Karşılık | Açıklama | İlgili Grup |
|---|---|---|---|
| **Patch / Upgrade** | Yama / sürüm yükseltme | Güvenlik düzeltmesi ve sürüm geçişi faaliyetleri. | KG11 |
| **Baseline** | Taban yapılandırma | Onaylı referans yapılandırma seti. | KG11 |
| **Config Drift** | Yapılandırma sapması | Onaylı taban yapılandırmadan zamanla uzaklaşma. | KG11 |
| **Staging** | Hazırlık ortamı | Üretim öncesi doğrulama ortamı. | KG11 |
| **Rollback** | Geri alma | Değişiklik öncesi duruma dönüş. | KG11 |
| **Hardening** | Sertleştirme | Saldırı yüzeyini azaltmaya yönelik güvenli yapılandırma. | KG03 |
| **Interoperability / HCL** | Uyumluluk listesi | Üreticinin desteklediği donanım-yazılım bileşimleri. | KG11 |
| **Golden Image / Template** | Altın imaj / şablon | Sertleştirilmiş, onaylı temel VM imajı. | KG10 |
| **Snapshot** | Anlık görüntü | VM'in belirli bir andaki disk/bellek durumunun kaydı; yedek yerine geçmez. | KG10 |
| **Clone** | Klon | Mevcut bir VM veya şablondan birebir kopya üretme. | KG10 |

## Log, izleme, olay yönetimi

| Terim (EN) | Türkçe Karşılık | Açıklama | İlgili Grup |
|---|---|---|---|
| **SIEM** | — | Log toplama, korelasyon ve alarm platformu. | KG12 |
| **Syslog** | — | Standart log iletim protokolü. | KG12 |
| **Audit Log** | İz kaydı / denetim izi | Kimin, ne zaman, hangi işlemi yaptığını gösteren kayıt (BDDK-BSY Md. 13/1 asgari içerik). | KG12 |
| **Correlation Rule** | Korelasyon kuralı | Birden çok olayı ilişkilendirerek alarm üreten kural. | KG12 |
| **Log Retention** | Log saklama süresi | Kayıtların saklandığı asgari süre (BDDK-BSY Md. 13/3: 3 yıl). | KG12 |
| **Playbook** | Müdahale kılavuzu | Olay tipine göre adım adım yanıt planı. | KG12 |
| **Alert Noise / Alert Fatigue** | Alarm gürültüsü / alarm yorgunluğu | Yüksek yanlış pozitif nedeniyle gerçek alarmların gözden kaçması. | KG12 |

## Denetim metodolojisi

| Terim (EN) | Türkçe Karşılık | Açıklama | İlgili Grup |
|---|---|---|---|
| **Acceptance Criteria** | Kabul ölçütü | Kontrolün "uygun" sayılabilmesi için karşılanması gereken koşul. | tüm sayfalar |
| **Sampling** | Örnekleme | Popülasyonun tamamı yerine temsili bir alt kümenin incelenmesi. | tüm sayfalar |
| **Evidence Limitations** | Kanıtın sınırları | Toplanan kanıtın neyi kanıtlamadığı; bulgu yazımında aşırı genellemeyi engeller. | tüm sayfalar |
| **Read-only access** | Salt okunur erişim | Üretim ortamında değişiklik yapmadan yalnız okuma yetkisiyle kanıt toplama. | tüm sayfalar |
| **Denetim sonucu değerleri** | — | uygun / uyumsuzluk / kapsam dışı / değerlendirilemedi. Uyumsuzluk yalnız "Bağlayıcı Kriter (Mevzuat)" kolonundaki maddeye atıfla verilebilir. | tüm sayfalar |

## Kaynak ve Referans Kodları

Referans kolonlarında geçen kaynak kodlarının açılımı ve **doğrulama durumu**. `DOĞRULANMADI` / `KISMEN` işaretli kodlar tam künyeye bağlanamamıştır — bulguya dayanak yapılmadan önce doğrulanmalıdır.

| Kod | Açılım | Kullanıldığı Kolon | Doğrulama Durumu |
|---|---|---|---|
| `BDDK-BSY` | BDDK Bilgi Sistemleri ve Elektronik Bankacılık Hizmetleri Hakkında Yönetmelik | Bağlayıcı Kriter (Mevzuat) | Doğrulandı - "Kapsam ve Kaynaklar" sayfasında künyesiyle listeli |
| `BDDK-DHY` | BDDK Bankaların Destek Hizmeti Almalarına İlişkin Yönetmelik | Bağlayıcı Kriter (Mevzuat) | Doğrulandı - "Kapsam ve Kaynaklar" sayfasında künyesiyle listeli |
| `BDDK-2020` | Kaynak dosyada açılımı verilmemiş BDDK atfı (KG08-07, "md.25") | Teknik Referanslar | DOĞRULANMADI - EK dosyasının Kaynaklar sayfası sağlanmadı; bulguya dayanak yapılmadan önce künye netleştirilmeli |
| `CBDDO / BIGR` | CBDDO Bilgi ve İletişim Güvenliği Rehberi | Bağlayıcı Kriter, Teknik Referanslar | Doğrulandı - "Kapsam ve Kaynaklar" sayfasında cbddo-bigr olarak listeli; satırlarda basılı/PDF sayfa numarası da veriliyor |
| `CIS-ESX7` | CIS VMware ESXi 7.0 Benchmark v1.5.0 | Teknik Referanslar, Orijinal Dayanak | Doğrulandı - "Kapsam ve Kaynaklar" sayfasında sürümüyle listeli |
| `CIS-ESX8` | CIS VMware ESXi 8.0 Benchmark v1.3.0 | Teknik Referanslar, Orijinal Dayanak | Doğrulandı - "Kapsam ve Kaynaklar" sayfasında sürümüyle listeli |
| `NIST-53` | NIST SP 800-53 Rev.5 güvenlik kontrolü kimlikleri (AC-, AU-, CM-, CP-, IA-, SC- aileleri) | Teknik Referanslar | Doğrulandı - "Kapsam ve Kaynaklar" sayfasında listeli |
| `NIST-ASSESS` | Kaynakta bölüm numarasıyla (2.4, 3.2-3.4, Ek C) atıf yapılan NIST denetim/değerlendirme kaynağı; numaralandırma NIST SP 800-53A yapısıyla uyumludur | Denetim Yöntemi Referansları | DOĞRULANMADI - EK dosyasının Kaynaklar sayfası sağlanmadığı için tam künye teyit edilemedi |
| `IIA-GIAS` | IIA Global Internal Audit Standards; kaynakta 13.4, 13.6, 14.1-14.3, 14.6 maddelerine atıf var | Denetim Yöntemi Referansları | DOĞRULANMADI - kaynak dosyada künye yok; madde numaralandırması GIAS yapısıyla uyumlu |
| `VMW-SCG` | VMware Security Configuration Guide; satırlarda esxi-8.*, vcenter-8.*, vm-8.* biçiminde ayar adı verilir | Teknik Referanslar, Erişim Referansları | KISMEN - ayar adları satırlarda mevcut; EK'in "Üretici Eşlemesi" sayfası sağlanmadığı için sürüm ve tam başlık doğrulanamadı |
| `VMW-VCD` | VMware Cloud Director ürün dokümantasyonu (ör. Global Roles, Query Global Role Tenants) | Teknik Referanslar, Erişim Referansları | KISMEN - nesne/API adları satırlarda var, künye yok |
| `VMW-NSX` | VMware NSX ürün dokümantasyonu | Teknik Referanslar | KISMEN - nesne adları var, künye yok |
| `VMW-VSAN` | VMware vSAN ürün dokümantasyonu | Erişim Referansları | KISMEN - künye yok |
| `VMW-VMOTION` | VMware vSphere vMotion dokümantasyonu | Erişim Referansları | KISMEN - künye yok |
| `VCD-LOCK` | Cloud Director hesap kilitleme (account lockout) ayar nesnesi: OrgPasswordPolicySettingsType | Teknik Referanslar (KG02-07) | KISMEN - nesne adı kaynakta açık, kod açılımı verilmemiş |
| `NSX-PI` | NSX Principal Identity nesnesi: PrincipalIdentityList | Teknik Referanslar (KG02-17) | KISMEN - nesne adı kaynakta açık, kod açılımı verilmemiş |
| `NSX-SPOOF` | NSX SpoofGuard adres bağlama listesi: address_binding_allowlist | Teknik Referanslar (KG07-11) | KISMEN - nesne adı kaynakta açık, kod açılımı verilmemiş |
| `SSH-MAN` | OpenSSH sshd_config kılavuzu (man sayfası) atfı | Teknik Referanslar (KG03-15, KG03-16) | DOĞRULANMADI - kaynak dosyada açılım yok, bağlamdan çıkarılmıştır |
| `RO-VMW-ADV` | Salt okunur (read-only) VMware Advanced System Settings erişim yöntemi referansı | Erişim Referansları | KISMEN - "RO" öneki salt okunur erişimi işaret eder; kaynak dosyada açılım yok |
| `RO-VMW-PERM` | Salt okunur (read-only) VMware Permissions görünümü erişim yöntemi referansı | Erişim Referansları | KISMEN - kaynak dosyada açılım yok |
| `TSM-SSH` | ESXi SSH servisinin PowerCLI servis anahtarı (bir referans kodu değil, ürün değeri) | Kaynaklar sayfasındaki CIS denetim komutu | Doğrulandı - CIS ESXi 7.0 denetim komutunda birebir geçer |
| `AS-ADV / SVC-SEC / SSH-FILES / AD-PERM / SCG-RO(X) / VIPERM` | EK setinin kanıta erişim yöntemi kısaltmaları | Kanıta Ulaşım Yöntemi | Doğrulandı - tam metinleri "Kısaltmalar" sayfasında, kaynaktan birebir |
| `TAIL-1 / TAIL-2 / TEST-1 / TEST-2` | EK setinin ortak test adımı kısaltmaları | İnceleme ve Test Adımları | Doğrulandı - tam metinleri "Kısaltmalar" sayfasında |
| `KAYIT-B / KAYIT-B2` | EK setinin ortak örnekleme (sampling) metni kısaltmaları | İncelenecek Kayıtlar ve Örnekleme | Doğrulandı - tam metinleri "Kısaltmalar" sayfasında |
| `SINIR-1 ... SINIR-4` | EK setinin ortak kanıt sınırı metni kısaltmaları | Kanıtın Sınırları | Doğrulandı - tam metinleri "Kısaltmalar" sayfasında |
| `RISK-B / RISK-C` | EK setinin ortak risk metni kısaltmaları | Olası Riskler | Doğrulandı - tam metinleri "Kısaltmalar" sayfasında |

