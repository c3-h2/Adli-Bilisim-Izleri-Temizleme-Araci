# Kısaltmalar (ortak metinler)

**Çalışma:** VMware MSP Denetimi · **Sürüm:** v4 — 14 Eylül 2026  
**Doküman:** EK soru setinde tekrar eden ortak metinlerin tam karşılıkları  
**Hazırlayan:** KKB İç Denetim Başkanlığı — BT Denetimi (danışmanlık çıktısıdır, son karar denetçinindir)  
**Ana dizin:** `00 - Ana Dizin ve Dokuman Haritasi.xlsx`

---

EK soru setinde tekrar eden ortak metinler hücrelerde kısaltmayla yazılmıştır (`X + KISALTMA` biçiminde). Tam metinler kaynaktan birebir alınmıştır.

| Kısaltma | Tam Metin | Kullanıldığı Kolon |
|---|---|---|
| `AS-ADV` | vSphere Client içinde hedef hostun Configure > System > Advanced System Settings görünümünde kanıt alanında adı verilen parametreyi okuyun. Alternatif: Get-AdvancedSetting -Entity (Get-VMHost -Name <host>) -Name <parametre>. VM parametresi varsa ilgili VM üzerinde ayrıca okuyun; host ayarıyla eşitlemeyin. | Kanıta Ulaşım Yöntemi |
| `SVC-SEC` | Hedef host Configure > System > Services ve Security Profile nesnelerinden hizmet/start policy durumunu okuyun. SNMP/CIM için ilgili CIS Audit bölümünün salt okunur sorgu çıktısını, rol ve izinli kaynaklarla eşleştirin. | Kanıta Ulaşım Yöntemi |
| `SSH-FILES` | Hostun ilgili CIS Audit bölümünde belirtilen SSH/yapılandırma dosyalarını yetkili salt okunur erişimle inceleyin. Dosya yolu, include/override ve etkin değer ayrımını koruyun; authorized_keys için özel anahtar değil kamu anahtarı parmak izi/varlık bilgisi alın. | Kanıta Ulaşım Yöntemi |
| `AD-PERM` | Host kimlik/permission ve AD integration yapılandırmasını okuyun; kişisel hesap/rol listesini AD gerçek grup üyeliği ve giriş kayıtlarıyla karşılaştırın. Katılım veya rol değiştirme işlemi yapmayın. | Kanıta Ulaşım Yöntemi |
| `SCG-RO(X)` | Üretici SCG Setting Location: X. Salt okunur ekran/rapor kullanın; üretici eşlemesindeki ayar adıyla karşılaştırın. | Kanıta Ulaşım Yöntemi |
| `VIPERM` | vSphere nesnesinin Permissions görünümünde principal, role ve propagate değerlerini okuyun; Get-VIPermission -Entity <hedef nesne> çıktısını global ve üst nesne izinleriyle tamamlayın. Yerel SSO/grup üyeliğini ayrı kimlik kaynağında doğrulayın. | Kanıta Ulaşım Yöntemi |
| `TAIL-1` | Yetki tanımını gerçek üyelik, oturum ve izin/ret davranışıyla birlikte doğrulayın. | İnceleme ve Test Adımları |
| `TAIL-2` | İzinli hedefi ve başka müşteriye ait yetkisiz hedefi farklı kimliklerle kontrollü karşılaştırın. | İnceleme ve Test Adımları |
| `TEST-1` | Etkin ayarı ve nesne kapsamını kabul ölçütünün her koşuluyla karşılaştırın. Onaylı test veya gerçekleşmiş olayla işletimi doğrulayın; üretimde ayar değiştirmeyin. | İnceleme ve Test Adımları |
| `TEST-2` | Salt okunur sistem çıktısını onaylı rol, kapsam ve yapılandırma kaydıyla karşılaştır; ölçütteki her koşul için kanıt konumu ve ayrı alt sonucu kaydet. Yalnız görüşme veya ekran görüntüsüyle fiili işleyiş sonucunu kapatma. | İnceleme ve Test Adımları |
| `KAYIT-B` | Farklı müşteri, sürüm, rol/işlev ve istisnaları ayırın. Tam export alınabiliyorsa kayıt listesinin eksiksizliğini doğrulayın; örnek seçildiyse gerekçe, dönem ve kapsamadığı alanı analizde belirtin. | İncelenecek Kayıtlar ve Örnekleme |
| `KAYIT-B2` | Farklı müşteri, sürüm, düğüm ve istisnaları kapsayın; kısmi örneklemden tüm ortama sonuç genellemeyin. | İncelenecek Kayıtlar ve Örnekleme |
| `SINIR-1` | Yapılandırma kanıtı ilgili anı gösterir; dönem boyunca işletimi tek başına kanıtlamaz. | Kanıtın Sınırları |
| `SINIR-2` | Senaryo gerçekleşmiş bulgu değildir. Kurulu sürüm ve kullanılan özellik kanıtlanır; konfigürasyon tek başına dönemsel işletimi göstermez. | Kanıtın Sınırları |
| `SINIR-3` | Kurum için onaylı periyot/eşik gerekir; metindeki uygulama örnekleri NIST'in zorunlu ürün parametresi değildir. Üretimde değişiklik veya kesinti testi yapılmaz. | Kanıtın Sınırları |
| `SINIR-4` | Kurulu sürüm/dağıtımın özellik ve lisans desteği kanıtlanır. Test, salt okunur çıktı veya onaylı izole ortamla yürütülür. | Kanıtın Sınırları |
| `RISK-B` | Etkinin yayılımı hesabın fiilî rolü, erişebildiği hedefler ve alternatif giriş yollarına bağlıdır. Senaryonun gerçekleştiği varsayılmaz; yayılımı kanıttaki hedef ve müşteri kapsamıyla sınırlandırın. | Olası Riskler |
| `RISK-C` | Paylaşılmış bir nesne veya yanlış kapsam kalıtımı aynı altyapıdaki başka müşteri verisine erişim yolu açabilir. | Olası Riskler |

